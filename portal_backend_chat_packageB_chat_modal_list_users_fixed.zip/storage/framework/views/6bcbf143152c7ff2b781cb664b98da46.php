<?php $__env->startSection('title', 'Admin - Agenda HSE & ESG'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h1 class="section-title mb-0">Agenda HSE & ESG</h1>
        <div class="text-muted small">Gerir eventos, workshops, formações, datas internacionais e webinars.</div>
    </div>
    <a href="<?php echo e(route('admin.agenda.create')); ?>" class="btn btn-primary">
        <i class="fa-solid fa-plus me-1"></i> Novo item
    </a>
</div>

<form class="row g-2 mb-3" method="GET" action="<?php echo e(route('admin.agenda.index')); ?>">
    <div class="col-12 col-md-5">
        <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Pesquisar por título, tipo ou local...">
    </div>
    <div class="col-12 col-md-3">
        <select name="type" class="form-select">
            <option value="">— Tipo —</option>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k); ?>" <?php if(request('type')===$k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-12 col-md-2">
        <button class="btn btn-outline-secondary w-100"><i class="fa-solid fa-filter me-1"></i> Filtrar</button>
    </div>
    <div class="col-12 col-md-2">
        <a class="btn btn-light w-100" href="<?php echo e(route('admin.agenda.index')); ?>"><i class="fa-solid fa-rotate-left me-1"></i> Limpar</a>
    </div>
</form>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="table-responsive bg-white rounded-4 shadow-sm">
    <table class="table table-hover mb-0 align-middle">
        <thead class="table-light">
            <tr>
                <th>Título</th>
                <th>Tipo</th>
                <th>Data</th>
                <th>Local</th>
                <th class="text-center">Ativo</th>
                <th class="text-end">Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="fw-semibold"><?php echo e($item->title); ?></div>
                        <div class="text-muted small">/agenda-hse/<?php echo e($item->slug); ?></div>
                    </td>
                    <td><span class="badge text-bg-light border"><?php echo e($types[$item->type] ?? $item->type); ?></span></td>
                    <td class="text-muted">
                        <?php echo e($item->starts_at?->format('d/m/Y H:i')); ?>

                    </td>
                    <td class="text-muted">
                        <?php echo e($item->is_online ? 'Online' : ($item->location ?? '—')); ?>

                    </td>
                    <td class="text-center">
                        <?php if($item->is_active): ?>
                            <span class="badge text-bg-success">Sim</span>
                        <?php else: ?>
                            <span class="badge text-bg-secondary">Não</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <a href="<?php echo e(route('admin.agenda.edit', $item)); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="fa-solid fa-pen"></i>
                        </a>
                        <form action="<?php echo e(route('admin.agenda.destroy', $item)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apagar este item?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">Nenhum item encontrado.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-3">
    <?php echo e($items->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\portal_backend_chat_packageB_chat_modal_list_users_fixed\resources\views/admin/agenda/index.blade.php ENDPATH**/ ?>