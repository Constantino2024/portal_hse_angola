

<?php $__env->startSection('title', 'Vagas HSE - Oportunidades em Saúde, Segurança e Ambiente'); ?>

<?php $__env->startSection('meta_description', 'Encontre as melhores vagas de emprego em HSE (Saúde, Segurança e Ambiente). Oportunidades para técnicos, engenheiros, auditores e profissionais do setor.'); ?>

<?php $__env->startSection('content'); ?>

<section class="jobs-index-section mt-8">
  <div class="container">
    
    <div class="jobs-header">
      <div class="header-content">
        <div class="header-text">
          <h1 class="jobs-title">Vagas de Emprego em HSE</h1>
          <p class="jobs-subtitle">Encontre oportunidades para técnicos, engenheiros, auditores e profissionais do setor de Saúde, Segurança e Ambiente.</p>
        </div>
        <div class="header-illustration">
          <i class="fas fa-search"></i>
        </div>
      </div>

      
      <div class="search-container">
        <form method="GET" action="<?php echo e(route('jobs.index')); ?>" class="search-form">
          <div class="search-input-group">
            <div class="search-icon">
              <i class="fas fa-search"></i>
            </div>
            <input type="text" 
                   name="q" 
                   value="<?php echo e(request('q')); ?>"
                   class="search-input"
                   placeholder="Pesquisar por cargo, empresa, localização...">
            <button class="search-btn" type="submit">
              Buscar Vagas
            </button>
          </div>
          
          
          <div class="quick-filters">
            <div class="filter-tags">
              <span class="filter-label">Filtrar por:</span>
              <?php if($filters = request()->except(['q', 'page'])): ?>
                <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($value): ?>
                    <a href="<?php echo e(route('jobs.index', request()->except([$key, 'page']))); ?>" 
                       class="filter-tag active">
                      <?php echo e(ucfirst($key)); ?>: <?php echo e($value); ?>

                      <i class="fas fa-times"></i>
                    </a>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </div>
            
            <button type="button" class="btn-filter-toggle" data-bs-toggle="collapse" data-bs-target="#advancedFilters">
              <i class="fas fa-sliders-h"></i> Filtros Avançados
            </button>
          </div>
          
          
          <div class="collapse" id="advancedFilters">
            <div class="advanced-filters">
              <div class="row g-3">
                <div class="col-md-4">
                  <label class="form-label">Localização</label>
                  <select name="location" class="form-select">
                    <option value="">Qualquer local</option>
                    <option value="Luanda" <?php echo e(request('location') == 'Luanda' ? 'selected' : ''); ?>>Luanda</option>
                    <option value="Benguela" <?php echo e(request('location') == 'Benguela' ? 'selected' : ''); ?>>Benguela</option>
                    <option value="Huíla" <?php echo e(request('location') == 'Huíla' ? 'selected' : ''); ?>>Huíla</option>
                    <option value="Remoto" <?php echo e(request('location') == 'Remoto' ? 'selected' : ''); ?>>Remoto</option>
                    <option value="Híbrido" <?php echo e(request('location') == 'Híbrido' ? 'selected' : ''); ?>>Híbrido</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="form-label">Tipo de Emprego</label>
                  <select name="type" class="form-select">
                    <option value="">Qualquer tipo</option>
                    <option value="Tempo Integral" <?php echo e(request('type') == 'Tempo Integral' ? 'selected' : ''); ?>>Tempo Integral</option>
                    <option value="Meio Período" <?php echo e(request('type') == 'Meio Período' ? 'selected' : ''); ?>>Meio Período</option>
                    <option value="Contrato" <?php echo e(request('type') == 'Contrato' ? 'selected' : ''); ?>>Contrato</option>
                    <option value="Estágio" <?php echo e(request('type') == 'Estágio' ? 'selected' : ''); ?>>Estágio</option>
                    <option value="Freelance" <?php echo e(request('type') == 'Freelance' ? 'selected' : ''); ?>>Freelance</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="form-label">Nível de Experiência</label>
                  <select name="level" class="form-select">
                    <option value="">Qualquer nível</option>
                    <option value="Estagiário" <?php echo e(request('level') == 'Estagiário' ? 'selected' : ''); ?>>Estagiário</option>
                    <option value="Júnior" <?php echo e(request('level') == 'Júnior' ? 'selected' : ''); ?>>Júnior</option>
                    <option value="Pleno" <?php echo e(request('level') == 'Pleno' ? 'selected' : ''); ?>>Pleno</option>
                    <option value="Sênior" <?php echo e(request('level') == 'Sênior' ? 'selected' : ''); ?>>Sênior</option>
                    <option value="Especialista" <?php echo e(request('level') == 'Especialista' ? 'selected' : ''); ?>>Especialista</option>
                  </select>
                </div>
              </div>
              <div class="filter-actions">
                <button type="submit" class="btn btn-primary">
                  <i class="fas fa-filter"></i> Aplicar Filtros
                </button>
                <a href="<?php echo e(route('jobs.index')); ?>" class="btn btn-outline-secondary">
                  <i class="fas fa-times"></i> Limpar Filtros
                </a>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>

    
    <div class="jobs-stats">
      <div class="stat-item">
        <div class="stat-number"><?php echo e($jobs->total() ?? 0); ?></div>
        <div class="stat-label">Vagas Publicadas</div>
      </div>
      <div class="stat-item">
        <div class="stat-number"><?php echo e($sponsoredCount ?? 0); ?></div>
        <div class="stat-label">Vagas Patrocinadas</div>
      </div>
      <div class="stat-item">
        <div class="stat-number"><?php echo e($remoteCount ?? 0); ?></div>
        <div class="stat-label">Vagas Remotas</div>
      </div>
      <div class="stat-item">
        <div class="stat-number"><?php echo e($newToday ?? 0); ?></div>
        <div class="stat-label">Novas Hoje</div>
      </div>
    </div>

    <div class="row g-5">
      
      <div class="col-lg-8">
        <?php if($jobs->count()): ?>
          
          <div class="sorting-bar">
            <div class="sorting-info">
              <span class="showing-count">
                Mostrando <strong><?php echo e($jobs->firstItem() ?? 0); ?>-<?php echo e($jobs->lastItem() ?? 0); ?></strong> 
                de <strong><?php echo e($jobs->total()); ?></strong> vagas
              </span>
              <?php if(request()->hasAny(['q', 'location', 'type', 'level'])): ?>
                <span class="search-results">
                  <i class="fas fa-search"></i> Resultados da sua busca
                </span>
              <?php endif; ?>
            </div>
            <div class="sorting-options">
              <select class="form-select form-select-sm" onchange="window.location.href = this.value">
                <option value="<?php echo e(route('jobs.index', array_merge(request()->except('page'), ['sort' => 'newest']))); ?>"
                        <?php echo e(request('sort') == 'newest' ? 'selected' : ''); ?>>
                  Mais Recentes
                </option>
                <option value="<?php echo e(route('jobs.index', array_merge(request()->except('page'), ['sort' => 'sponsored']))); ?>"
                        <?php echo e(request('sort') == 'sponsored' ? 'selected' : ''); ?>>
                  Patrocinadas Primeiro
                </option>
                <option value="<?php echo e(route('jobs.index', array_merge(request()->except('page'), ['sort' => 'closing_soon']))); ?>"
                        <?php echo e(request('sort') == 'closing_soon' ? 'selected' : ''); ?>>
                  A Encerrar Breve
                </option>
              </select>
            </div>
          </div>

          
          <div class="jobs-grid">
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <article class="job-card <?php echo e($job->is_sponsored ? 'sponsored' : ''); ?>">
                <?php if($job->is_sponsored): ?>
                  <div class="job-badge sponsored-badge">
                    <i class="fas fa-bolt"></i> Patrocinada
                  </div>
                <?php endif; ?>
                
                <?php if($job->is_featured): ?>
                  <div class="job-badge featured-badge">
                    <i class="fas fa-star"></i> Destaque
                  </div>
                <?php endif; ?>
                
                <?php if($job->is_urgent): ?>
                  <div class="job-badge urgent-badge">
                    <i class="fas fa-clock"></i> Urgente
                  </div>
                <?php endif; ?>

                <div class="job-header">
                  <div class="job-company">
                    <?php if($job->company_logo): ?>
                      <img src="<?php echo e(asset('storage/'.$job->company_logo)); ?>" 
                           alt="<?php echo e($job->company); ?>"
                           class="company-logo">
                    <?php else: ?>
                      <div class="company-logo-placeholder">
                        <?php echo e(substr($job->company, 0, 2)); ?>

                      </div>
                    <?php endif; ?>
                    <div class="company-info">
                      <h3 class="company-name"><?php echo e($job->company); ?></h3>
                      <div class="job-meta">
                        <span class="meta-item">
                          <i class="fas fa-map-marker-alt"></i>
                          <?php echo e($job->location ?? 'Local não especificado'); ?>

                        </span>
                        <?php if($job->type): ?>
                          <span class="meta-item">
                            <i class="fas fa-clock"></i>
                            <?php echo e($job->type); ?>

                          </span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="job-body">
                  <h2 class="job-title">
                    <a href="<?php echo e(route('jobs.show', $job->slug)); ?>"><?php echo e($job->title); ?></a>
                  </h2>
                  
                  <p class="job-excerpt">
                    <?php echo e($job->excerpt ?? \Illuminate\Support\Str::limit(strip_tags($job->description), 160)); ?>

                  </p>
                  
                  <div class="job-tags">
                    <?php if($job->level): ?>
                      <span class="job-tag level-tag">
                        <i class="fas fa-signal"></i> <?php echo e($job->level); ?>

                      </span>
                    <?php endif; ?>
                    
                    <?php if($job->salary_range): ?>
                      <span class="job-tag salary-tag">
                        <i class="fas fa-money-bill-wave"></i> <?php echo e($job->salary_range); ?>

                      </span>
                    <?php endif; ?>
                    
                    <?php if($job->category): ?>
                      <span class="job-tag category-tag">
                        <i class="fas fa-tag"></i> <?php echo e($job->category); ?>

                      </span>
                    <?php endif; ?>
                    
                    <?php if($job->is_remote): ?>
                      <span class="job-tag remote-tag">
                        <i class="fas fa-laptop-house"></i> Remoto
                      </span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="job-footer">
                  <div class="job-posted">
                    <span class="posted-date">
                      <i class="fas fa-calendar-alt"></i>
                      <?php echo e(optional($job->published_at)->diffForHumans()); ?>

                    </span>
                    <?php if($job->closing_date): ?>
                      <span class="closing-date">
                        <i class="fas fa-hourglass-end"></i>
                        Fecha em <?php echo e(\Carbon\Carbon::parse($job->closing_date)->format('d/m/Y')); ?>

                      </span>
                    <?php endif; ?>
                  </div>
                  
                  <div class="job-actions">
                    <a href="<?php echo e(route('jobs.show', $job->slug)); ?>" class="btn btn-primary btn-sm">
                      <i class="fas fa-eye me-1"></i> Ver Vaga
                    </a>
                    <?php if($job->apply_link): ?>
                      <a href="<?php echo e($job->apply_link); ?>" 
                         target="_blank" 
                         class="btn btn-success btn-sm">
                        <i class="fas fa-paper-plane me-1"></i> Candidatar
                      </a>
                    <?php endif; ?>
                    <button class="btn btn-outline-secondary btn-sm save-job" data-job-id="<?php echo e($job->id); ?>">
                      <i class="far fa-bookmark"></i>
                    </button>
                  </div>
                </div>
              </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          
          <div class="pagination-container">
            <nav aria-label="Navegação de vagas">
              <ul class="pagination justify-content-center">
                
                <li class="page-item <?php echo e($jobs->onFirstPage() ? 'disabled' : ''); ?>">
                  <a class="page-link" href="<?php echo e($jobs->previousPageUrl()); ?>" aria-label="Anterior">
                    <i class="fas fa-chevron-left"></i>
                    <span class="d-none d-md-inline">Anterior</span>
                  </a>
                </li>

                
                <?php
                  $current = $jobs->currentPage();
                  $last = $jobs->lastPage();
                  $start = max(1, $current - 2);
                  $end = min($last, $current + 2);
                ?>

                <?php if($start > 1): ?>
                  <li class="page-item">
                    <a class="page-link" href="<?php echo e($jobs->url(1)); ?>">1</a>
                  </li>
                  <?php if($start > 2): ?>
                    <li class="page-item disabled">
                      <span class="page-link">...</span>
                    </li>
                  <?php endif; ?>
                <?php endif; ?>

                <?php for($i = $start; $i <= $end; $i++): ?>
                  <li class="page-item <?php echo e($i == $current ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($jobs->url($i)); ?>"><?php echo e($i); ?></a>
                  </li>
                <?php endfor; ?>

                <?php if($end < $last): ?>
                  <?php if($end < $last - 1): ?>
                    <li class="page-item disabled">
                      <span class="page-link">...</span>
                    </li>
                  <?php endif; ?>
                  <li class="page-item">
                    <a class="page-link" href="<?php echo e($jobs->url($last)); ?>"><?php echo e($last); ?></a>
                  </li>
                <?php endif; ?>

                
                <li class="page-item <?php echo e(!$jobs->hasMorePages() ? 'disabled' : ''); ?>">
                  <a class="page-link" href="<?php echo e($jobs->nextPageUrl()); ?>" aria-label="Próximo">
                    <span class="d-none d-md-inline">Próximo</span>
                    <i class="fas fa-chevron-right"></i>
                  </a>
                </li>
              </ul>
            </nav>
            
            <div class="pagination-info text-center mt-3">
              <span class="text-muted">
                Página <?php echo e($jobs->currentPage()); ?> de <?php echo e($jobs->lastPage()); ?>

                • <?php echo e($jobs->perPage()); ?> vagas por página
              </span>
            </div>
          </div>

        <?php else: ?>
          
          <div class="no-results">
            <div class="no-results-icon">
              <i class="fas fa-search"></i>
            </div>
            <h3>Nenhuma vaga encontrada</h3>
            <p class="text-muted">
              <?php if(request()->hasAny(['q', 'location', 'type', 'level'])): ?>
                Não encontramos vagas correspondentes aos seus critérios de busca.
                <a href="<?php echo e(route('jobs.index')); ?>" class="text-primary">Ver todas as vagas</a>
              <?php else: ?>
                Não há vagas disponíveis no momento. Volte mais tarde para novas oportunidades.
              <?php endif; ?>
            </p>
            <div class="suggestions">
              <p class="mb-2"><strong>Sugestões:</strong></p>
              <ul>
                <li>Verifique se digitou corretamente os termos da busca</li>
                <li>Tente usar palavras-chave mais genéricas</li>
                <li>Remova alguns filtros para ampliar a busca</li>
                <li>Cadastre-se na newsletter para receber novas vagas</li>
              </ul>
            </div>
          </div>
        <?php endif; ?>
      </div>

      
      <div class="col-lg-4">
        
        <div class="sidebar-widget">
          <div class="widget-header">
            <i class="fas fa-lightbulb"></i>
            <h3>Dicas de Busca</h3>
          </div>
          <div class="widget-content">
            <ul class="tips-list">
              <li>
                <i class="fas fa-check-circle text-success"></i>
                <span>Use palavras-chave específicas como <strong>"Técnico HSE"</strong> ou <strong>"Engenheiro Ambiental"</strong></span>
              </li>
              <li>
                <i class="fas fa-check-circle text-success"></i>
                <span>Pesquise por <strong>nome da empresa</strong> ou <strong>cidade/estado</strong></span>
              </li>
              <li>
                <i class="fas fa-check-circle text-success"></i>
                <span>Clique na vaga para ver <strong>requisitos completos</strong> e <strong>como se candidatar</strong></span>
              </li>
              <li>
                <i class="fas fa-check-circle text-success"></i>
                <span>Salve vagas interessantes clicando no ícone <i class="far fa-bookmark"></i></span>
              </li>
            </ul>
          </div>
        </div>

        
        <div class="sidebar-widget">
          <div class="widget-header">
            <i class="fas fa-envelope-open-text"></i>
            <h3>Receba Novas Vagas</h3>
          </div>
          <div class="widget-content">
            <p>Cadastre-se para receber alertas de novas vagas em HSE diretamente no seu email.</p>
            <form action="<?php echo e(route('subscribers.store')); ?>" method="POST" class="newsletter-form" id="jobsNewsletter">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="source" value="jobs_page">
              
              <div class="form-group mb-3">
                <input type="email" 
                       name="email" 
                       class="form-control" 
                       placeholder="seu@email.com"
                       required>
              </div>
              
              <div class="form-group mb-3">
                <select name="job_alerts_category" class="form-select">
                  <option value="">Todas as categorias</option>
                  <option value="saude">Saúde Ocupacional</option>
                  <option value="seguranca">Segurança do Trabalho</option>
                  <option value="ambiente">Meio Ambiente</option>
                  <option value="qualidade">Qualidade</option>
                </select>
              </div>
              
              <button type="submit" class="btn btn-primary w-100">
                <i class="fas fa-paper-plane me-2"></i> Receber Vagas
              </button>
            </form>
            <div class="form-text mt-2">
              <small>
                <i class="fas fa-shield-alt text-primary"></i>
                Seu email está seguro. Não enviamos spam.
              </small>
            </div>
          </div>
        </div>


      

        
        <div class="sidebar-widget">
          <div class="widget-header">
            <i class="fas fa-tags"></i>
            <h3>Categorias HSE</h3>
          </div>
          <div class="widget-content">
            <div class="categories-list">
              <a href="<?php echo e(route('jobs.index', ['category' => 'seguranca'])); ?>" class="category-item">
                <i class="fas fa-hard-hat"></i>
                <span>Segurança do Trabalho</span>
                <span class="category-count">(<?php echo e($categoryCounts['seguranca'] ?? 0); ?>)</span>
              </a>
              <a href="<?php echo e(route('jobs.index', ['category' => 'saude'])); ?>" class="category-item">
                <i class="fas fa-heartbeat"></i>
                <span>Saúde Ocupacional</span>
                <span class="category-count">(<?php echo e($categoryCounts['saude'] ?? 0); ?>)</span>
              </a>
              <a href="<?php echo e(route('jobs.index', ['category' => 'ambiente'])); ?>" class="category-item">
                <i class="fas fa-leaf"></i>
                <span>Meio Ambiente</span>
                <span class="category-count">(<?php echo e($categoryCounts['ambiente'] ?? 0); ?>)</span>
              </a>
              <a href="<?php echo e(route('jobs.index', ['category' => 'qualidade'])); ?>" class="category-item">
                <i class="fas fa-chart-line"></i>
                <span>Qualidade</span>
                <span class="category-count">(<?php echo e($categoryCounts['qualidade'] ?? 0); ?>)</span>
              </a>
              <a href="<?php echo e(route('jobs.index', ['category' => 'consultoria'])); ?>" class="category-item">
                <i class="fas fa-briefcase"></i>
                <span>Consultoria</span>
                <span class="category-count">(<?php echo e($categoryCounts['consultoria'] ?? 0); ?>)</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="jobs-cta">
  <div class="container">
    <div class="cta-content">
      <h2 class="cta-title">Encontrou a vaga ideal?</h2>
      <p class="cta-text">Prepare seu currículo e faça sua candidatura agora mesmo!</p>
      <div class="cta-actions">
        <a href="<?php echo e(route('jobs.index', ['sort' => 'newest'])); ?>" class="btn btn-light btn-lg">
          <i class="fas fa-sync-alt me-2"></i> Ver Vagas Recentes
        </a>
        <a href="#" class="btn btn-outline-light btn-lg">
          <i class="fas fa-file-alt me-2"></i> Dicas de CV HSE
        </a>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* Estilos específicos para a página de vagas */
.jobs-index-section {
  padding: 40px 0 80px;
  background: linear-gradient(180deg, #f8f9fa 0%, #ffffff 100%);
}

/* Header */
.jobs-header {
  background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
  border-radius: 20px;
  padding: 40px;
  color: white;
  margin-bottom: 40px;
  position: relative;
  overflow: hidden;
}

.jobs-header::before {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  width: 300px;
  height: 300px;
  background: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
  background-size: 30px 30px;
  opacity: 0.3;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  position: relative;
  z-index: 1;
}

.header-text {
  flex: 1;
}

.jobs-title {
  font-size: 2.8rem;
  font-weight: 800;
  margin-bottom: 10px;
  color: white;
}

.jobs-subtitle {
  font-size: 1.1rem;
  opacity: 0.9;
  max-width: 600px;
}

.header-illustration {
  font-size: 5rem;
  opacity: 0.2;
  margin-left: 30px;
}

/* Search Container */
.search-container {
  position: relative;
  z-index: 1;
}

.search-form {
  background: white;
  border-radius: 15px;
  padding: 20px;
  box-shadow: 0 15px 35px rgba(0,0,0,0.15);
}

.search-input-group {
  display: flex;
  gap: 10px;
  margin-bottom: 15px;
  position: relative;
}

.search-icon {
  position: absolute;
  left: 20px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--primary-color);
  font-size: 1.2rem;
  z-index: 2;
}

.search-input {
  flex: 1;
  padding: 16px 20px 16px 50px;
  border: 2px solid var(--neutral-medium);
  border-radius: 12px;
  font-size: 1rem;
  transition: all 0.3s ease;
}

.search-input:focus {
  border-color: var(--primary-color);
  box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.1);
  outline: none;
}

.search-btn {
  background: var(--accent-color);
  color: white;
  border: none;
  padding: 16px 30px;
  border-radius: 12px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.3s ease;
  white-space: nowrap;
}

.search-btn:hover {
  background: var(--accent-dark);
  transform: translateY(-2px);
}

/* Quick Filters */
.quick-filters {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 15px;
}

.filter-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
}

.filter-label {
  font-weight: 600;
  color: var(--neutral-dark);
  font-size: 0.9rem;
}

.filter-tag {
  background: var(--neutral-light);
  color: var(--neutral-text);
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 0.85rem;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  border: 1px solid var(--neutral-medium);
  transition: all 0.3s ease;
}

.filter-tag.active {
  background: var(--primary-light);
  color: white;
  border-color: var(--primary-color);
}

.filter-tag:hover {
  background: var(--primary-color);
  color: white;
  border-color: var(--primary-color);
}

.btn-filter-toggle {
  background: transparent;
  border: 2px solid var(--neutral-medium);
  color: var(--neutral-text);
  padding: 8px 16px;
  border-radius: 8px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: all 0.3s ease;
}

.btn-filter-toggle:hover {
  border-color: var(--primary-color);
  color: var(--primary-color);
}

.btn-filter-toggle[aria-expanded="true"] {
  background: var(--primary-light);
  border-color: var(--primary-color);
  color: white;
}

/* Advanced Filters */
.advanced-filters {
  padding-top: 20px;
  border-top: 1px solid var(--neutral-medium);
  margin-top: 15px;
}

.form-label {
  font-weight: 600;
  color: var(--neutral-dark);
  margin-bottom: 8px;
  display: block;
}

.form-select {
  padding: 10px 15px;
  border: 2px solid var(--neutral-medium);
  border-radius: 8px;
  font-size: 0.95rem;
  transition: all 0.3s ease;
}

.form-select:focus {
  border-color: var(--primary-color);
  box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.1);
  outline: none;
}

.filter-actions {
  display: flex;
  gap: 10px;
  margin-top: 20px;
  flex-wrap: wrap;
}

/* Stats */
.jobs-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 40px;
  background: white;
  padding: 25px;
  border-radius: 15px;
  box-shadow: var(--shadow);
}

.stat-item {
  text-align: center;
  padding: 15px;
  background: var(--neutral-light);
  border-radius: 10px;
  transition: all 0.3s ease;
}

.stat-item:hover {
  transform: translateY(-5px);
  background: linear-gradient(135deg, var(--neutral-light) 0%, white 100%);
  box-shadow: var(--shadow);
}

.stat-number {
  font-size: 2.5rem;
  font-weight: 800;
  color: var(--primary-color);
  line-height: 1;
  margin-bottom: 8px;
}

.stat-label {
  font-size: 0.9rem;
  color: var(--neutral-text);
  font-weight: 600;
}

/* Sorting Bar */
.sorting-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  padding: 15px 20px;
  background: white;
  border-radius: 10px;
  box-shadow: var(--shadow);
  flex-wrap: wrap;
  gap: 15px;
}

.sorting-info {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.showing-count {
  font-size: 0.95rem;
  color: var(--neutral-text);
}

.search-results {
  font-size: 0.85rem;
  color: var(--primary-color);
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.sorting-options {
  min-width: 200px;
}

/* Jobs Grid */
.jobs-grid {
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-bottom: 40px;
}

.job-card {
  background: white;
  border-radius: 15px;
  padding: 25px;
  box-shadow: var(--shadow);
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  border: 2px solid transparent;
  position: relative;
}

.job-card:hover {
  transform: translateY(-8px);
  box-shadow: var(--shadow-large);
  border-color: var(--primary-light);
}

.job-card.sponsored {
  border-color: var(--accent-color);
}

.job-badge {
  position: absolute;
  top: 15px;
  right: 15px;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 0.75rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  z-index: 1;
}

.sponsored-badge {
  background: var(--accent-color);
  color: white;
  box-shadow: 0 4px 10px rgba(255, 107, 53, 0.2);
}

.featured-badge {
  background: var(--secondary-color);
  color: white;
  box-shadow: 0 4px 10px rgba(0, 168, 89, 0.2);
}

.urgent-badge {
  background: var(--danger-color);
  color: white;
  box-shadow: 0 4px 10px rgba(220, 53, 69, 0.2);
}

/* Job Header */
.job-header {
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 2px solid var(--neutral-medium);
}

.job-company {
  display: flex;
  align-items: center;
  gap: 15px;
}

.company-logo {
  width: 60px;
  height: 60px;
  border-radius: 12px;
  object-fit: contain;
  border: 2px solid var(--neutral-medium);
  padding: 5px;
  background: white;
}

.company-logo-placeholder {
  width: 60px;
  height: 60px;
  border-radius: 12px;
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 1.5rem;
  font-weight: 700;
  border: 2px solid var(--neutral-medium);
}

.company-info {
  flex: 1;
}

.company-name {
  font-size: 1.2rem;
  font-weight: 700;
  color: var(--neutral-dark);
  margin-bottom: 5px;
}

.job-meta {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

.meta-item {
  font-size: 0.9rem;
  color: var(--neutral-text);
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.meta-item i {
  color: var(--secondary-color);
}

/* Job Body */
.job-body {
  margin-bottom: 25px;
}

.job-title {
  font-size: 1.4rem;
  font-weight: 700;
  margin-bottom: 15px;
  line-height: 1.4;
}

.job-title a {
  color: var(--primary-dark);
  text-decoration: none;
  transition: color 0.3s ease;
}

.job-title a:hover {
  color: var(--primary-color);
}

.job-excerpt {
  color: var(--neutral-text);
  line-height: 1.6;
  margin-bottom: 20px;
  font-size: 0.95rem;
}

.job-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.job-tag {
  padding: 6px 12px;
  background: var(--neutral-light);
  color: var(--neutral-text);
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  border: 1px solid var(--neutral-medium);
}

.level-tag {
  background: rgba(0, 102, 204, 0.1);
  color: var(--primary-color);
  border-color: rgba(0, 102, 204, 0.2);
}

.salary-tag {
  background: rgba(0, 168, 89, 0.1);
  color: var(--secondary-color);
  border-color: rgba(0, 168, 89, 0.2);
}

.category-tag {
  background: rgba(255, 107, 53, 0.1);
  color: var(--accent-color);
  border-color: rgba(255, 107, 53, 0.2);
}

.remote-tag {
  background: rgba(108, 117, 125, 0.1);
  color: #6c757d;
  border-color: rgba(108, 117, 125, 0.2);
}

/* Job Footer */
.job-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 20px;
  border-top: 2px solid var(--neutral-medium);
  flex-wrap: wrap;
  gap: 15px;
}

.job-posted {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}

.posted-date,
.closing-date {
  font-size: 0.85rem;
  color: var(--neutral-text);
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.closing-date {
  color: var(--danger-color);
  font-weight: 600;
}

.job-actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.job-actions .btn {
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 0.9rem;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.save-job {
  width: 40px;
  padding: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.save-job.saved {
  color: var(--accent-color);
  border-color: var(--accent-color);
}

.save-job.saved i {
  color: var(--accent-color);
}

/* Pagination */
.pagination-container {
  margin-top: 40px;
}

.pagination {
  gap: 5px;
}

.page-item.active .page-link {
  background: var(--primary-color);
  border-color: var(--primary-color);
  color: white;
}

.page-link {
  padding: 10px 16px;
  border: 2px solid var(--neutral-medium);
  color: var(--neutral-dark);
  font-weight: 600;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.page-link:hover {
  background: var(--primary-light);
  border-color: var(--primary-color);
  color: white;
}

.page-item.disabled .page-link {
  background: var(--neutral-light);
  border-color: var(--neutral-medium);
  color: var(--neutral-text);
  opacity: 0.6;
}

.pagination-info {
  font-size: 0.9rem;
  color: var(--neutral-text);
}

/* No Results */
.no-results {
  text-align: center;
  padding: 60px 20px;
  background: white;
  border-radius: 15px;
  box-shadow: var(--shadow);
}

.no-results-icon {
  font-size: 4rem;
  color: var(--neutral-medium);
  margin-bottom: 20px;
  opacity: 0.5;
}

.no-results h3 {
  font-size: 1.8rem;
  color: var(--neutral-dark);
  margin-bottom: 15px;
}

.suggestions {
  text-align: left;
  max-width: 500px;
  margin: 30px auto 0;
  padding: 20px;
  background: var(--neutral-light);
  border-radius: 10px;
}

.suggestions ul {
  list-style: none;
  padding-left: 0;
  margin-bottom: 0;
}

.suggestions li {
  padding: 5px 0;
  color: var(--neutral-text);
  display: flex;
  align-items: flex-start;
  gap: 10px;
}

.suggestions li::before {
  content: '•';
  color: var(--primary-color);
  font-weight: bold;
}

/* Sidebar Widgets */
.sidebar-widget {
  background: white;
  border-radius: 15px;
  margin-bottom: 30px;
  box-shadow: var(--shadow);
  border: 2px solid var(--neutral-medium);
  overflow: hidden;
}

.sidebar-widget .widget-header {
  background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
  color: white;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 15px;
}

.sidebar-widget .widget-header i {
  font-size: 1.5rem;
}

.sidebar-widget .widget-header h3 {
  margin: 0;
  font-size: 1.2rem;
  font-weight: 700;
}

.sidebar-widget .widget-content {
  padding: 25px;
}

.tips-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.tips-list li {
  display: flex;
  gap: 12px;
  align-items: flex-start;
}

.tips-list i {
  margin-top: 3px;
  flex-shrink: 0;
}

.tips-list span {
  color: var(--neutral-text);
  font-size: 0.95rem;
  line-height: 1.5;
}

.newsletter-form .form-control {
  border: 2px solid var(--neutral-medium);
  border-radius: 8px;
  padding: 12px 15px;
  font-size: 0.95rem;
  transition: all 0.3s ease;
}

.newsletter-form .form-control:focus {
  border-color: var(--primary-color);
  box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.1);
  outline: none;
}

.newsletter-form .btn-primary {
  padding: 12px;
  border-radius: 8px;
  font-weight: 600;
}

.form-text {
  text-align: center;
}

/* Popular Jobs */
.popular-jobs {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.popular-job-item {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 15px;
  background: var(--neutral-light);
  border-radius: 10px;
  text-decoration: none;
  transition: all 0.3s ease;
  border: 2px solid transparent;
}

.popular-job-item:hover {
  background: white;
  border-color: var(--primary-light);
  transform: translateX(5px);
}

.company-logo-sm {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  object-fit: contain;
  border: 2px solid var(--neutral-medium);
  padding: 3px;
  background: white;
}

.company-logo-placeholder-sm {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 1rem;
  font-weight: 700;
  border: 2px solid var(--neutral-medium);
}

.popular-job-info {
  flex: 1;
}

.popular-job-title {
  font-size: 0.95rem;
  font-weight: 700;
  color: var(--neutral-dark);
  margin-bottom: 4px;
  line-height: 1.3;
}

.popular-job-meta {
  font-size: 0.8rem;
  color: var(--neutral-text);
  opacity: 0.8;
  display: flex;
  align-items: center;
  gap: 5px;
  flex-wrap: wrap;
}

.popular-job-badge {
  color: var(--primary-color);
  font-size: 0.9rem;
  opacity: 0.7;
}

/* Categories */
.categories-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.category-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 15px;
  background: var(--neutral-light);
  border-radius: 10px;
  text-decoration: none;
  color: var(--neutral-text);
  transition: all 0.3s ease;
  border: 2px solid transparent;
}

.category-item:hover {
  background: white;
  border-color: var(--primary-light);
  color: var(--primary-dark);
  transform: translateX(5px);
}

.category-item i {
  color: var(--primary-color);
  font-size: 1.2rem;
  width: 24px;
  text-align: center;
}

.category-item span:first-of-type {
  flex: 1;
  font-weight: 600;
  font-size: 0.95rem;
}

.category-count {
  font-size: 0.85rem;
  color: var(--neutral-text);
  opacity: 0.7;
}

/* CTA Section */
.jobs-cta {
  background: linear-gradient(135deg, var(--secondary-color) 0%, var(--secondary-dark) 100%);
  color: white;
  padding: 80px 0;
  margin-top: 60px;
}

.cta-content {
  text-align: center;
  max-width: 800px;
  margin: 0 auto;
}

.cta-title {
  font-size: 2.5rem;
  font-weight: 800;
  margin-bottom: 20px;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
}

.cta-text {
  font-size: 1.2rem;
  opacity: 0.9;
  margin-bottom: 40px;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
}

.cta-actions {
  display: flex;
  gap: 20px;
  justify-content: center;
  flex-wrap: wrap;
}

.cta-actions .btn {
  padding: 15px 30px;
  border-radius: 30px;
  font-weight: 600;
  font-size: 1rem;
  display: inline-flex;
  align-items: center;
  gap: 10px;
  transition: all 0.3s ease;
}

.cta-actions .btn-light {
  background: white;
  color: var(--secondary-color);
  border: 2px solid white;
}

.cta-actions .btn-light:hover {
  background: transparent;
  color: white;
  transform: translateY(-3px);
}

.cta-actions .btn-outline-light {
  border: 2px solid white;
  background: transparent;
  color: white;
}

.cta-actions .btn-outline-light:hover {
  background: white;
  color: var(--secondary-color);
  transform: translateY(-3px);
}

/* Responsividade */
@media (max-width: 992px) {
  .header-content {
    flex-direction: column;
    text-align: center;
    gap: 20px;
  }
  
  .header-illustration {
    margin-left: 0;
    font-size: 4rem;
  }
  
  .jobs-stats {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .jobs-header {
    padding: 30px 20px;
  }
  
  .jobs-title {
    font-size: 2.2rem;
  }
  
  .search-input-group {
    flex-direction: column;
  }
  
  .search-input,
  .search-btn {
    width: 100%;
  }
  
  .quick-filters {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .sorting-bar {
    flex-direction: column;
    align-items: flex-start;
    gap: 15px;
  }
  
  .sorting-options {
    width: 100%;
  }
  
  .job-footer {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .job-actions {
    width: 100%;
    justify-content: flex-start;
  }
  
  .pagination {
    flex-wrap: wrap;
    justify-content: center;
  }
  
  .cta-title {
    font-size: 2rem;
  }
  
  .cta-actions {
    flex-direction: column;
    align-items: stretch;
  }
  
  .cta-actions .btn {
    width: 100%;
    max-width: 300px;
    margin: 0 auto;
  }
}

@media (max-width: 576px) {
  .jobs-stats {
    grid-template-columns: 1fr;
  }
  
  .stat-item {
    padding: 20px;
  }
  
  .job-company {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }
  
  .company-logo,
  .company-logo-placeholder {
    width: 50px;
    height: 50px;
    font-size: 1.2rem;
  }
  
  .job-tags {
    gap: 8px;
  }
  
  .job-tag {
    padding: 4px 10px;
    font-size: 0.8rem;
  }
  
  .page-link {
    padding: 8px 12px;
    font-size: 0.9rem;
  }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Salvar vaga
  const saveButtons = document.querySelectorAll('.save-job');
  saveButtons.forEach(button => {
    button.addEventListener('click', function() {
      const jobId = this.getAttribute('data-job-id');
      const icon = this.querySelector('i');
      
      // Toggle save state
      if (icon.classList.contains('far')) {
        // Salvar
        icon.classList.remove('far');
        icon.classList.add('fas');
        this.classList.add('saved');
        this.innerHTML = '<i class="fas fa-bookmark" style="color: var(--accent-color);"></i>';
        
        // Aqui você enviaria uma requisição AJAX para salvar a vaga
        console.log('Vaga ' + jobId + ' salva');
        
        // Feedback visual
        showToast('Vaga salva com sucesso!', 'success');
      } else {
        // Remover
        icon.classList.remove('fas');
        icon.classList.add('far');
        this.classList.remove('saved');
        this.innerHTML = '<i class="far fa-bookmark"></i>';
        
        // Aqui você enviaria uma requisição AJAX para remover a vaga
        console.log('Vaga ' + jobId + ' removida');
        
        // Feedback visual
        showToast('Vaga removida dos salvos.', 'info');
      }
    });
  });
  
  // Formulário de newsletter
  const newsletterForm = document.getElementById('jobsNewsletter');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const submitBtn = this.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      
      // Simular envio
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Processando...';
      
      setTimeout(() => {
        showToast('Inscrição realizada com sucesso!', 'success');
        this.reset();
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }, 1500);
    });
  }
  
  // Filtros avançados - mostrar/ocultar
  const filterToggle = document.querySelector('.btn-filter-toggle');
  const advancedFilters = document.getElementById('advancedFilters');
  
  if (filterToggle && advancedFilters) {
    filterToggle.addEventListener('click', function() {
      const icon = this.querySelector('i');
      if (this.getAttribute('aria-expanded') === 'true') {
        icon.classList.remove('fa-sliders-h');
        icon.classList.add('fa-chevron-up');
      } else {
        icon.classList.remove('fa-chevron-up');
        icon.classList.add('fa-sliders-h');
      }
    });
  }
  
  // Contadores animados
  const statNumbers = document.querySelectorAll('.stat-number');
  statNumbers.forEach(stat => {
    const target = parseInt(stat.textContent) || 0;
    const increment = target / 50;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if(current >= target) {
        current = target;
        clearInterval(timer);
        stat.textContent = target.toLocaleString('pt-BR');
      } else {
        stat.textContent = Math.floor(current).toLocaleString('pt-BR');
      }
    }, 30);
  });
  
  // Função para mostrar toast
  function showToast(message, type = 'info') {
    // Criar toast
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <div class="toast-content">
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'} me-2"></i>
        <span>${message}</span>
      </div>
      <button class="toast-close" onclick="this.parentElement.remove()">
        <i class="fas fa-times"></i>
      </button>
    `;
    
    // Adicionar ao corpo
    document.body.appendChild(toast);
    
    // Estilos inline
    toast.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${type === 'success' ? '#28a745' : '#17a2b8'};
      color: white;
      padding: 15px 20px;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 15px;
      z-index: 9999;
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
      animation: slideInRight 0.3s ease;
    `;
    
    toast.querySelector('.toast-close').style.cssText = `
      background: none;
      border: none;
      color: white;
      cursor: pointer;
      font-size: 1.1rem;
    `;
    
    // Remover após 4 segundos
    setTimeout(() => {
      toast.style.animation = 'slideOutRight 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }
  
  // Animar cards de vaga quando aparecem na tela
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, { threshold: 0.1 });
  
  // Observar todos os cards de vaga
  document.querySelectorAll('.job-card').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(card);
  });
  
  // Adicionar animação CSS para toast
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideInRight {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
    
    @keyframes slideOutRight {
      from {
        transform: translateX(0);
        opacity: 1;
      }
      to {
        transform: translateX(100%);
        opacity: 0;
      }
    }
  `;
  document.head.appendChild(style);
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_com_auth_fix_seed\portal\resources\views/jobs/index.blade.php ENDPATH**/ ?>