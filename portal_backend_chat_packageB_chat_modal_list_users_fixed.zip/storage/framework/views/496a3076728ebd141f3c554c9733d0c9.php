<?php $__env->startSection('title', 'Admin - Novo item da Agenda'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="section-title mb-0">Novo item da Agenda</h1>
    <a href="<?php echo e(route('admin.agenda.index')); ?>" class="btn btn-light">
        <i class="fa-solid fa-arrow-left me-1"></i> Voltar
    </a>
</div>

<div class="bg-white rounded-4 shadow-sm p-3 p-md-4">
    <form method="POST" action="<?php echo e(route('admin.agenda.store')); ?>" class="vstack gap-3" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <div class="fw-bold mb-1">Corrige os erros:</div>
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($e); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->make('admin.agenda._form', ['item' => null, 'types' => $types], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="d-flex gap-2">
            <button class="btn btn-primary"><i class="fa-solid fa-check me-1"></i> Guardar</button>
            <a href="<?php echo e(route('admin.agenda.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\portal_backend_chat_packageB_chat_modal_list_users_fixed\resources\views/admin/agenda/create.blade.php ENDPATH**/ ?>