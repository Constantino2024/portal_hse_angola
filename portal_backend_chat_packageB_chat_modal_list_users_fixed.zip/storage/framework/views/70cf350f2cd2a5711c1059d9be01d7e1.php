
<div class="avatar av-l chatify-d-flex"></div>
<p class="info-name"><?php echo e(config('chatify.name')); ?></p>
<div class="messenger-infoView-btns">
    <a href="#" class="danger delete-conversation">Apagar conversa</a>
</div>

<div class="messenger-infoView-shared">
    <p class="messenger-title"><span>Fotos partilhadas</span></p>
    <div class="shared-photos-list"></div>
</div>
<?php /**PATH C:\Users\Constantino\Downloads\portal_backend_chat_packageB_chatify_frontend_pt_hse\resources\views/vendor/Chatify/layouts/info.blade.php ENDPATH**/ ?>