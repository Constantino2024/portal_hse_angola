<?php $__env->startSection('title', 'Nova Iniciativa ESG · Parceiro'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4">
  <div>
    <h1 class="section-title mb-0">Nova iniciativa ESG</h1>
    <div class="text-muted small">Regista uma iniciativa e torna-a visível.</div>
  </div>
  <a href="<?php echo e(route('partner.esg.index')); ?>" class="btn btn-outline-secondary">
    <i class="fa-solid fa-arrow-left me-1"></i> Voltar
  </a>
</div>

<form method="POST" action="<?php echo e(route('partner.esg.store')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <?php echo $__env->make('partner.esg._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <div class="mt-4 d-flex gap-2">
    <button class="btn btn-primary">
      <i class="fa-solid fa-cloud-arrow-up me-1"></i> Publicar
    </button>
    <a href="<?php echo e(route('partner.esg.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal_backend_chat_packageB_UI_chat_start_avatar_badge_company_logo_resized_routesfix\resources\views/partner/esg/create.blade.php ENDPATH**/ ?>