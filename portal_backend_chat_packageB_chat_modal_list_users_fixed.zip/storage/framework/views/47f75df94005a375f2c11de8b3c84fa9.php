<?php $__env->startSection('title', 'Pesquisar Talentos · Banco de Talentos'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
    <div>
        <h1 class="h4 mb-1"><i class="fa-solid fa-users me-2"></i>Pesquisar Talentos</h1>
        <div class="text-muted">Filtra profissionais por nível, área, disponibilidade e província.</div>
    </div>
    <a href="<?php echo e(route('partner.needs.index')); ?>" class="btn btn-outline-secondary mt-3 mt-md-0">
        <i class="fa-solid fa-clipboard-list me-2"></i>Ver Necessidades
    </a>
</div>

<div class="card shadow-sm border-0 rounded-4 mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('partner.talents.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Nível</label>
                <select class="form-select" name="level">
                    <option value="">Todos</option>
                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k); ?>" <?php if(request('level') === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Área</label>
                <select class="form-select" name="area">
                    <option value="">Todas</option>
                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k); ?>" <?php if(request('area') === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Disponibilidade</label>
                <select class="form-select" name="availability">
                    <option value="">Todas</option>
                    <?php $__currentLoopData = $availabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k); ?>" <?php if(request('availability') === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Província</label>
                <input type="text" name="province" class="form-control" value="<?php echo e(request('province')); ?>" placeholder="Ex: Huambo">
            </div>
            <div class="col-md-9">
                <label class="form-label">Pesquisa (headline/bio)</label>
                <input type="text" name="search" class="form-control" value="<?php echo e(request('search')); ?>" placeholder="Ex: NEBOSH, ISO 45001, auditoria...">
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-accent" type="submit"><i class="fa-solid fa-filter me-2"></i>Filtrar</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <?php $__empty_1 = true; $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6 col-lg-4">
            <div class="card shadow-sm border-0 rounded-4 h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="fw-semibold"><?php echo e($p->user->name ?? 'Profissional'); ?></div>
                            <div class="text-muted small">
                                <?php echo e($levels[$p->level] ?? $p->level); ?> · <?php echo e($areas[$p->area] ?? $p->area); ?>

                            </div>
                        </div>
                        <span class="badge text-bg-light border"><?php echo e($p->province); ?></span>
                    </div>

                    <?php if($p->headline): ?>
                        <div class="mt-2"><?php echo e($p->headline); ?></div>
                    <?php endif; ?>

                    <?php if($p->bio): ?>
                        <div class="text-muted small mt-2" style="white-space: pre-wrap"><?php echo e(\Illuminate\Support\Str::limit($p->bio, 140)); ?></div>
                    <?php endif; ?>

                    <div class="mt-3 d-flex flex-wrap gap-2">
                        <span class="badge text-bg-info"><i class="fa-solid fa-clock me-1"></i><?php echo e($availabilities[$p->availability] ?? $p->availability); ?></span>
                        <?php if($p->cv_path): ?>
                            <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(asset('storage/'.$p->cv_path)); ?>" target="_blank">
                                <i class="fa-solid fa-file-arrow-down me-1"></i> CV
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="text-muted">Nenhum talento encontrado com os filtros atuais.</div>
        </div>
    <?php endif; ?>
</div>

<div class="mt-3">
    <?php echo e($profiles->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.partner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_com_auth_fix_seed\portal\resources\views/partner/talents/index.blade.php ENDPATH**/ ?>