<?php $__env->startSection('title', 'Iniciativas ESG · Parceiro'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h1 class="section-title mb-0">Iniciativas ESG</h1>
    <div class="text-muted small">Divulga iniciativas e práticas ESG da tua empresa.</div>
  </div>

  <div class="d-flex gap-2">
    <form method="GET" class="d-flex gap-2">
      <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Buscar iniciativa...">
      <button class="btn btn-outline-secondary" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>

    <a href="<?php echo e(route('partner.esg.create')); ?>" class="btn btn-primary">
      <i class="fa-solid fa-plus me-1"></i> Nova iniciativa
    </a>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-4">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover mb-0 align-middle">
        <thead class="table-light">
          <tr>
            <th style="min-width:320px;">Iniciativa</th>
            <th>Foco</th>
            <th>Local</th>
            <th class="text-center">Ativa</th>
            <th class="text-end">Ações</th>
          </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $initiative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td>
              <div class="fw-semibold"><?php echo e($initiative->title); ?></div>
              <div class="text-muted small">
                <?php if($initiative->start_date): ?> <?php echo e($initiative->start_date->format('d/m/Y')); ?> <?php endif; ?>
                <?php if($initiative->end_date): ?> — <?php echo e($initiative->end_date->format('d/m/Y')); ?> <?php endif; ?>
              </div>
            </td>
            <td><?php echo e($initiative->focus_area ?? '—'); ?></td>
            <td><?php echo e($initiative->location ?? '—'); ?></td>
            <td class="text-center">
              <?php if($initiative->is_active): ?>
                <span class="badge text-bg-success">Sim</span>
              <?php else: ?>
                <span class="badge text-bg-secondary">Não</span>
              <?php endif; ?>
            </td>
            <td class="text-end">
              <a href="<?php echo e(route('partner.esg.edit', $initiative)); ?>" class="btn btn-sm btn-outline-primary">
                <i class="fa-regular fa-pen-to-square"></i>
              </a>
              <form action="<?php echo e(route('partner.esg.destroy', $initiative)); ?>" method="POST" class="d-inline"
                    onsubmit="return confirm('Remover esta iniciativa?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-outline-danger" type="submit">
                  <i class="fa-regular fa-trash-can"></i>
                </button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="5" class="text-center text-muted py-5">
              <i class="fa-regular fa-folder-open me-2"></i> Ainda não publicaste iniciativas ESG.
            </td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="mt-3">
  <?php echo e($items->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_com_auth_fix_seed\portal\resources\views/partner/esg/index.blade.php ENDPATH**/ ?>