<?php $__env->startSection('title', 'Banco de Talentos HSE'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5 mt-8">
    <div class="row align-items-center g-4">
        <div class="col-lg-7">
            <h1 class="mb-3">Banco de Talentos <span class="text-primary">HSE</span></h1>
            <p class="lead text-muted">Um espaço onde profissionais de HSE podem criar o seu perfil e anexar CV, enquanto empresas publicam necessidades e recebem sugestões de matches automaticamente.</p>

            <div class="d-flex flex-wrap gap-2 mt-4">
                <a href="<?php echo e(route('talent.profile.edit')); ?>" class="btn btn-accent">
                    <i class="fa-solid fa-user-pen me-2"></i> Criar / Atualizar Perfil
                </a>
                <a href="<?php echo e(route('partner.talents.index')); ?>" class="btn btn-outline-primary">
                    <i class="fa-solid fa-users me-2"></i> Área Empresa (Pesquisar Talentos)
                </a>
            </div>

            <div class="mt-4">
                <div class="badge bg-light text-dark border me-2"><i class="fa-solid fa-layer-group me-1"></i> Nível: Júnior · Pleno · Sénior</div>
                <div class="badge bg-light text-dark border me-2"><i class="fa-solid fa-helmet-safety me-1"></i> Áreas: HST · Ambiente · ESG · Médico do Trabalho · QHSE</div>
                <div class="badge bg-light text-dark border"><i class="fa-solid fa-clock me-1"></i> Disponibilidade: Obra · Projecto · Permanente</div>
            </div>

            <div class="alert alert-info mt-4 mb-0">
                <i class="fa-solid fa-circle-info me-2"></i>
                Nota: este módulo já está pronto para evoluir para <strong>serviço pago para empresas</strong> (ex.: desbloqueio de CV completo, contacto direto, número de matches por mês, etc.).
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card shadow-sm rounded-4 border-0">
                <div class="card-body p-4">
                    <h5 class="mb-3"><i class="fa-solid fa-wand-magic-sparkles me-2"></i>Como funciona o match</h5>
                    <ol class="text-muted mb-0">
                        <li>Profissional cria perfil e anexa CV.</li>
                        <li>Empresa publica uma necessidade (nível, área, disponibilidade, província).</li>
                        <li>O sistema sugere perfis compatíveis automaticamente.</li>
                    </ol>
                </div>
            </div>

            <div class="card shadow-sm rounded-4 mt-3 border-0">
                <div class="card-body p-4">
                    <h6 class="mb-2">Filtros suportados</h6>
                    <ul class="text-muted mb-0">
                        <li>Nível</li>
                        <li>Área</li>
                        <li>Disponibilidade</li>
                        <li>Província</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_com_auth_fix_seed\portal\resources\views/talent/index.blade.php ENDPATH**/ ?>