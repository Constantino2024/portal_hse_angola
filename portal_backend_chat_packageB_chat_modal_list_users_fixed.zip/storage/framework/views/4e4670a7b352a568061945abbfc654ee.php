<?php $__env->startSection('title', $item->title); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4 mt-9">
    <!-- Breadcrumb e Voltar -->
    <div class="row mb-4">
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('agenda.index')); ?>" class="text-decoration-none">
                            <i class="fa-solid fa-calendar-alt me-1"></i>Agenda
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <?php echo e(Str::limit($item->title, 50)); ?>

                    </li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row g-4">
        <!-- Conteúdo Principal -->
        <div class="col-lg-8">
            <!-- Card de Cabeçalho -->
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden mb-4">
                <div class="card-header 
                    <?php if($item->type === 'webinar'): ?> bg-gradient-info
                    <?php elseif($item->type === 'workshop'): ?> bg-gradient-warning
                    <?php elseif($item->type === 'formacao'): ?> bg-gradient-success
                    <?php elseif($item->type === 'evento'): ?> bg-gradient-primary
                    <?php else: ?> bg-gradient-secondary <?php endif; ?> 
                    py-5">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <?php if($item->type === 'webinar'): ?>
                            <i class="fas fa-video fa-3x text-white opacity-75"></i>
                            <?php elseif($item->type === 'workshop'): ?>
                            <i class="fas fa-chalkboard-teacher fa-3x text-white opacity-75"></i>
                            <?php elseif($item->type === 'formacao'): ?>
                            <i class="fas fa-graduation-cap fa-3x text-white opacity-75"></i>
                            <?php elseif($item->type === 'data_internacional'): ?>
                            <i class="fas fa-globe-europe fa-3x text-white opacity-75"></i>
                            <?php else: ?>
                            <i class="fas fa-calendar-day fa-3x text-white opacity-75"></i>
                            <?php endif; ?>
                        </div>
                        <div class="flex-grow-1 ms-4">
                            <h1 class="h2 text-white mb-2"><?php echo e($item->title); ?></h1>
                            <div class="d-flex flex-wrap gap-2">
                                <span class="badge bg-white text-dark px-3 py-2 rounded-3">
                                    <?php echo e(ucfirst(str_replace('_',' ', $item->type))); ?>

                                </span>
                                <?php if($item->is_online): ?>
                                    <span class="badge bg-light text-dark px-3 py-2 rounded-3">
                                        <i class="fa-solid fa-video me-1"></i>Online
                                    </span>
                                <?php endif; ?>
                                <?php if(!$item->is_active): ?>
                                    <span class="badge bg-secondary px-3 py-2 rounded-3">
                                        <i class="fa-solid fa-eye-slash me-1"></i>Inativo
                                    </span>
                                <?php endif; ?>
                                <?php if($item->capacity !== null && ($item->available_spots ?? 0) <= 0): ?>
                                    <span class="badge bg-danger px-3 py-2 rounded-3">
                                        <i class="fa-solid fa-times-circle me-1"></i>Esgotado
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Informações do Evento -->
            <div class="card border-0 shadow-lg rounded-4 mb-4">
                <div class="card-body p-5">
                    <h2 class="h4 text-dark mb-4">
                        <i class="fa-solid fa-circle-info me-2 text-primary"></i>Informações do Evento
                    </h2>
                    
                    <div class="row g-4">
                        <!-- Data e Hora -->
                        <div class="col-md-6">
                            <div class="d-flex align-items-start">
                                <div class="bg-light rounded-circle p-3 me-3">
                                    <i class="fa-regular fa-clock fa-lg text-primary"></i>
                                </div>
                                <div>
                                    <h3 class="h6 text-muted mb-1">Data e Hora</h3>
                                    <p class="mb-1 fw-bold fs-5"><?php echo e($item->starts_at?->format('d/m/Y')); ?></p>
                                    <p class="text-muted mb-0">
                                        <?php echo e($item->starts_at?->format('H:i')); ?>

                                        <?php if($item->ends_at): ?>
                                        - <?php echo e($item->ends_at->format('H:i')); ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Localização -->
                        <div class="col-md-6">
                            <div class="d-flex align-items-start">
                                <div class="bg-light rounded-circle p-3 me-3">
                                    <i class="fa-solid fa-location-dot fa-lg text-primary"></i>
                                </div>
                                <div>
                                    <h3 class="h6 text-muted mb-1">Localização</h3>
                                    <p class="mb-1 fw-bold fs-5">
                                        <?php echo e($item->is_online ? 'Evento Online' : ($item->location ?? 'Local a confirmar')); ?>

                                    </p>
                                    <?php if(!$item->is_online && $item->location): ?>
                                    <p class="text-muted mb-0">
                                        <i class="fa-solid fa-map-marker-alt me-1"></i>Presencial
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Vagas -->
                        <?php if($item->capacity !== null): ?>
                        <div class="col-md-6">
                            <div class="d-flex align-items-start">
                                <div class="bg-light rounded-circle p-3 me-3">
                                    <i class="fa-solid fa-users fa-lg text-primary"></i>
                                </div>
                                <div class="w-100">
                                    <h3 class="h6 text-muted mb-1">Vagas</h3>
                                    <p class="mb-1 fw-bold fs-5">
                                        <?php echo e($item->available_spots ?? 0); ?> / <?php echo e($item->capacity); ?>

                                    </p>
                                    <?php
                                        $vagasDisponiveis = $item->available_spots ?? $item->capacity;
                                        $vagasTotais = $item->capacity;
                                        $porcentagem = $vagasTotais > 0 
                                            ? (($vagasTotais - $vagasDisponiveis) / $vagasTotais) * 100 
                                            : 0;
                                    ?>
                                    <div class="progress mt-2" style="height: 8px;">
                                        <div class="progress-bar 
                                            <?php if($vagasDisponiveis == 0): ?> bg-danger
                                            <?php elseif($vagasDisponiveis < $vagasTotais * 0.3): ?> bg-warning
                                            <?php else: ?> bg-success <?php endif; ?>" 
                                            role="progressbar" 
                                            style="width: <?php echo e($porcentagem); ?>%"
                                            aria-valuenow="<?php echo e($porcentagem); ?>" 
                                            aria-valuemin="0" 
                                            aria-valuemax="100">
                                        </div>
                                    </div>
                                    <small class="text-muted mt-1 d-block">
                                        <?php if($vagasDisponiveis == 0): ?>
                                            <span class="text-danger">
                                                <i class="fa-solid fa-times-circle me-1"></i>Todas as vagas preenchidas
                                            </span>
                                        <?php elseif($vagasDisponiveis < $vagasTotais * 0.3): ?>
                                            <span class="text-warning">
                                                <i class="fa-solid fa-exclamation-circle me-1"></i>Últimas vagas disponíveis
                                            </span>
                                        <?php else: ?>
                                            <span class="text-success">
                                                <i class="fa-solid fa-check-circle me-1"></i>Vagas disponíveis
                                            </span>
                                        <?php endif; ?>
                                    </small>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Status da Inscrição -->
                        <div class="col-md-6">
                            <div class="d-flex align-items-start">
                                <div class="bg-light rounded-circle p-3 me-3">
                                    <i class="fa-solid fa-clipboard-check fa-lg text-primary"></i>
                                </div>
                                <div>
                                    <h3 class="h6 text-muted mb-1">Status</h3>
                                    <p class="mb-1 fw-bold fs-5">
                                        <?php if($item->registration_enabled): ?>
                                            <?php if($item->external_registration_url): ?>
                                                <span class="text-info">
                                                    <i class="fa-solid fa-link me-1"></i>Inscrição Externa
                                                </span>
                                            <?php else: ?>
                                                <span class="text-success">
                                                    <i class="fa-solid fa-check-circle me-1"></i>Inscrições Abertas
                                                </span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-secondary">
                                                <i class="fa-solid fa-ban me-1"></i>Inscrições Encerradas
                                            </span>
                                        <?php endif; ?>
                                    </p>
                                    <small class="text-muted">
                                        <?php if($item->external_registration_url): ?>
                                            <a href="<?php echo e($item->external_registration_url); ?>" target="_blank"><?php echo e($item->external_registration_url); ?></a>
                                        <?php else: ?>
                                            Apenas para visualização
                                        <?php endif; ?>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Descrição do Evento -->
            <?php if($item->excerpt || $item->description): ?>
            <div class="card border-0 shadow-lg rounded-4">
                <div class="card-body p-5">
                    <?php if($item->excerpt): ?>
                    <div class="mb-4">
                        <h2 class="h4 text-dark mb-3">
                            <i class="fa-solid fa-quote-left me-2 text-primary"></i>Resumo
                        </h2>
                        <p class="lead text-muted mb-0"><?php echo e($item->excerpt); ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <?php if($item->description): ?>
                    <div class="<?php if($item->excerpt): ?> border-top pt-4 <?php endif; ?>">
                        <h2 class="h4 text-dark mb-3">
                            <i class="fa-solid fa-align-left me-2 text-primary"></i>Descrição Detalhada
                        </h2>
                        <div class="prose">
                            <?php echo nl2br(e($item->description)); ?>

                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar (Apenas Informação) -->
        <div class="col-lg-4">
            <!-- Card de Status -->
            <div class="card border-0 shadow-lg rounded-4 mb-4">
                <div class="card-header bg-white py-4">
                    <h3 class="h5 mb-0 text-dark">
                        <i class="fa-solid fa-eye me-2 text-primary"></i>Modo Visualização
                    </h3>
                </div>
                <div class="card-body p-4">
                    <div class="alert alert-info mb-0">
                        <div class="d-flex">
                            <i class="fa-solid fa-info-circle fa-lg me-3 mt-1"></i>
                            <div>
                                <strong>Esta página é apenas para visualização.</strong><br>
                                As funcionalidades de inscrição foram desabilitadas conforme requisitos.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card de Links Externos -->
            <?php if($item->external_registration_url || $item->website_url): ?>
            <div class="card border-0 shadow-lg rounded-4 mb-4">
                <div class="card-header bg-white py-4">
                    <h3 class="h5 mb-0 text-dark">
                        <i class="fa-solid fa-external-link-alt me-2 text-primary"></i>Links Relacionados
                    </h3>
                </div>
                <div class="card-body p-4">
                    <div class="vstack gap-3">
                        <?php if($item->external_registration_url): ?>
                        <div>
                            <label class="form-label text-muted small mb-1">Inscrição Externa</label>
                            <a href="<?php echo e($item->external_registration_url); ?>" target="_blank" 
                               class="btn btn-outline-primary w-100 d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-arrow-up-right-from-square me-2"></i>
                                Acessar Link de Inscrição
                            </a>
                            <small class="text-muted d-block mt-1">
                                Você será redirecionado para um site externo.
                            </small>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($item->website_url): ?>
                        <div>
                            <label class="form-label text-muted small mb-1">Site do Evento</label>
                            <a href="<?php echo e($item->website_url); ?>" target="_blank" 
                               class="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-globe me-2"></i>
                                Visitar Site Oficial
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Card de Outros Eventos -->
            <div class="card border-0 shadow-lg rounded-4">
                <div class="card-header bg-white py-4">
                    <h3 class="h5 mb-0 text-dark">
                        <i class="fa-solid fa-calendar-day me-2 text-primary"></i>Outros Eventos
                    </h3>
                </div>
                <div class="card-body p-4">
                    <div class="vstack gap-3">
                        <a href="<?php echo e(route('agenda.index')); ?>" class="btn btn-outline-primary rounded-3">
                            <i class="fa-solid fa-calendar-alt me-2"></i>Ver Todos os Eventos
                        </a>
                        
                        <a href="<?php echo e(route('agenda.index')); ?>?type=<?php echo e($item->type); ?>" class="btn btn-outline-secondary rounded-3">
                            <i class="fa-solid fa-filter me-2"></i>Ver Mais <?php echo e(ucfirst(str_replace('_',' ', $item->type))); ?>s
                        </a>
                        
                        <?php if($item->starts_at): ?>
                        <a href="<?php echo e(route('agenda.index')); ?>?month=<?php echo e($item->starts_at->format('Y-m')); ?>" 
                           class="btn btn-outline-secondary rounded-3">
                            <i class="fa-solid fa-calendar me-2"></i>Eventos de <?php echo e($item->starts_at->format('F Y')); ?>

                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Estilos customizados -->
<style>
    .bg-gradient-primary {
        background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
    }
    .mt-9{
        margin-top: 120px;
    }
    
    .bg-gradient-secondary {
        background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
    }
    
    .bg-gradient-info {
        background: linear-gradient(135deg, #36b9cc 0%, #258391 100%);
    }
    
    .bg-gradient-warning {
        background: linear-gradient(135deg, #f6c23e 0%, #dda20a 100%);
    }
    
    .bg-gradient-success {
        background: linear-gradient(135deg, #1cc88a 0%, #13855c 100%);
    }
    
    .rounded-4 {
        border-radius: 1rem !important;
    }
    
    .breadcrumb {
        background-color: transparent;
        padding: 0;
    }
    
    .breadcrumb-item.active {
        color: #6c757d;
    }
    
    .prose {
        line-height: 1.8;
        color: #495057;
    }
    
    .prose p {
        margin-bottom: 1.5rem;
    }
    
    .prose p:last-child {
        margin-bottom: 0;
    }
    
    .progress {
        border-radius: 10px;
        overflow: hidden;
    }
    
    .card-header {
        border-bottom: none;
    }
    
    .vstack > *:not(:last-child) {
        margin-bottom: 1rem;
    }
    
    .btn-outline-primary, .btn-outline-secondary {
        transition: all 0.3s ease;
    }
    
    .btn-outline-primary:hover, .btn-outline-secondary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
</style>

<!-- Script para melhorar experiência -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Adiciona tooltips aos badges
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Melhora links externos com ícone
    document.querySelectorAll('a[target="_blank"]').forEach(link => {
        if (!link.querySelector('.fa-external-link')) {
            link.innerHTML += ' <i class="fa-solid fa-external-link ms-1 small"></i>';
        }
    });
    
    // Adiciona efeito de hover nos cards
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transition = 'all 0.3s ease';
            this.style.boxShadow = '0 10px 25px rgba(0,0,0,0.1)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.boxShadow = '0 0.125rem 0.25rem rgba(0,0,0,0.075)';
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal_backend_chat_packageB_fixed_reverb\resources\views/agenda/show.blade.php ENDPATH**/ ?>