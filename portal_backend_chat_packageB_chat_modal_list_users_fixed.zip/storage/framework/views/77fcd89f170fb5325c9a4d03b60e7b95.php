<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Admin'); ?> · Portal HSE</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="admin-body">

<div class="admin-wrapper">

    
    <aside class="admin-sidebar">
        <div class="sidebar-header">
            <span class="logo">
                Portal <strong>HSE</strong>
            </span>
        </div>

        <nav class="sidebar-nav">

            <a href="<?php echo e(route('admin.posts.index')); ?>"
               class="sidebar-link <?php echo e(request()->routeIs('admin.posts.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-newspaper"></i>
                <span>Notícias</span>
            </a>


            <a href="<?php echo e(route('admin.jobs.index')); ?>" 
                class="sidebar-link <?php echo e(request()->routeIs('admin.jobs.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-briefcase"></i> 
                <span>Vagas HSE</span>
            </a>

            <hr>

            <a href="<?php echo e(route('home')); ?>" target="_blank" class="sidebar-link">
                <i class="fa-solid fa-globe"></i>
                <span>Ver site</span>
            </a>

        </nav>
    </aside>

    
    <main class="admin-content">

        
        <header class="admin-topbar">
            <button class="btn btn-sm btn-outline-secondary d-lg-none" id="toggleSidebar">
                <i class="fa-solid fa-bars"></i>
            </button>

            <div class="ms-auto">
                <span class="admin-user">
                    <i class="fa-regular fa-user"></i> Administrador
                </span>
            </div>
        </header>

        
        <section class="admin-page-content">
            <?php echo $__env->yieldContent('content'); ?>
        </section>

    </main>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.getElementById('toggleSidebar')?.addEventListener('click', function () {
    document.body.classList.toggle('sidebar-open');
});
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal_hse\resources\views/layouts/admin.blade.php ENDPATH**/ ?>