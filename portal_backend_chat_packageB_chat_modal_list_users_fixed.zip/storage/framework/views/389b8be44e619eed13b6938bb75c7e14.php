<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Portal HSE - <?php echo $__env->yieldContent('title', 'Início'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'Portal HSE - Notícias sobre Saúde, Segurança e Ambiente'); ?>">
    <?php echo $__env->yieldContent('meta_extra'); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
          crossorigin="anonymous" referrerpolicy="no-referrer" />

    
    <link rel="stylesheet" href="<?php echo e(asset('css/globals.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/postshow.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/portal-enhancements.css')); ?>">

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

    
    <header>
        <div class="container header-container">
            <a href="<?php echo e(route('home')); ?>" class="logo">
                <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" width="100">
                <div class="logo-text">
                    Portal <span>HSE</span>
                </div>
            </a>

            <div class="mobile-toggle" id="mobileToggle">
                <i class="fa-solid fa-bars"></i>
            </div>

            <ul class="nav-menu" id="navMenu">
                <li><a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                    <i class="fas fa-home me-1"></i> Início
                </a></li>
                <li><a href="<?php echo e(route('posts.public')); ?>" class="<?php echo e(request()->routeIs('posts.public') ? 'active' : ''); ?>">
                    <i class="fas fa-newspaper me-1"></i> Notícias
                </a></li>
                <li><a href="#">
                    <i class="fas fa-briefcase me-1"></i> Serviços
                </a></li>
                <li><a href="#">
                    <i class="fas fa-calendar-alt me-1"></i> Eventos
                </a></li>
                <li><a href="<?php echo e(route('jobs.index')); ?>" class="<?php echo e(request()->routeIs('jobs.*') ? 'active' : ''); ?>">
                    <i class="fas fa-briefcase me-1"></i> Vagas HSE
                </a></li>
                <li>
                    <form class="search-inline" action="<?php echo e(route('posts.public')); ?>" method="GET">
                        <div class="search-wrapper">
                            <input type="search"
                                   name="q"
                                   value="<?php echo e(request('q')); ?>"
                                   placeholder="Procurar notícias..."
                                   class="search-input">
                            <button type="submit" class="search-btn">
                                <i class="fa-solid fa-magnifying-glass"></i>
                            </button>
                        </div>
                    </form>
                </li>
            </ul>
        </div>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <footer id="contactos">
        
        <div class="footer-newsletter">
            <div class="container">
                <div class="newsletter-content">
                    <div class="newsletter-text">
                        <h4><i class="fas fa-envelope-open-text"></i> Fique por Dentro das Novidades HSE</h4>
                        <p>Receba conteúdo exclusivo, notícias e atualizações diretamente no seu email.</p>
                    </div>
                    <form action="<?php echo e(route('subscribers.store')); ?>" method="POST" class="newsletter-form">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="email" 
                                name="email" 
                                placeholder="Seu melhor email" 
                                required
                                class="form-control">
                            <button type="submit" class="btn btn-accent">
                                <i class="fas fa-paper-plane"></i> Subscrever
                            </button>
                        </div>
                        <small class="form-text">Não enviamos spam. Cancele a qualquer momento.</small>
                    </form>
                </div>
            </div>
        </div>

        
        <div class="footer-main">
            <div class="container">
                <div class="footer-grid">
                    
                    <div class="footer-col">
                        <div class="footer-brand">
                            <div class="footer-logo">
                                <i class="fas fa-shield-alt"></i>
                                <div>
                                    <span class="logo-main">Portal</span>
                                    <span class="logo-highlight">HSE</span>
                                </div>
                            </div>
                            <p class="footer-description">
                                Sua plataforma de referência em Saúde, Segurança e Ambiente em Angola.
                                Conteúdos técnicos, notícias e oportunidades para profissionais do setor.
                            </p>
                        </div>
                        
                        <div class="footer-social">
                            <h5>Siga-nos</h5>
                            <div class="social-icons">
                                <a href="#" class="social-icon facebook" title="Facebook">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="social-icon linkedin" title="LinkedIn">
                                    <i class="fab fa-linkedin-in"></i>
                                </a>
                                <a href="#" class="social-icon instagram" title="Instagram">
                                    <i class="fab fa-instagram"></i>
                                </a>
                                <a href="#" class="social-icon youtube" title="YouTube">
                                    <i class="fab fa-youtube"></i>
                                </a>
                                <a href="#" class="social-icon twitter" title="Twitter">
                                    <i class="fab fa-twitter"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="footer-col">
                        <h4 class="footer-title">Navegação</h4>
                        <ul class="footer-links">
                            <li>
                                <a href="<?php echo e(route('home')); ?>">
                                    <i class="fas fa-home"></i> Início
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('posts.public')); ?>">
                                    <i class="fas fa-newspaper"></i> Notícias
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('jobs.index')); ?>">
                                    <i class="fas fa-briefcase"></i> Vagas HSE
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fas fa-calendar-alt"></i> Eventos
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fas fa-book"></i> Biblioteca
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fas fa-users"></i> Comunidade
                                </a>
                            </li>
                        </ul>
                    </div>

                    
                    <div class="footer-col">
                        <h4 class="footer-title">Categorias</h4>
                        <ul class="footer-links">
                            <li><a href="#"><i class="fas fa-stethoscope"></i> Saúde Ocupacional</a></li>
                            <li><a href="#"><i class="fas fa-hard-hat"></i> Segurança no Trabalho</a></li>
                            <li><a href="#"><i class="fas fa-leaf"></i> Gestão Ambiental</a></li>
                            <li><a href="#"><i class="fas fa-gavel"></i> Legislação HSE</a></li>
                            <li><a href="#"><i class="fas fa-chart-line"></i> Indicadores</a></li>
                            <li><a href="#"><i class="fas fa-graduation-cap"></i> Formação</a></li>
                        </ul>
                    </div>

                    
                    <div class="footer-col">
                        <h4 class="footer-title">Contactos</h4>
                        <div class="contact-info">
                            <div class="contact-item">
                                <div class="contact-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="contact-details">
                                    <strong>Endereço</strong>
                                    <p>Vila Alice, Rua Arsénio Pompílio Pompeu do Carpo, nº 60 R/C</p>
                                </div>
                            </div>
                            
                            <div class="contact-item">
                                <div class="contact-icon">
                                    <i class="fas fa-phone"></i>
                                </div>
                                <div class="contact-details">
                                    <strong>Telefone</strong>
                                    <p>+244 940 532 884</p>
                                    <p>+244 939 148 686</p>
                                </div>
                            </div>
                            
                            <div class="contact-item">
                                <div class="contact-icon">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class="contact-details">
                                    <strong>Email</strong>
                                    <p>geral@portalseangola.co.ao</p>
                                    <p>suporte@portalseangola.co.ao</p>
                                </div>
                            </div>
                            
                            <div class="contact-item">
                                <div class="contact-icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div class="contact-details">
                                    <strong>Horário</strong>
                                    <p>Seg - Sex: 8h às 18h</p>
                                    <p>Sábado: 9h às 13h</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <p>&copy; <?php echo e(date('Y')); ?> Portal HSE. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    
    <?php if(session('success')): ?>
        <div class="position-fixed top-0 end-0 p-3" style="z-index: 1080;">
            <div class="toast align-items-center text-bg-success border-0 show"
                 role="alert" aria-live="assertive" aria-atomic="true" id="globalToast">
                <div class="d-flex">
                    <div class="toast-body">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo e(session('success')); ?>

                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto"
                            data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Toast
            const toastEl = document.getElementById('globalToast');
            if (toastEl) {
                const toast = new bootstrap.Toast(toastEl, { 
                    delay: 4000,
                    animation: true 
                });
                toast.show();
            }

            // Loading nos botões de formulário
            document.querySelectorAll('form').forEach(form => {
                form.addEventListener('submit', function () {
                    const btn = form.querySelector('button[type="submit"]');
                    if (btn && !btn.dataset.loadingSet) {
                        btn.dataset.loadingSet = 'true';
                        btn.dataset.originalText = btn.innerHTML;
                        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Aguarde...';
                        btn.disabled = true;
                    }
                });
            });

            // Menu mobile
            const mobileToggle = document.getElementById('mobileToggle');
            const navMenu = document.getElementById('navMenu');

            if (mobileToggle && navMenu) {
                mobileToggle.addEventListener('click', () => {
                    navMenu.classList.toggle('active');
                    mobileToggle.innerHTML = navMenu.classList.contains('active') 
                        ? '<i class="fa-solid fa-times"></i>' 
                        : '<i class="fa-solid fa-bars"></i>';
                });
            }

            // Fechar menu ao clicar em um link
            document.querySelectorAll('.nav-menu a').forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('active');
                    mobileToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
                });
            });

            // Smooth scroll para âncoras
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    if(this.getAttribute('href') === '#') return;
                    
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if(target) {
                        window.scrollTo({
                            top: target.offsetTop - 100,
                            behavior: 'smooth'
                        });
                    }
                });
            });

            // Contador de visualizações (simulado)
            const counters = document.querySelectorAll('.view-count');
            counters.forEach(counter => {
                const count = parseInt(counter.textContent);
                if(!isNaN(count) && count > 1000) {
                    counter.innerHTML = `<i class="fas fa-fire text-danger me-1"></i>${(count/1000).toFixed(1)}K visualizações`;
                }
            });
        });

        // Scroll to top button functionality
const scrollTopBtn = document.getElementById('scrollTopBtn');
if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollTopBtn.style.opacity = '1';
            scrollTopBtn.style.visibility = 'visible';
        } else {
            scrollTopBtn.style.opacity = '0';
            scrollTopBtn.style.visibility = 'hidden';
        }
    });
    
    scrollTopBtn.addEventListener('click', (e) => {
        e.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Animate footer columns on scroll
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animationPlayState = 'running';
        }
    });
}, {
    threshold: 0.1
});

document.querySelectorAll('.footer-col').forEach(col => {
    col.style.animationPlayState = 'paused';
    observer.observe(col);
});

// Newsletter form enhancement
const newsletterForm = document.querySelector('.newsletter-form');
if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
        const submitBtn = this.querySelector('button[type="submit"]');
        if (submitBtn && !submitBtn.dataset.loading) {
            submitBtn.dataset.loading = 'true';
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> A processar...';
            submitBtn.disabled = true;
        }
    });
}
    </script>
    

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal_hse\resources\views/layouts/app.blade.php ENDPATH**/ ?>