<?php
  $isEdit = isset($job);
?>

<div class="row g-3">
  <div class="col-12 col-lg-8">
    <div class="mb-3">
      <label class="form-label">Título da vaga</label>
      <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $job->title ?? '')); ?>" required>
    </div>

    <div class="row g-2">
      <div class="col-12 col-md-6">
        <label class="form-label">Empresa</label>
        <input type="text" name="company" class="form-control" value="<?php echo e(old('company', $job->company ?? '')); ?>" placeholder="(Opcional)">
      </div>
      <div class="col-12 col-md-6">
        <label class="form-label">Local</label>
        <input type="text" name="location" class="form-control" value="<?php echo e(old('location', $job->location ?? '')); ?>" placeholder="Luanda, Huambo, etc.">
      </div>
    </div>

    <div class="row g-2 mt-1">
      <div class="col-12 col-md-6">
        <label class="form-label">Tipo</label>
        <input type="text" name="type" class="form-control" value="<?php echo e(old('type', $job->type ?? '')); ?>" placeholder="Tempo integral / Contrato / Estágio...">
      </div>
      <div class="col-12 col-md-6">
        <label class="form-label">Nível</label>
        <input type="text" name="level" class="form-control" value="<?php echo e(old('level', $job->level ?? '')); ?>" placeholder="Júnior / Pleno / Sénior...">
      </div>
    </div>

    <div class="mt-3">
      <label class="form-label">Resumo (excerpt)</label>
      <textarea name="excerpt" class="form-control" rows="2" placeholder="Breve descrição"><?php echo e(old('excerpt', $job->excerpt ?? '')); ?></textarea>
    </div>

    <div class="mt-3">
      <label class="form-label">Descrição</label>
      <textarea name="description" class="form-control" rows="6" placeholder="Detalhes da vaga"><?php echo e(old('description', $job->description ?? '')); ?></textarea>
    </div>

    <div class="mt-3">
      <label class="form-label">Requisitos</label>
      <textarea name="requirements" class="form-control" rows="5" placeholder="Requisitos e competências"><?php echo e(old('requirements', $job->requirements ?? '')); ?></textarea>
    </div>
  </div>

  <div class="col-12 col-lg-4">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="card-body">
        <div class="fw-semibold mb-2">Candidatura</div>

        <div class="mb-3">
          <label class="form-label">Link de candidatura</label>
          <input type="url" name="apply_link" class="form-control" value="<?php echo e(old('apply_link', $job->apply_link ?? '')); ?>" placeholder="https://...">
        </div>

        <div class="mb-3">
          <label class="form-label">Email (opcional)</label>
          <input type="email" name="apply_email" class="form-control" value="<?php echo e(old('apply_email', $job->apply_email ?? '')); ?>" placeholder="rh@empresa.com">
        </div>

        <hr>

        <div class="form-check form-switch">
          <input class="form-check-input" type="checkbox" role="switch" id="is_active" name="is_active" value="1"
                 <?php if(old('is_active', $job->is_active ?? true)): echo 'checked'; endif; ?>>
          <label class="form-check-label" for="is_active">Ativa (visível no portal)</label>
        </div>

        <div class="text-muted small mt-3">
          <i class="fa-regular fa-circle-info me-1"></i>
          Destaque e patrocínio são geridos pelo Admin.
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_com_auth_fix_seed\portal\resources\views/partner/jobs/_form.blade.php ENDPATH**/ ?>