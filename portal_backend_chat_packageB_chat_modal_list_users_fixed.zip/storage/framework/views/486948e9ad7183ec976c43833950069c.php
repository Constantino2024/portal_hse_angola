<?php
    /** @var \App\Models\AgendaItem|null $item */
?>

<div class="row g-3">
    <div class="col-12">
        <label class="form-label">Título</label>
        <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $item->title ?? '')); ?>" required>
    </div>

    <div class="col-12 col-md-4">
        <label class="form-label">Tipo</label>
        <select name="type" class="form-select" required>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k); ?>" <?php if(old('type', $item->type ?? '')===$k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-12 col-md-4">
        <label class="form-label">Início</label>
        <input type="datetime-local" name="starts_at" class="form-control"
               value="<?php echo e(old('starts_at', isset($item) && $item->starts_at ? $item->starts_at->format('Y-m-d\TH:i') : '')); ?>" required>
    </div>

    <div class="col-12 col-md-4">
        <label class="form-label">Fim (opcional)</label>
        <input type="datetime-local" name="ends_at" class="form-control"
               value="<?php echo e(old('ends_at', isset($item) && $item->ends_at ? $item->ends_at->format('Y-m-d\TH:i') : '')); ?>">
    </div>

    <div class="col-12">
        <label class="form-label">Resumo (opcional)</label>
        <textarea name="excerpt" class="form-control" rows="2"><?php echo e(old('excerpt', $item->excerpt ?? '')); ?></textarea>
    </div>

    <div class="col-12">
        <label class="form-label">Descrição (opcional)</label>
        <textarea name="description" class="form-control" rows="7"><?php echo e(old('description', $item->description ?? '')); ?></textarea>
        <div class="form-text">Dica: podes colar texto com quebras de linha.</div>
    </div>

    <div class="col-12 col-md-6">
        <label class="form-label">Local (opcional)</label>
        <input type="text" name="location" class="form-control" value="<?php echo e(old('location', $item->location ?? '')); ?>" placeholder="Ex: Luanda, Huambo, Online...">
    </div>

    <div class="col-12 col-md-3">
        <label class="form-label">Capacidade (opcional)</label>
        <input type="number" name="capacity" class="form-control" value="<?php echo e(old('capacity', $item->capacity ?? '')); ?>" min="1" placeholder="Ilimitado">
    </div>

    <div class="col-12 col-md-3">
        <label class="form-label">Link externo (opcional)</label>
        <input type="url" name="external_registration_url" class="form-control" value="<?php echo e(old('external_registration_url', $item->external_registration_url ?? '')); ?>" placeholder="https://...">
    </div>

    

    <div class="col-12">
        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" role="switch" name="is_online" id="is_online"
                value="1" <?php if(old('is_online', $item->is_online ?? false)): echo 'checked'; endif; ?>>
            <label class="form-check-label" for="is_online">Online</label>
        </div>
        
        <div class="form-check form-switch">
            <input type="hidden" name="registration_enabled" value="0">
            <input class="form-check-input" type="checkbox" role="switch" name="registration_enabled" 
                id="registration_enabled" value="1" 
                <?php if(old('registration_enabled', $item->registration_enabled ?? true)): echo 'checked'; endif; ?>>
            <label class="form-check-label" for="registration_enabled">Inscrição direta ativada</label>
        </div>
        
        <div class="form-check form-switch">
            <input type="hidden" name="is_active" value="0">
            <input class="form-check-input" type="checkbox" role="switch" name="is_active" 
                id="is_active" value="1" 
                <?php if(old('is_active', $item->is_active ?? true)): echo 'checked'; endif; ?>>
            <label class="form-check-label" for="is_active">Ativo / Publicado</label>
        </div>
    </div>
</div><?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_com_auth_fix_seed\portal\resources\views/admin/agenda/_form.blade.php ENDPATH**/ ?>