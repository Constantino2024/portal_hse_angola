<?php
    /** @var \App\Models\CompanyNeed $need */
?>

<div class="row g-3">
    <div class="col-12">
        <label class="form-label">Título</label>
        <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $need->title)); ?>" required>
    </div>

    <div class="col-md-3">
        <label class="form-label">Nível</label>
        <select name="level" class="form-select" required>
            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k); ?>" <?php if(old('level', $need->level) === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-3">
        <label class="form-label">Área</label>
        <select name="area" class="form-select" required>
            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k); ?>" <?php if(old('area', $need->area) === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-3">
        <label class="form-label">Disponibilidade</label>
        <select name="availability" class="form-select" required>
            <?php $__currentLoopData = $availabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k); ?>" <?php if(old('availability', $need->availability) === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-3">
        <label class="form-label">Província</label>
        <input type="text" name="province" class="form-control" value="<?php echo e(old('province', $need->province)); ?>" required>
    </div>

    <div class="col-12">
        <label class="form-label">Descrição (opcional)</label>
        <textarea name="description" class="form-control" rows="5"><?php echo e(old('description', $need->description)); ?></textarea>
    </div>

    <div class="col-12">
        <div class="form-check form-switch">
            <input type="hidden" name="is_active" value="0">
            <input class="form-check-input" type="checkbox" role="switch" id="is_active" name="is_active" value="1" <?php if(old('is_active', $need->is_active ?? true)): echo 'checked'; endif; ?>>
            <label class="form-check-label" for="is_active">Ativo (gerar matches)</label>
        </div>
    </div>
</div><?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal\resources\views/partner/needs/_form.blade.php ENDPATH**/ ?>