<?php $__env->startSection('title', 'Nova Vaga · Parceiro'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4">
  <div>
    <h1 class="section-title mb-0">Nova vaga</h1>
    <div class="text-muted small">Preenche os dados e publica no portal.</div>
  </div>
  <a href="<?php echo e(route('partner.jobs.index')); ?>" class="btn btn-outline-secondary">
    <i class="fa-solid fa-arrow-left me-1"></i> Voltar
  </a>
</div>

<form method="POST" action="<?php echo e(route('partner.jobs.store')); ?>">
  <?php echo csrf_field(); ?>
  <?php echo $__env->make('partner.jobs._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <div class="mt-4 d-flex gap-2">
    <button class="btn btn-primary">
      <i class="fa-solid fa-cloud-arrow-up me-1"></i> Publicar
    </button>
    <a href="<?php echo e(route('partner.jobs.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_com_auth_fix_seed\portal\resources\views/partner/jobs/create.blade.php ENDPATH**/ ?>