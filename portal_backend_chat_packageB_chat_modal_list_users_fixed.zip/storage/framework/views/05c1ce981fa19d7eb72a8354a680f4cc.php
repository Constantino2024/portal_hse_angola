<?php $__env->startSection('title', 'Necessidades · Banco de Talentos'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
    <div>
        <h1 class="h4 mb-1"><i class="fa-solid fa-clipboard-list me-2"></i>Necessidades da Empresa</h1>
        <div class="text-muted">Publica as necessidades de recrutamento e deixa o sistema sugerir matches automaticamente.</div>
    </div>
    <a href="<?php echo e(route('partner.needs.create')); ?>" class="btn btn-accent mt-3 mt-md-0">
        <i class="fa-solid fa-plus me-2"></i>Nova necessidade
    </a>
</div>

<div class="card shadow-sm border-0 rounded-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead>
                <tr>
                    <th>Título</th>
                    <th>Nível</th>
                    <th>Área</th>
                    <th>Disponibilidade</th>
                    <th>Província</th>
                    <th>Status</th>
                    <th class="text-end">Ações</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $needs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="fw-semibold"><?php echo e($n->title); ?></td>
                        <td><?php echo e($levels[$n->level] ?? $n->level); ?></td>
                        <td><?php echo e($areas[$n->area] ?? $n->area); ?></td>
                        <td><?php echo e($availabilities[$n->availability] ?? $n->availability); ?></td>
                        <td><?php echo e($n->province); ?></td>
                        <td>
                            <?php if($n->is_active): ?>
                                <span class="badge text-bg-success"><i class="fa-solid fa-check me-1"></i>Ativo</span>
                            <?php else: ?>
                                <span class="badge text-bg-secondary">Inativo</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <a href="<?php echo e(route('partner.needs.show', $n)); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fa-solid fa-wand-magic-sparkles"></i>
                            </a>
                            <a href="<?php echo e(route('partner.needs.edit', $n)); ?>" class="btn btn-sm btn-outline-secondary">
                                <i class="fa-solid fa-pen"></i>
                            </a>
                            <form action="<?php echo e(route('partner.needs.destroy', $n)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Remover esta necessidade?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger" type="submit"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Ainda não há necessidades. Cria a primeira para ver matches.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($needs->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal\resources\views/partner/needs/index.blade.php ENDPATH**/ ?>