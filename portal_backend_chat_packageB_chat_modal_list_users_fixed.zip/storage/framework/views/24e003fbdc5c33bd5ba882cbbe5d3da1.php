

<?php $__env->startSection('title', 'Portal HSE - Saúde, Segurança e Ambiente'); ?>

<?php $__env->startSection('meta_description', 'Portal HSE: Notícias, vagas, eventos e conteúdos sobre Saúde, Segurança e Ambiente em Angola e no mundo.'); ?>

<?php $__env->startSection('content'); ?>


<?php if($featured->count()): ?>
<section class="hero-section" aria-label="Destaques do Portal HSE">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators" aria-label="Navegação do carousel">
            <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" 
                        data-bs-target="#heroCarousel" 
                        data-bs-slide-to="<?php echo e($i); ?>"
                        class="<?php echo e($i === 0 ? 'active' : ''); ?>"
                        aria-label="Slide <?php echo e($i+1); ?>"
                        aria-current="<?php echo e($i === 0 ? 'true' : 'false'); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="carousel-inner">
            <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($i === 0 ? 'active' : ''); ?>" data-bs-interval="5000">
                    <div class="hero-background">
                        <?php if($post->image_url): ?>
                            <img src="<?php echo e(asset('storage/'.$post->image_url)); ?>" 
                                 alt="<?php echo e($post->title); ?> - Portal HSE"
                                 class="hero-image"
                                 loading="lazy"
                                 width="1600"
                                 height="900"
                                 onload="this.classList.add('loaded')">
                        <?php else: ?>
                            <img src="https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=1600&q=80" 
                                 alt="Destaque HSE - Saúde, Segurança e Ambiente"
                                 class="hero-image"
                                 loading="lazy"
                                 width="1600"
                                 height="900"
                                 onload="this.classList.add('loaded')">
                        <?php endif; ?>
                        <div class="hero-overlay" aria-hidden="true"></div>
                    </div>
                    
                    <div class="hero-content">
                        <div class="container">
                            <div class="hero-tags">
                                <span class="hero-category"><?php echo e($post->category->name ?? 'Destaque'); ?></span>
                                <?php if($post->is_featured): ?>
                                    <span class="hero-featured">
                                        <i class="fas fa-star" aria-hidden="true"></i> Em Destaque
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <h1 class="hero-title"><?php echo e($post->title); ?></h1>
                            
                            <?php if($post->subtitle): ?>
                            <p class="hero-subtitle"><?php echo e($post->subtitle); ?></p>
                            <?php endif; ?>
                            
                            <div class="hero-meta">
                                <div class="meta-item" aria-label="Autor">
                                    <i class="fas fa-user-edit" aria-hidden="true"></i>
                                    <span><?php echo e($post->author_name); ?></span>
                                </div>
                                <div class="meta-item" aria-label="Data de publicação">
                                    <i class="fas fa-calendar-alt" aria-hidden="true"></i>
                                    <span><?php echo e(optional($post->published_at)->format('d \\d\\e F, Y')); ?></span>
                                </div>
                                <div class="meta-item" aria-label="Tempo de leitura">
                                    <i class="fas fa-clock" aria-hidden="true"></i>
                                    <span><?php echo e($post->reading_time ?? '5'); ?> min de leitura</span>
                                </div>
                            </div>
                            
                            <div class="hero-actions">
                                <a href="<?php echo e(route('posts.show', $post->slug)); ?>" 
                                   class="btn btn-primary btn-lg"
                                   aria-label="Ler notícia completa: <?php echo e($post->title); ?>">
                                    <i class="fas fa-newspaper me-2" aria-hidden="true"></i> 
                                    <span class="btn-text">Ler Notícia Completa</span>
                                </a>
                                
                                <?php if($post->video_url): ?>
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>#video" 
                                       class="btn btn-outline-light btn-lg"
                                       aria-label="Ver vídeo da notícia: <?php echo e($post->title); ?>">
                                        <i class="fas fa-play-circle me-2" aria-hidden="true"></i> 
                                        <span class="btn-text">Ver Vídeo</span>
                                    </a>
                                <?php endif; ?>
                                
                                <button class="btn btn-icon" 
                                        onclick="shareContent('<?php echo e($post->title); ?>', '<?php echo e(route('posts.show', $post->slug)); ?>')" 
                                        title="Compartilhar"
                                        aria-label="Compartilhar notícia">
                                    <i class="fas fa-share-alt" aria-hidden="true"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Slide anterior</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Próximo slide</span>
        </button>
    </div>
    
    
    <div class="carousel-loading" aria-hidden="true">
        <div class="spinner"></div>
    </div>
</section>
<?php endif; ?>


<section class="stats-section">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-newspaper"></i>
                </div>
                <div class="stat-content">
                    <h3 class="stat-number" data-count="<?php echo e($totalPosts ?? 1200); ?>">0</h3>
                    <p class="stat-label">Notícias Publicadas</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-content">
                    <h3 class="stat-number" data-count="<?php echo e($totalReaders ?? 8500); ?>">0</h3>
                    <p class="stat-label">Leitores Mensais</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-briefcase"></i>
                </div>
                <div class="stat-content">
                    <h3 class="stat-number" data-count="<?php echo e($totalJobs ?? 450); ?>">0</h3>
                    <p class="stat-label">Vagas Publicadas</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <div class="stat-content">
                    <h3 class="stat-number" data-count="<?php echo e($totalCourses ?? 85); ?>">0</h3>
                    <p class="stat-label">Cursos Disponíveis</p>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="ssa-section">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Áreas de Atuação</h2>
            <p class="section-subtitle">Explore os principais pilares do HSE e seus conteúdos especializados</p>
        </div>
        
        <div class="ssa-grid">
            <div class="ssa-card">
                <div class="ssa-card-header">
                    <div class="ssa-icon">
                        <i class="fas fa-heartbeat"></i>
                    </div>
                    <h3>Saúde Ocupacional</h3>
                </div>
                <div class="ssa-card-body">
                    <p>Conteúdos sobre bem-estar, medicina do trabalho, ergonomia e prevenção de doenças profissionais.</p>
                    <ul class="ssa-topics">
                        <li><i class="fas fa-check-circle"></i> PCMSO e PPRA</li>
                        <li><i class="fas fa-check-circle"></i> Ergonomia</li>
                        <li><i class="fas fa-check-circle"></i> Saúde Mental</li>
                        <li><i class="fas fa-check-circle"></i> EPIs</li>
                    </ul>
                </div>
                <div class="ssa-card-footer">
                    <a href="<?php echo e(route('posts.public')); ?>?category=saude" class="ssa-link">
                        Ver Notícias <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
            
            <div class="ssa-card featured">
                <div class="ssa-card-header">
                    <div class="ssa-icon">
                        <i class="fas fa-hard-hat"></i>
                    </div>
                    <h3>Segurança do Trabalho</h3>
                </div>
                <div class="ssa-card-body">
                    <p>Normas regulamentadoras, análise de riscos, prevenção de acidentes e gestão de segurança.</p>
                    <ul class="ssa-topics">
                        <li><i class="fas fa-check-circle"></i> NRs Aplicáveis</li>
                        <li><i class="fas fa-check-circle"></i> Análise de Riscos</li>
                        <li><i class="fas fa-check-circle"></i> CIPA</li>
                        <li><i class="fas fa-check-circle"></i> Emergências</li>
                    </ul>
                </div>
                <div class="ssa-card-footer">
                    <a href="<?php echo e(route('posts.public')); ?>?category=seguranca" class="ssa-link">
                        Ver Notícias <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
            
            <div class="ssa-card">
                <div class="ssa-card-header">
                    <div class="ssa-icon">
                        <i class="fas fa-leaf"></i>
                    </div>
                    <h3>Meio Ambiente</h3>
                </div>
                <div class="ssa-card-body">
                    <p>Sustentabilidade, gestão de resíduos, licenciamento ambiental e responsabilidade socioambiental.</p>
                    <ul class="ssa-topics">
                        <li><i class="fas fa-check-circle"></i> ISO 14001</li>
                        <li><i class="fas fa-check-circle"></i> Resíduos Sólidos</li>
                        <li><i class="fas fa-check-circle"></i> Efluentes</li>
                        <li><i class="fas fa-check-circle"></i> ESG</li>
                    </ul>
                </div>
                <div class="ssa-card-footer">
                    <a href="<?php echo e(route('posts.public')); ?>?category=ambiente" class="ssa-link">
                        Ver Notícias <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="latest-news-section">
    <div class="container">
        <div class="section-header">
            <div class="header-left">
                <h2 class="section-title">Últimas Notícias</h2>
                <p class="section-subtitle">Acompanhe as publicações mais recentes do Portal HSE</p>
            </div>
            <div class="header-right">
                <a href="<?php echo e(route('posts.public')); ?>" class="btn-view-all">
                    Ver Todas <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
        
        
        <?php if($categories->count()): ?>
        <div class="category-filters">
            <div class="filter-group">
                <button class="filter-btn active" data-category="all">Todas</button>
                <?php $__currentLoopData = $categories->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="filter-btn" data-category="<?php echo e($category->slug); ?>">
                        <i class="fas fa-folder"></i> <?php echo e($category->name); ?>

                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($categories->count() > 6): ?>
                <div class="dropdown">
                    <button class="filter-btn filter-more dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        Mais <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="dropdown-menu">
                        <?php $__currentLoopData = $categories->slice(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button class="dropdown-item filter-btn" type="button" data-category="<?php echo e($category->slug); ?>">
                                <?php echo e($category->name); ?>

                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="view-toggle">
                <button class="view-btn active" data-view="grid" title="Visualização em Grade">
                    <i class="fas fa-th-large"></i>
                </button>
                <button class="view-btn" data-view="list" title="Visualização em Lista">
                    <i class="fas fa-list"></i>
                </button>
            </div>
        </div>
        <?php endif; ?>
        
        
        <div class="news-container" id="newsContainer">
            <div class="news-grid" id="newsGrid">
                <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="news-card" data-categories="<?php echo e($post->category->slug ?? 'geral'); ?>">
                        <div class="news-card-image">
                            <a href="<?php echo e(route('posts.show', $post->slug)); ?>">
                                <?php if($post->image_url): ?>
                                    <img src="<?php echo e(asset('storage/'.$post->image_url)); ?>" 
                                         alt="<?php echo e($post->title); ?>"
                                         loading="lazy">
                                <?php else: ?>
                                    <div class="image-placeholder">
                                        <i class="fas fa-newspaper"></i>
                                    </div>
                                <?php endif; ?>
                            </a>
                            <div class="news-card-badge">
                                <span class="category-badge"><?php echo e($post->category->name ?? 'Geral'); ?></span>
                                <?php if($post->is_featured): ?>
                                    <span class="featured-badge">
                                        <i class="fas fa-star"></i> Destaque
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="news-card-content">
                            <div class="news-meta">
                                <span class="meta-item">
                                    <i class="fas fa-calendar-alt"></i>
                                    <?php echo e(optional($post->published_at)->format('d/m/Y')); ?>

                                </span>
                                <span class="meta-item">
                                    <i class="fas fa-clock"></i>
                                    <?php echo e($post->reading_time ?? '5'); ?> min
                                </span>
                                <span class="meta-item">
                                    <i class="fas fa-eye"></i>
                                    <?php echo e($post->views ?? '0'); ?>

                                </span>
                            </div>
                            
                            <h3 class="news-title">
                                <a href="<?php echo e(route('posts.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
                            </h3>
                            
                            <p class="news-excerpt"><?php echo e($post->excerpt); ?></p>
                            
                            <div class="news-author">
                                <div class="author-avatar">
                                    <i class="fas fa-user-circle"></i>
                                </div>
                                <div class="author-info">
                                    <strong><?php echo e($post->author_name); ?></strong>
                                    <span>Portal HSE</span>
                                </div>
                            </div>
                            
                            <div class="news-footer">
                                <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="read-more-btn">
                                    Ler Mais <i class="fas fa-arrow-right"></i>
                                </a>
                                <div class="news-actions">
                                    <button class="action-btn" onclick="shareContent('<?php echo e($post->title); ?>', '<?php echo e(route('posts.show', $post->slug)); ?>')" title="Compartilhar">
                                        <i class="fas fa-share-alt"></i>
                                    </button>
                                    <button class="action-btn save-btn" data-post-id="<?php echo e($post->id); ?>" title="Salvar">
                                        <i class="far fa-bookmark"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        
        <div class="load-more-container">
            <button class="btn btn-load-more" id="loadMoreBtn">
                <i class="fas fa-spinner d-none" id="loadMoreSpinner"></i>
                <span id="loadMoreText">Carregar Mais Notícias</span>
            </button>
        </div>
    </div>
</section>


<section class="featured-sidebar-section">
    <div class="container">
        <div class="row g-5">
            
            <div class="col-lg-8">
                <div class="section-header">
                    <h2 class="section-title">Notícias em Destaque</h2>
                    <p class="section-subtitle">As publicações mais relevantes e populares da semana</p>
                </div>
                
                <div class="featured-news-grid">
                    <?php $mainFeatured = $popular->first(); ?>
                    <?php if($mainFeatured): ?>
                    <article class="featured-main-card">
                        <div class="featured-image">
                            <a href="<?php echo e(route('posts.show', $mainFeatured->slug)); ?>">
                                <?php if($mainFeatured->image_url): ?>
                                    <img src="<?php echo e(asset('storage/'.$mainFeatured->image_url)); ?>" 
                                         alt="<?php echo e($mainFeatured->title); ?>"
                                         loading="lazy">
                                <?php endif; ?>
                                <div class="featured-overlay">
                                    <span class="featured-label">
                                        <i class="fas fa-crown"></i> MAIS POPULAR
                                    </span>
                                </div>
                            </a>
                        </div>
                        <div class="featured-content">
                            <div class="featured-meta">
                                <span class="category-tag"><?php echo e($mainFeatured->category->name ?? 'Destaque'); ?></span>
                                <span class="date">
                                    <i class="fas fa-calendar-alt"></i> 
                                    <?php echo e(optional($mainFeatured->published_at)->format('d \\d\\e F')); ?>

                                </span>
                            </div>
                            <h3 class="featured-title">
                                <a href="<?php echo e(route('posts.show', $mainFeatured->slug)); ?>"><?php echo e($mainFeatured->title); ?></a>
                            </h3>
                            <p class="featured-excerpt"><?php echo e($mainFeatured->excerpt); ?></p>
                            <div class="featured-stats">
                                <span class="stat">
                                    <i class="fas fa-eye"></i> <?php echo e($mainFeatured->views ?? '1.2k'); ?> visualizações
                                </span>
                                <span class="stat">
                                    <i class="fas fa-comment"></i> <?php echo e($mainFeatured->comments_count ?? '45'); ?> comentários
                                </span>
                                <span class="stat">
                                    <i class="fas fa-share"></i> <?php echo e($mainFeatured->shares ?? '120'); ?> compartilhamentos
                                </span>
                            </div>
                        </div>
                    </article>
                    <?php endif; ?>
                    
                    <div class="featured-secondary-grid">
                        <?php $__currentLoopData = $popular->slice(1)->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="featured-secondary-card">
                                <div class="featured-secondary-image">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>">
                                        <?php if($post->image_url): ?>
                                            <img src="<?php echo e(asset('storage/'.$post->image_url)); ?>" 
                                                 alt="<?php echo e($post->title); ?>"
                                                 loading="lazy">
                                        <?php endif; ?>
                                    </a>
                                    <span class="trending-badge">
                                        <i class="fas fa-fire"></i> Trending
                                    </span>
                                </div>
                                <div class="featured-secondary-content">
                                    <h4 class="featured-secondary-title">
                                        <a href="<?php echo e(route('posts.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    </h4>
                                    <div class="featured-secondary-meta">
                                        <span><?php echo e(optional($post->published_at)->format('d/m')); ?></span>
                                        <span>•</span>
                                        <span><?php echo e($post->reading_time ?? '3'); ?> min</span>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            
            
            <div class="col-lg-4">
                
                <div class="sidebar-widget newsletter-widget">
                    <div class="widget-header">
                        <i class="fas fa-envelope-open-text"></i>
                        <h3>Newsletter HSE</h3>
                    </div>
                    <div class="widget-content">
                        <p>Inscreva-se para receber as principais notícias, artigos técnicos e oportunidades de HSE.</p>
                        <form action="<?php echo e(route('subscribers.store')); ?>" method="POST" class="sidebar-newsletter-form" id="sidebarNewsletterForm">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="email" 
                                       name="email" 
                                       class="form-control" 
                                       placeholder="seu@email.com"
                                       required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-paper-plane me-2"></i> Subscrever Agora
                            </button>
                        </form>
                        <div class="newsletter-benefits">
                            <small>
                                <i class="fas fa-check-circle text-success me-1"></i> 
                                Conteúdo exclusivo semanal
                            </small>
                            <small>
                                <i class="fas fa-check-circle text-success me-1"></i> 
                                Zero spam - pode cancelar quando quiser
                            </small>
                        </div>
                    </div>
                </div>
                
                
                <div class="sidebar-widget events-widget">
                    <div class="widget-header">
                        <i class="fas fa-calendar-day"></i>
                        <h3>Próximos Eventos</h3>
                    </div>
                    <div class="widget-content">
                        <div class="event-list">
                            <div class="event-item">
                                <div class="event-date">
                                    <span class="event-day">15</span>
                                    <span class="event-month">MAR</span>
                                </div>
                                <div class="event-details">
                                    <h5>Workshop NR-35 - Trabalho em Altura</h5>
                                    <div class="event-meta">
                                        <span><i class="fas fa-clock"></i> 14h-18h</span>
                                        <span><i class="fas fa-map-marker-alt"></i> Online</span>
                                    </div>
                                </div>
                            </div>
                            <div class="event-item">
                                <div class="event-date">
                                    <span class="event-day">22</span>
                                    <span class="event-month">MAR</span>
                                </div>
                                <div class="event-details">
                                    <h5>Webinar: ESG na Prática</h5>
                                    <div class="event-meta">
                                        <span><i class="fas fa-clock"></i> 10h-12h</span>
                                        <span><i class="fas fa-map-marker-alt"></i> Luanda</span>
                                    </div>
                                </div>
                            </div>
                            <div class="event-item">
                                <div class="event-date">
                                    <span class="event-day">05</span>
                                    <span class="event-month">ABR</span>
                                </div>
                                <div class="event-details">
                                    <h5>Certificação ISO 45001</h5>
                                    <div class="event-meta">
                                        <span><i class="fas fa-clock"></i> 9h-17h</span>
                                        <span><i class="fas fa-map-marker-alt"></i> Luanda</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="btn btn-outline-primary w-100 mt-3">
                            Ver Todos os Eventos
                        </a>
                    </div>
                </div>
                
                
                <div class="sidebar-widget ads-widget">
                    <div class="widget-header">
                        <i class="fas fa-handshake"></i>
                        <h3>Nossos Parceiros</h3>
                    </div>
                    <div class="widget-content">
                        <div class="partners-grid">
                            <div class="partner-item">
                                <img src="https://via.placeholder.com/100x50/0066cc/ffffff?text=INPS" 
                                     alt="INPS" 
                                     loading="lazy">
                            </div>
                            <div class="partner-item">
                                <img src="https://via.placeholder.com/100x50/00a859/ffffff?text=SONILS" 
                                     alt="SONILS" 
                                     loading="lazy">
                            </div>
                            <div class="partner-item">
                                <img src="https://via.placeholder.com/100x50/ff6b35/ffffff?text=ENVIRONMENT" 
                                     alt="Environment Co" 
                                     loading="lazy">
                            </div>
                            <div class="partner-item">
                                <img src="https://via.placeholder.com/100x50/0066cc/ffffff?text=HSE+PRO" 
                                     alt="HSE Pro" 
                                     loading="lazy">
                            </div>
                        </div>
                        <a href="#" class="btn btn-link btn-sm w-100">
                            Torne-se Parceiro <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php if(isset($jobsFeatured) && $jobsFeatured->count()): ?>
<section class="jobs-section">
    <div class="container">
        <div class="section-header">
            <div class="header-left">
                <h2 class="section-title">Vagas em Destaque</h2>
                <p class="section-subtitle">Oportunidades profissionais em Saúde, Segurança e Ambiente</p>
            </div>
            <div class="header-right">
                <a href="<?php echo e(route('jobs.index')); ?>" class="btn-view-all">
                    Ver Todas as Vagas <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
        
        <div class="jobs-grid">
            <?php $__currentLoopData = $jobsFeatured->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="job-card <?php echo e($job->is_sponsored ? 'sponsored' : ''); ?>">
                    <?php if($job->is_sponsored): ?>
                        <div class="job-badge sponsored-badge">
                            <i class="fas fa-bolt"></i> Patrocinada
                        </div>
                    <?php endif; ?>
                    
                    <div class="job-header">
                        <div class="job-company">
                            <?php if($job->company_logo): ?>
                                <img src="<?php echo e(asset('storage/'.$job->company_logo)); ?>" 
                                     alt="<?php echo e($job->company); ?>"
                                     class="company-logo">
                            <?php else: ?>
                                <div class="company-logo-placeholder">
                                    <?php echo e(substr($job->company, 0, 2)); ?>

                                </div>
                            <?php endif; ?>
                            <div class="company-info">
                                <h4 class="company-name"><?php echo e($job->company); ?></h4>
                                <span class="job-location">
                                    <i class="fas fa-map-marker-alt"></i> <?php echo e($job->location ?? 'Remoto'); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="job-body">
                        <h3 class="job-title"><?php echo e($job->title); ?></h3>
                        <p class="job-excerpt"><?php echo e(\Illuminate\Support\Str::limit($job->description, 120)); ?></p>
                        
                        <div class="job-tags">
                            <?php if($job->job_type): ?>
                                <span class="job-tag"><?php echo e($job->job_type); ?></span>
                            <?php endif; ?>
                            <?php if($job->experience_level): ?>
                                <span class="job-tag"><?php echo e($job->experience_level); ?></span>
                            <?php endif; ?>
                            <?php if($job->salary_range): ?>
                                <span class="job-tag salary-tag">
                                    <i class="fas fa-money-bill-wave"></i> <?php echo e($job->salary_range); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="job-footer">
                        <div class="job-posted">
                            <small>
                                <i class="fas fa-clock"></i> 
                                <?php echo e(optional($job->created_at)->diffForHumans()); ?>

                            </small>
                        </div>
                        <div class="job-actions">
                            <a href="<?php echo e(route('jobs.show', $job->slug)); ?>" class="btn btn-primary btn-sm">
                                Ver Vaga
                            </a>
                            <?php if($job->apply_link): ?>
                                <a href="<?php echo e($job->apply_link); ?>" 
                                   target="_blank" 
                                   class="btn btn-success btn-sm">
                                    Candidatar
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>


<section class="video-section">
    <div class="container">
        <div class="video-container">
            <div class="video-content">
                <div class="section-header text-start">
                    <h2 class="section-title">Conheça o Portal HSE</h2>
                    <p class="section-subtitle">Assista ao nosso vídeo institucional e descubra nossa missão em promover uma cultura de segurança e saúde no trabalho em Angola.</p>
                </div>
                
                <div class="video-features">
                    <div class="feature-item">
                        <i class="fas fa-check-circle text-success"></i>
                        <span>Conteúdo técnico atualizado</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check-circle text-success"></i>
                        <span>Especialistas certificados</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check-circle text-success"></i>
                        <span>Foco na realidade angolana</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check-circle text-success"></i>
                        <span>Comunidade ativa de profissionais</span>
                    </div>
                </div>
                
                <div class="video-cta">
                    <a href="<?php echo e(route('posts.public')); ?>" class="btn btn-primary">
                        <i class="fas fa-newspaper me-2"></i> Explorar Notícias
                    </a>
                    <a href="<?php echo e(route('jobs.index')); ?>" class="btn btn-outline-primary">
                        <i class="fas fa-briefcase me-2"></i> Ver Vagas
                    </a>
                </div>
            </div>
            
            <div class="video-player">
                <div class="video-wrapper">
                    <div class="ratio ratio-16x9">
                        <iframe src="https://www.youtube.com/embed/-qA5yVWFu3U" 
                                title="Portal HSE - Vídeo Institucional"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen
                                loading="lazy"
                                id="videoFrame">
                        </iframe>
                    </div>
                    <div class="video-overlay" id="videoOverlay">
                        <button class="play-btn" id="playVideoBtn">
                            <i class="fas fa-play"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="cta-section">
    <div class="container">
        <div class="cta-content">
            <h2 class="cta-title">Junte-se à Comunidade HSE</h2>
            <p class="cta-subtitle">Participe, contribua e faça parte da evolução da cultura de Saúde, Segurança e Ambiente em Angola.</p>
            
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar Bootstrap carousel
    const heroCarousel = document.getElementById('heroCarousel');
    if (heroCarousel) {
        const carousel = new bootstrap.Carousel(heroCarousel, {
            interval: 5000,
            wrap: true,
            touch: true
        });
    }

    // Contadores animados
    const counters = document.querySelectorAll('.stat-number');
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-count')) || 0;
        const increment = target / 50;
        let current = 0;
        
        const timer = setInterval(() => {
            current += increment;
            if(current >= target) {
                current = target;
                clearInterval(timer);
                counter.textContent = target.toLocaleString('pt-BR');
            } else {
                counter.textContent = Math.floor(current).toLocaleString('pt-BR');
            }
        }, 30);
    });
    
    // Filtro de categorias
    const filterBtns = document.querySelectorAll('.filter-btn');
    const newsCards = document.querySelectorAll('.news-card');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (this.classList.contains('dropdown-item')) {
                e.preventDefault();
            }
            
            // Remove active class from all buttons
            filterBtns.forEach(b => b.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            
            // Filter news cards
            newsCards.forEach(card => {
                const cardCategories = card.getAttribute('data-categories');
                if(category === 'all' || cardCategories.includes(category)) {
                    card.style.display = 'block';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 10);
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        card.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
    
    // Alternar visualização grid/list
    const viewBtns = document.querySelectorAll('.view-btn');
    const newsGrid = document.getElementById('newsGrid');
    
    viewBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            viewBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const view = this.getAttribute('data-view');
            if (view === 'list') {
                newsGrid.classList.remove('news-grid');
                newsGrid.classList.add('news-list');
            } else {
                newsGrid.classList.remove('news-list');
                newsGrid.classList.add('news-grid');
            }
        });
    });
    
    // Load more functionality
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if(loadMoreBtn) {
        let currentPage = 1;
        let isLoading = false;
        
        loadMoreBtn.addEventListener('click', async function() {
            if (isLoading) return;
            
            isLoading = true;
            const spinner = document.getElementById('loadMoreSpinner');
            const text = document.getElementById('loadMoreText');
            
            spinner.classList.remove('d-none');
            text.textContent = 'Carregando...';
            this.disabled = true;
            
            try {
                currentPage++;
                
                // Simulate API call delay
                setTimeout(() => {
                    // In a real app, you would fetch from your API
                    // const response = await fetch(`/api/posts?page=${currentPage}`);
                    // const data = await response.json();
                    
                    // For demo, add 3 more cards
                    const newsGrid = document.getElementById('newsGrid');
                    const existingCards = document.querySelectorAll('.news-card');
                    
                    if (existingCards.length > 0) {
                        for (let i = 0; i < 3; i++) {
                            const template = existingCards[0].cloneNode(true);
                            // Update content for demo
                            const title = template.querySelector('.news-title a');
                            title.textContent = 'Nova Notícia ' + (existingCards.length + i + 1);
                            newsGrid.appendChild(template);
                        }
                    }
                    
                    spinner.classList.add('d-none');
                    text.textContent = 'Carregar Mais Notícias';
                    loadMoreBtn.disabled = false;
                    isLoading = false;
                    
                    // Hide button after 5 pages
                    if (currentPage >= 5) {
                        loadMoreBtn.style.display = 'none';
                    }
                }, 1000);
                
            } catch (error) {
                console.error('Error loading more news:', error);
                spinner.classList.add('d-none');
                text.textContent = 'Tentar Novamente';
                loadMoreBtn.disabled = false;
                isLoading = false;
            }
        });
    }
    
    // Video play button
    const playBtn = document.getElementById('playVideoBtn');
    const videoOverlay = document.getElementById('videoOverlay');
    const videoFrame = document.getElementById('videoFrame');
    
    if(playBtn && videoOverlay && videoFrame) {
        playBtn.addEventListener('click', function() {
            const src = videoFrame.src;
            if (!src.includes('autoplay=1')) {
                videoFrame.src = src.includes('?') ? src + '&autoplay=1' : src + '?autoplay=1';
            }
            videoOverlay.style.display = 'none';
        });
    }
    
    // Share functionality
    window.shareContent = function(title, url) {
        if (navigator.share) {
            navigator.share({
                title: title,
                text: 'Confira esta notícia do Portal HSE:',
                url: url
            }).then(() => {
                console.log('Conteúdo compartilhado com sucesso');
            }).catch(console.error);
        } else {
            // Fallback for browsers that don't support Web Share API
            navigator.clipboard.writeText(url).then(() => {
                alert('Link copiado para a área de transferência!');
            }).catch(err => {
                console.error('Erro ao copiar link: ', err);
            });
        }
    };
    
    // Save post functionality
    const saveBtns = document.querySelectorAll('.save-btn');
    saveBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const postId = this.getAttribute('data-post-id');
            const icon = this.querySelector('i');
            
            // Toggle save state
            if (icon.classList.contains('far')) {
                icon.classList.remove('far');
                icon.classList.add('fas');
                this.style.color = 'var(--accent-color)';
                // Here you would send an AJAX request to save the post
                console.log('Post ' + postId + ' salvo');
            } else {
                icon.classList.remove('fas');
                icon.classList.add('far');
                this.style.color = '';
                // Here you would send an AJAX request to unsave the post
                console.log('Post ' + postId + ' removido');
            }
        });
    });
    
    // Newsletter form submission
    const newsletterForm = document.getElementById('sidebarNewsletterForm');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const submitBtn = this.querySelector('button[type="submit"]');
            
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Processando...';
            
            // Simulate API call
            setTimeout(() => {
                submitBtn.innerHTML = '<i class="fas fa-check me-2"></i> Inscrito!';
                submitBtn.classList.remove('btn-primary');
                submitBtn.classList.add('btn-success');
                
                // Reset form after 2 seconds
                setTimeout(() => {
                    this.reset();
                    submitBtn.innerHTML = '<i class="fas fa-paper-plane me-2"></i> Subscrever Agora';
                    submitBtn.classList.remove('btn-success');
                    submitBtn.classList.add('btn-primary');
                    submitBtn.disabled = false;
                }, 2000);
            }, 1500);
        });
    }
    
    // Scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.stat-card, .ssa-card, .news-card, .job-card').forEach(el => {
        observer.observe(el);
    });
    
    // Back to top functionality
    const backToTop = document.createElement('a');
    backToTop.href = '#top';
    backToTop.className = 'back-to-top';
    backToTop.innerHTML = '<i class="fas fa-chevron-up"></i>';
    document.body.appendChild(backToTop);
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 500) {
            backToTop.classList.add('show');
        } else {
            backToTop.classList.remove('show');
        }
    });
    
    backToTop.addEventListener('click', (e) => {
        e.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});

// No seu script do home.blade.php, adicione:
document.addEventListener('DOMContentLoaded', function() {
    // Otimização do carousel
    const heroCarousel = document.getElementById('heroCarousel');
    if (heroCarousel) {
        // Inicializar carousel com opções otimizadas
        const carousel = new bootstrap.Carousel(heroCarousel, {
            interval: 5000,
            wrap: true,
            touch: true,
            pause: 'hover'
        });
        
        // Lazy loading otimizado para imagens
        const carouselImages = document.querySelectorAll('.hero-image');
        carouselImages.forEach(img => {
            // Carregar primeira imagem imediatamente
            if (img.closest('.carousel-item.active')) {
                img.loading = 'eager';
            } else {
                img.loading = 'lazy';
            }
        });
        
        // Preload das próximas imagens
        let preloadedImages = [];
        const preloadNextImage = () => {
            const activeIndex = Array.from(document.querySelectorAll('.carousel-item')).findIndex(item => 
                item.classList.contains('active')
            );
            const nextIndex = (activeIndex + 1) % carouselImages.length;
            
            if (!preloadedImages.includes(nextIndex)) {
                const nextImg = carouselImages[nextIndex];
                if (nextImg && !nextImg.complete) {
                    const tempImg = new Image();
                    tempImg.src = nextImg.src;
                    preloadedImages.push(nextIndex);
                }
            }
        };
        
        // Preload inicial
        preloadNextImage();
        
        // Preload ao mudar slide
        heroCarousel.addEventListener('slide.bs.carousel', preloadNextImage);
        
        // Otimização para touch
        let touchStartX = 0;
        let touchEndX = 0;
        
        heroCarousel.addEventListener('touchstart', e => {
            touchStartX = e.changedTouches[0].screenX;
        });
        
        heroCarousel.addEventListener('touchend', e => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        });
        
        function handleSwipe() {
            const swipeThreshold = 50;
            const diff = touchStartX - touchEndX;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    carousel.next(); // Swipe para esquerda
                } else {
                    carousel.prev(); // Swipe para direita
                }
            }
        }
        
        // Pause carousel quando não estiver visível
        let isVisible = true;
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                isVisible = entry.isIntersecting;
                if (isVisible) {
                    carousel.cycle();
                } else {
                    carousel.pause();
                }
            });
        }, { threshold: 0.1 });
        
        observer.observe(heroCarousel);
        
        // Otimização de performance
        const heroContent = document.querySelector('.hero-content');
        if (heroContent) {
            // Debounce para resize
            let resizeTimeout;
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(() => {
                    adjustHeroLayout();
                }, 100);
            });
            
            function adjustHeroLayout() {
                const viewportWidth = window.innerWidth;
                const viewportHeight = window.innerHeight;
                
                // Ajustar layout baseado na orientação
                if (viewportHeight < 500 && viewportWidth > viewportHeight) {
                    // Landscape mobile
                    heroContent.classList.add('landscape-mode');
                } else {
                    heroContent.classList.remove('landscape-mode');
                }
            }
            
            // Ajustar layout inicial
            adjustHeroLayout();
        }
        
        // Feedback tátil para botões
        const heroButtons = document.querySelectorAll('.hero-actions .btn');
        heroButtons.forEach(btn => {
            btn.addEventListener('touchstart', () => {
                btn.style.transform = 'scale(0.98)';
            });
            
            btn.addEventListener('touchend', () => {
                btn.style.transform = '';
            });
        });
    }
    
    // Otimização de imagens responsivas
    function optimizeImages() {
        const images = document.querySelectorAll('img');
        const viewportWidth = window.innerWidth;
        
        images.forEach(img => {
            if (img.classList.contains('hero-image')) {
                // Para hero images, usar srcset se disponível
                const currentSrc = img.src;
                if (!img.srcset && currentSrc.includes('storage/')) {
                    // Adicionar lógica para srcset se sua aplicação suportar
                    // img.srcset = `${currentSrc}?w=400 400w, ${currentSrc}?w=800 800w, ${currentSrc}?w=1200 1200w`;
                }
            }
        });
    }
    
    // Otimizar imagens no load
    window.addEventListener('load', optimizeImages);
    
    // Ajustar layout em orientação mudada
    window.addEventListener('orientationchange', () => {
        setTimeout(() => {
            optimizeImages();
            if (heroCarousel) {
                const carousel = bootstrap.Carousel.getInstance(heroCarousel);
                if (carousel) {
                    carousel.pause();
                    setTimeout(() => carousel.cycle(), 500);
                }
            }
        }, 300);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_links_chatbot\resources\views/home.blade.php ENDPATH**/ ?>