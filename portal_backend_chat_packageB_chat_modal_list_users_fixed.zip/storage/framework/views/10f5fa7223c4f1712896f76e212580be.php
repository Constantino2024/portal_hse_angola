<?php $__env->startSection('title', 'Editar Perfil HSE · Banco de Talentos'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <!-- Header -->
    <div class="row align-items-center mb-5">
        <div class="col-lg-8">
            <div class="d-flex align-items-center mb-3">
                <div class="bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                    <i class="fa-solid fa-user-pen text-primary fs-3"></i>
                </div>
                <div>
                    <h1 class="display-6 fw-bold mb-1">Editar Perfil HSE</h1>
                    <p class="text-muted mb-0">Preencha todos os campos para criar um currículo completo.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 text-lg-end">
            <div class="d-flex flex-column flex-sm-row gap-3">
                <a href="<?php echo e(route('talent.profile.show')); ?>" class="btn btn-outline-primary px-4 py-2 d-inline-flex align-items-center">
                    <i class="fa-solid fa-eye me-2"></i>
                    Ver Perfil
                </a>
                <a href="<?php echo e(route('talent.index')); ?>" class="btn btn-outline-secondary px-4 py-2 d-inline-flex align-items-center">
                    <i class="fa-solid fa-arrow-left me-2"></i>
                    Voltar
                </a>
            </div>
        </div>
    </div>

    <!-- Progresso -->
    <?php
        $profile = \App\Models\HseTalentProfile::firstOrNew(['user_id' => auth()->id()]);
        $filledFields = 0;
        $totalFields = 20;
        $fieldsToCheck = ['full_name', 'email', 'phone', 'level', 'area', 'availability', 'province', 
                         'headline', 'bio', 'cv_path', 'profile_image', 'current_position', 
                         'years_experience', 'education', 'work_experience', 'skills', 
                         'certifications', 'languages', 'preferred_areas', 'expected_salary'];
        
        foreach($fieldsToCheck as $field) {
            if (!empty($profile->$field)) $filledFields++;
        }
        
        $completionPercentage = round(($filledFields / $totalFields) * 100);
    ?>

    <div class="mb-4">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <h6 class="fw-semibold text-muted mb-0">Progresso do Currículo</h6>
            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2">
                <i class="fa-solid fa-percent me-2"></i>
                <?php echo e($completionPercentage); ?>% Completo
            </span>
        </div>
        <div class="progress rounded-pill" style="height: 10px;">
            <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo e($completionPercentage); ?>%">
                <span class="visually-hidden"><?php echo e($completionPercentage); ?>% completo</span>
            </div>
        </div>
    </div>

    <!-- Formulário Principal -->
    <div class="card border-0 shadow-lg rounded-4 overflow-hidden mb-5">
        <div class="card-header bg-primary bg-gradient bg-opacity-10 border-0 py-4">
            <h4 class="fw-bold mb-0 d-flex align-items-center">
                <i class="fa-solid fa-id-card text-primary me-3"></i>
                Currículo Profissional HSE
            </h4>
        </div>
        
        <form method="POST" action="<?php echo e(route('talent.profile.update')); ?>" enctype="multipart/form-data" class="needs-validation" novalidate>
            <?php echo csrf_field(); ?>
            
            <div class="card-body p-4 p-lg-5">
                <!-- Tabs de navegação -->
                <ul class="nav nav-pills mb-5" id="profileTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="personal-tab" data-bs-toggle="pill" data-bs-target="#personal" type="button">
                            <i class="fa-solid fa-user me-2"></i>Pessoal
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="professional-tab" data-bs-toggle="pill" data-bs-target="#professional" type="button">
                            <i class="fa-solid fa-briefcase me-2"></i>Profissional
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="education-tab" data-bs-toggle="pill" data-bs-target="#education" type="button">
                            <i class="fa-solid fa-graduation-cap me-2"></i>Formação
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="experience-tab" data-bs-toggle="pill" data-bs-target="#experience" type="button">
                            <i class="fa-solid fa-history me-2"></i>Experiência
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="documents-tab" data-bs-toggle="pill" data-bs-target="#documents" type="button">
                            <i class="fa-solid fa-file me-2"></i>Documentos
                        </button>
                    </li>
                </ul>

                <div class="tab-content" id="profileTabsContent">
                    <!-- Tab 1: Informações Pessoais -->
                    <div class="tab-pane fade show active" id="personal" role="tabpanel">
                        <h5 class="fw-bold text-primary mb-4">Informações Pessoais</h5>
                        
                        <div class="row g-4 mb-4">
                            <!-- Foto de Perfil -->
                            <div class="col-md-4">
                                <div class="text-center">
                                    <div class="position-relative d-inline-block mb-3">
                                        <?php if($profile->profile_image): ?>
                                            <img src="<?php echo e(asset('storage/' . $profile->profile_image)); ?>" 
                                                 id="profileImagePreview"
                                                 class="rounded-circle border border-4 border-primary border-opacity-25"
                                                 style="width: 150px; height: 150px; object-fit: cover; cursor: pointer;"
                                                 onclick="document.getElementById('profile_image').click()">
                                        <?php else: ?>
                                            <div id="profileImagePreview" 
                                                 class="rounded-circle border border-4 border-primary border-opacity-25 d-flex align-items-center justify-content-center bg-primary bg-opacity-10"
                                                 style="width: 150px; height: 150px; cursor: pointer;"
                                                 onclick="document.getElementById('profile_image').click()">
                                                <i class="fa-solid fa-camera text-primary fs-1"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div class="position-absolute bottom-0 end-0 bg-primary rounded-circle p-2 border border-3 border-white">
                                            <i class="fa-solid fa-camera text-white"></i>
                                        </div>
                                    </div>
                                    <input type="file" name="profile_image" id="profile_image" class="d-none" accept="image/*">
                                    <div class="form-text">Clique na imagem para alterar (JPEG, PNG, max 2MB)</div>
                                </div>
                            </div>

                            <div class="col-md-8">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">Nome Completo *</label>
                                        <input type="text" name="full_name" class="form-control" 
                                               value="<?php echo e(old('full_name', $profile->full_name)); ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">Email *</label>
                                        <input type="email" name="email" class="form-control" 
                                               value="<?php echo e(old('email', $profile->email)); ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">Telefone *</label>
                                        <input type="tel" name="phone" class="form-control" 
                                               value="<?php echo e(old('phone', $profile->phone)); ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">Data de Nascimento</label>
                                        <input type="date" name="birth_date" class="form-control" 
                                               value="<?php echo e(old('birth_date', $profile->birth_date ? $profile->birth_date->format('Y-m-d') : '')); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">Nacionalidade</label>
                                        <input type="text" name="nationality" class="form-control" 
                                               value="<?php echo e(old('nationality', $profile->nationality)); ?>" placeholder="ex: Angolana">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">Estado Civil</label>
                                        <select name="marital_status" class="form-select">
                                            <option value="">-- Selecionar --</option>
                                            <?php $__currentLoopData = $maritalStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if(old('marital_status', $profile->marital_status) === $key): echo 'selected'; endif; ?>>
                                                    <?php echo e($status); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label fw-semibold">Morada</label>
                                        <textarea name="address" class="form-control" rows="2"><?php echo e(old('address', $profile->address)); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tab 2: Informações Profissionais -->
                    <div class="tab-pane fade" id="professional" role="tabpanel">
                        <h5 class="fw-bold text-primary mb-4">Informações Profissionais</h5>
                        
                        <div class="row g-4">
                            <!-- Campos existentes -->
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Nível Profissional *</label>
                                <select name="level" class="form-select" required>
                                    <option value="" disabled selected>-- Selecione --</option>
                                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k); ?>" <?php if(old('level', $profile->level) === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Área de Atuação *</label>
                                <select name="area" class="form-select" required>
                                    <option value="" disabled selected>-- Selecione --</option>
                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k); ?>" <?php if(old('area', $profile->area) === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Disponibilidade *</label>
                                <select name="availability" class="form-select" required>
                                    <option value="" disabled selected>-- Selecione --</option>
                                    <?php $__currentLoopData = $availabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k); ?>" <?php if(old('availability', $profile->availability) === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Novos campos -->
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Cargo Atual</label>
                                <input type="text" name="current_position" class="form-control" 
                                       value="<?php echo e(old('current_position', $profile->current_position)); ?>" 
                                       placeholder="ex: Técnico de Segurança Sénior">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Anos de Experiência</label>
                                <input type="number" name="years_experience" class="form-control" 
                                       value="<?php echo e(old('years_experience', $profile->years_experience)); ?>" 
                                       min="0" max="50" placeholder="ex: 5">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Pretensão Salarial (AKZ)</label>
                                <input type="number" name="expected_salary" class="form-control" 
                                       value="<?php echo e(old('expected_salary', $profile->expected_salary)); ?>" 
                                       step="0.01" placeholder="ex: 250000.00">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Carta de Condução</label>
                                <input type="text" name="drivers_license" class="form-control" 
                                       value="<?php echo e(old('drivers_license', $profile->drivers_license)); ?>" 
                                       placeholder="ex: Categoria B">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Província *</label>
                                <select name="province" class="form-select" required>
                                    <option value="" disabled selected>-- Selecione --</option>
                                    <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($province); ?>" <?php if(old('province', $profile->province) === $province): echo 'selected'; endif; ?>><?php echo e($province); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Localização Preferida</label>
                                <input type="text" name="preferred_location" class="form-control" 
                                       value="<?php echo e(old('preferred_location', $profile->preferred_location)); ?>" 
                                       placeholder="ex: Luanda, Benguela">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-semibold">Headline Profissional</label>
                                <input type="text" name="headline" class="form-control" 
                                       value="<?php echo e(old('headline', $profile->headline)); ?>" 
                                       placeholder="Breve descrição do seu perfil profissional">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-semibold">Biografia Profissional</label>
                                <textarea name="bio" class="form-control" rows="6" 
                                          placeholder="Descreva sua experiência, objetivos, conquistas..."><?php echo e(old('bio', $profile->bio)); ?></textarea>
                                <div class="form-text">Mínimo 200 caracteres recomendado</div>
                            </div>

                            <!-- Áreas de preferência -->
                            <div class="col-12">
                                <label class="form-label fw-semibold">Áreas de Interesse</label>
                                <div class="row g-2">
                                    <?php
                                        $allAreas = ['Construção Civil', 'Mineração', 'Petróleo & Gás', 'Indústria', 
                                                    'Energia', 'Consultoria', 'Saúde', 'Transportes', 'Agricultura'];
                                        // Garantir que seja um array
                                        $selectedAreas = old('preferred_areas', $profile->preferred_areas ?? []);
                                        
                                        // Se for string (JSON), converter para array
                                        if (is_string($selectedAreas)) {
                                            $selectedAreas = json_decode($selectedAreas, true) ?: [];
                                        }
                                        
                                        // Garantir que seja array mesmo após conversão
                                        if (!is_array($selectedAreas)) {
                                            $selectedAreas = [];
                                        }
                                    ?>
                                    <?php $__currentLoopData = $allAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="preferred_areas[]" 
                                                   value="<?php echo e($area); ?>" id="area_<?php echo e($loop->index); ?>"
                                                   <?php if(in_array($area, $selectedAreas)): echo 'checked'; endif; ?>>
                                            <label class="form-check-label" for="area_<?php echo e($loop->index); ?>">
                                                <?php echo e($area); ?>

                                            </label>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <!-- Tipos de empresa preferidos -->
                            <div class="col-12">
                                <label class="form-label fw-semibold">Tipos de Empresa Preferidos</label>
                                <div class="row g-2">
                                    <?php
                                        // Garantir que seja um array
                                        $selectedCompanyTypes = old('preferred_company_types', $profile->preferred_company_types ?? []);
                                        
                                        // Se for string (JSON), converter para array
                                        if (is_string($selectedCompanyTypes)) {
                                            $selectedCompanyTypes = json_decode($selectedCompanyTypes, true) ?: [];
                                        }
                                        
                                        // Garantir que seja array mesmo após conversão
                                        if (!is_array($selectedCompanyTypes)) {
                                            $selectedCompanyTypes = [];
                                        }
                                    ?>
                                    <?php $__currentLoopData = $companyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="preferred_company_types[]" 
                                                   value="<?php echo e($type); ?>" id="type_<?php echo e($key); ?>"
                                                   <?php if(in_array($type, $selectedCompanyTypes)): echo 'checked'; endif; ?>>
                                            <label class="form-check-label" for="type_<?php echo e($key); ?>">
                                                <?php echo e($type); ?>

                                            </label>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tab 3: Formação -->
                    <div class="tab-pane fade" id="education" role="tabpanel">
                        <h5 class="fw-bold text-primary mb-4">Formação & Certificações</h5>
                        
                        <!-- Formação Académica -->
                        <div class="mb-5">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="fw-bold">Formação Académica</h6>
                                <button type="button" class="btn btn-sm btn-primary" onclick="addEducation()">
                                    <i class="fa-solid fa-plus me-2"></i>Adicionar Formação
                                </button>
                            </div>
                            
                            <div id="education-container">
                                <?php
                                    // Garantir que education seja um array
                                    $educationData = old('education', $profile->education);
                                    if (is_string($educationData)) {
                                        $educationData = json_decode($educationData, true) ?: [];
                                    }
                                    if (!is_array($educationData)) {
                                        $educationData = [];
                                    }
                                ?>
                                <?php $__currentLoopData = $educationData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card border mb-3 education-entry">
                                    <div class="card-body">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label class="form-label">Instituição *</label>
                                                <input type="text" name="education[<?php echo e($index); ?>][institution]" 
                                                       class="form-control" value="<?php echo e($edu['institution'] ?? ''); ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Grau/Certificado *</label>
                                                <input type="text" name="education[<?php echo e($index); ?>][degree]" 
                                                       class="form-control" value="<?php echo e($edu['degree'] ?? ''); ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Área de Estudo</label>
                                                <input type="text" name="education[<?php echo e($index); ?>][field]" 
                                                       class="form-control" value="<?php echo e($edu['field'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-3">
                                                <label class="form-label">Data Início</label>
                                                <input type="date" name="education[<?php echo e($index); ?>][start_date]" 
                                                       class="form-control" value="<?php echo e($edu['start_date'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-3">
                                                <label class="form-label">Data Conclusão</label>
                                                <input type="date" name="education[<?php echo e($index); ?>][end_date]" 
                                                       class="form-control" value="<?php echo e($edu['end_date'] ?? ''); ?>">
                                            </div>
                                            <div class="col-12">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="education[<?php echo e($index); ?>][current]" value="1"
                                                           <?php if($edu['current'] ?? false): echo 'checked'; endif; ?>>
                                                    <label class="form-check-label">Ainda estou a estudar</label>
                                                </div>
                                            </div>
                                            <div class="col-12 text-end">
                                                <button type="button" class="btn btn-sm btn-danger" onclick="removeEntry(this)">
                                                    <i class="fa-solid fa-trash me-2"></i>Remover
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Certificações -->
                        <div>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="fw-bold">Certificações</h6>
                                <button type="button" class="btn btn-sm btn-primary" onclick="addCertification()">
                                    <i class="fa-solid fa-plus me-2"></i>Adicionar Certificação
                                </button>
                            </div>
                            
                            <div id="certifications-container">
                                <?php
                                    // Garantir que certifications seja um array
                                    $certificationsData = old('certifications', $profile->certifications);
                                    if (is_string($certificationsData)) {
                                        $certificationsData = json_decode($certificationsData, true) ?: [];
                                    }
                                    if (!is_array($certificationsData)) {
                                        $certificationsData = [];
                                    }
                                ?>
                                <?php $__currentLoopData = $certificationsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card border mb-3 certification-entry">
                                    <div class="card-body">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label class="form-label">Nome da Certificação *</label>
                                                <input type="text" name="certifications[<?php echo e($index); ?>][name]" 
                                                       class="form-control" value="<?php echo e($cert['name'] ?? ''); ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Emissor *</label>
                                                <input type="text" name="certifications[<?php echo e($index); ?>][issuer]" 
                                                       class="form-control" value="<?php echo e($cert['issuer'] ?? ''); ?>" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label">Data Emissão</label>
                                                <input type="date" name="certifications[<?php echo e($index); ?>][issue_date]" 
                                                       class="form-control" value="<?php echo e($cert['issue_date'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label">Data Validade</label>
                                                <input type="date" name="certifications[<?php echo e($index); ?>][expiry_date]" 
                                                       class="form-control" value="<?php echo e($cert['expiry_date'] ?? ''); ?>">
                                            </div>
                                            <div class="col-12 text-end">
                                                <button type="button" class="btn btn-sm btn-danger" onclick="removeEntry(this)">
                                                    <i class="fa-solid fa-trash me-2"></i>Remover
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Idiomas -->
                        <div class="mt-5">
                            <h6 class="fw-bold mb-3">Idiomas</h6>
                            <div id="languages-container">
                                <?php
                                    // Garantir que languages seja um array
                                    $languagesData = old('languages', $profile->languages);
                                    if (is_string($languagesData)) {
                                        $languagesData = json_decode($languagesData, true) ?: [];
                                    }
                                    if (!is_array($languagesData)) {
                                        $languagesData = [];
                                    }
                                ?>
                                <?php $__currentLoopData = $languagesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card border mb-3 language-entry">
                                    <div class="card-body">
                                        <div class="row g-3">
                                            <div class="col-md-4">
                                                <label class="form-label">Idioma *</label>
                                                <input type="text" name="languages[<?php echo e($index); ?>][language]" 
                                                       class="form-control" value="<?php echo e($lang['language'] ?? ''); ?>" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label">Nível *</label>
                                                <select name="languages[<?php echo e($index); ?>][level]" class="form-select" required>
                                                    <option value="">-- Selecionar --</option>
                                                    <option value="basico" <?php if(($lang['level'] ?? '') === 'basico'): echo 'selected'; endif; ?>>Básico</option>
                                                    <option value="intermedio" <?php if(($lang['level'] ?? '') === 'intermedio'): echo 'selected'; endif; ?>>Intermediário</option>
                                                    <option value="avancado" <?php if(($lang['level'] ?? '') === 'avancado'): echo 'selected'; endif; ?>>Avançado</option>
                                                    <option value="fluente" <?php if(($lang['level'] ?? '') === 'fluente'): echo 'selected'; endif; ?>>Fluente</option>
                                                    <option value="nativo" <?php if(($lang['level'] ?? '') === 'nativo'): echo 'selected'; endif; ?>>Nativo</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4 d-flex align-items-end">
                                                <button type="button" class="btn btn-sm btn-danger w-100" onclick="removeEntry(this)">
                                                    <i class="fa-solid fa-trash me-2"></i>Remover
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="addLanguage()">
                                <i class="fa-solid fa-plus me-2"></i>Adicionar Idioma
                            </button>
                        </div>
                    </div>

                    <!-- Tab 4: Experiência Profissional -->
                    <div class="tab-pane fade" id="experience" role="tabpanel">
                        <h5 class="fw-bold text-primary mb-4">Experiência Profissional</h5>
                        
                        <div class="mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="fw-bold">Histórico Profissional</h6>
                                <button type="button" class="btn btn-sm btn-primary" onclick="addExperience()">
                                    <i class="fa-solid fa-plus me-2"></i>Adicionar Experiência
                                </button>
                            </div>
                            
                            <div id="experience-container">
                                <?php
                                    // Garantir que work_experience seja um array
                                    $experienceData = old('work_experience', $profile->work_experience);
                                    if (is_string($experienceData)) {
                                        $experienceData = json_decode($experienceData, true) ?: [];
                                    }
                                    if (!is_array($experienceData)) {
                                        $experienceData = [];
                                    }
                                ?>
                                <?php $__currentLoopData = $experienceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card border mb-3 experience-entry">
                                    <div class="card-body">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label class="form-label">Empresa *</label>
                                                <input type="text" name="work_experience[<?php echo e($index); ?>][company]" 
                                                       class="form-control" value="<?php echo e($exp['company'] ?? ''); ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Cargo *</label>
                                                <input type="text" name="work_experience[<?php echo e($index); ?>][position]" 
                                                       class="form-control" value="<?php echo e($exp['position'] ?? ''); ?>" required>
                                            </div>
                                            <div class="col-md-3">
                                                <label class="form-label">Data Início</label>
                                                <input type="date" name="work_experience[<?php echo e($index); ?>][start_date]" 
                                                       class="form-control" value="<?php echo e($exp['start_date'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-3">
                                                <label class="form-label">Data Término</label>
                                                <input type="date" name="work_experience[<?php echo e($index); ?>][end_date]" 
                                                       class="form-control" value="<?php echo e($exp['end_date'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-check pt-4">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="work_experience[<?php echo e($index); ?>][current]" value="1"
                                                           <?php if($exp['current'] ?? false): echo 'checked'; endif; ?>>
                                                    <label class="form-check-label">Trabalho Atual</label>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <label class="form-label">Descrição das Funções</label>
                                                <textarea name="work_experience[<?php echo e($index); ?>][description]" 
                                                          class="form-control" rows="3"><?php echo e($exp['description'] ?? ''); ?></textarea>
                                            </div>
                                            <div class="col-12 text-end">
                                                <button type="button" class="btn btn-sm btn-danger" onclick="removeEntry(this)">
                                                    <i class="fa-solid fa-trash me-2"></i>Remover
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Habilidades -->
                        <div>
                            <h6 class="fw-bold mb-3">Habilidades Técnicas</h6>
                            <div id="skills-container">
                                <?php
                                    // Garantir que seja um array
                                    $profileSkills = old('skills', $profile->skills ?? []);
                                    
                                    // Se for string (JSON), converter para array
                                    if (is_string($profileSkills)) {
                                        $profileSkills = json_decode($profileSkills, true) ?: [];
                                    }
                                    
                                    // Garantir que seja array mesmo após conversão
                                    if (!is_array($profileSkills)) {
                                        $profileSkills = [];
                                    }
                                ?>
                                <?php $__currentLoopData = $profileSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="input-group mb-2 skill-entry">
                                    <input type="text" name="skills[]" class="form-control" 
                                           value="<?php echo e(is_string($skill) ? $skill : ''); ?>" placeholder="ex: Auditorias HSE, Gestão de Riscos">
                                    <button type="button" class="btn btn-outline-danger" onclick="removeSkill(this)">
                                        <i class="fa-solid fa-times"></i>
                                    </button>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="addSkill()">
                                <i class="fa-solid fa-plus me-2"></i>Adicionar Habilidade
                            </button>
                        </div>
                    </div>

                    <!-- Tab 5: Documentos -->
                    <div class="tab-pane fade" id="documents" role="tabpanel">
                        <h5 class="fw-bold text-primary mb-4">Documentos</h5>
                        
                        <div class="row g-4">
                            <!-- Upload de CV -->
                            <div class="col-md-8">
                                <label class="form-label fw-semibold">Curriculum Vitae (PDF/DOC/DOCX)</label>
                                <div class="input-group">
                                    <input type="file" name="cv" class="form-control" 
                                           accept=".pdf,.doc,.docx" id="cvUpload">
                                    <button class="btn btn-outline-primary" type="button" onclick="document.getElementById('cvUpload').click()">
                                        <i class="fa-solid fa-upload me-2"></i>Escolher Arquivo
                                    </button>
                                </div>
                                <div class="form-text">Tamanho máximo: 5MB. Formatos aceites: PDF, DOC, DOCX</div>
                                
                                <?php if($profile->cv_path): ?>
                                <div class="alert alert-success bg-success bg-opacity-10 border-success border-opacity-25 mt-3 p-3 rounded-3">
                                    <div class="d-flex align-items-center">
                                        <i class="fa-solid fa-check-circle text-success fs-4 me-3"></i>
                                        <div>
                                            <div class="fw-bold mb-1">CV já carregado</div>
                                            <a href="<?php echo e(asset('storage/'.$profile->cv_path)); ?>" target="_blank" class="btn btn-sm btn-outline-success">
                                                <i class="fa-solid fa-eye me-2"></i>Visualizar
                                            </a>
                                            <a href="<?php echo e(asset('storage/'.$profile->cv_path)); ?>" download class="btn btn-sm btn-outline-primary ms-2">
                                                <i class="fa-solid fa-download me-2"></i>Download
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>

                            <!-- Visibilidade do perfil -->
                            <div class="col-md-4">
                                <div class="card border-primary border-opacity-25 bg-primary bg-opacity-5 h-100">
                                    <div class="card-body">
                                        <div class="form-check form-switch mb-3">
                                            <input type="hidden" name="is_public" value="0">
                                            <input class="form-check-input" type="checkbox" role="switch" id="is_public" 
                                                   name="is_public" value="1" <?php if(old('is_public', $profile->is_public ?? true)): echo 'checked'; endif; ?> 
                                                   style="width: 3.5em; height: 1.8em;">
                                            <label class="form-check-label fw-bold" for="is_public">
                                                <i class="fa-solid fa-eye text-primary me-2"></i>
                                                Perfil Visível
                                            </label>
                                        </div>
                                        <p class="text-muted small mb-0">
                                            <i class="fa-solid fa-lightbulb me-1"></i>
                                            Desative para manter seu perfil privado. Apenas você poderá visualizá-lo.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Botões de ação -->
            <div class="card-footer bg-light border-0 py-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="fw-bold text-muted mb-1">Pronto para ser encontrado?</h6>
                        <p class="text-muted small mb-0">Seu perfil será incluído nas buscas automáticas das empresas.</p>
                    </div>
                    <div class="d-flex gap-3">
                        <button type="reset" class="btn btn-outline-secondary px-4 py-3">
                            <i class="fa-solid fa-rotate-left me-2"></i>Limpar
                        </button>
                        <button type="submit" class="btn btn-primary px-5 py-3 fw-bold shadow-sm">
                            <i class="fa-solid fa-floppy-disk me-2"></i>Salvar Perfil
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- Dicas -->
    <div class="card border-0 shadow-sm border-start-4 border-accent rounded-4">
        <div class="card-body p-4">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h5 class="fw-bold d-flex align-items-center mb-3">
                        <i class="fa-solid fa-lightbulb text-accent fs-3 me-3"></i>
                        Dicas para um currículo atrativo
                    </h5>
                    <ul class="text-muted mb-0">
                        <li class="mb-2">Use uma foto profissional e atualizada</li>
                        <li class="mb-2">Descreva suas experiências com detalhes e resultados alcançados</li>
                        <li class="mb-2">Mantenha seu CV atualizado com certificações recentes</li>
                        <li class="mb-0">Selecione filtros precisos para receber matches relevantes</li>
                    </ul>
                </div>
                <div class="col-md-4 text-md-end mt-3 mt-md-0">
                    <div class="badge bg-accent bg-opacity-10 text-accent border border-accent border-opacity-25 fs-6 px-4 py-3">
                        <i class="fa-solid fa-chart-line me-2"></i>
                        +80% de matches
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.nav-pills .nav-link {
    padding: 0.75rem 1.5rem;
    color: var(--bs-secondary);
    font-weight: 600;
    border-radius: 0.5rem;
    margin-right: 0.5rem;
    margin-bottom: 0.5rem;
    border: 1px solid transparent;
}

.nav-pills .nav-link.active {
    background-color: rgba(var(--bs-primary-rgb), 0.1);
    color: var(--bs-primary);
    border: 1px solid rgba(var(--bs-primary-rgb), 0.25);
}

.form-control:focus, .form-select:focus {
    border-color: var(--bs-primary);
    box-shadow: 0 0 0 0.25rem rgba(var(--bs-primary-rgb), 0.15);
}

.btn-primary {
    background: linear-gradient(135deg, var(--bs-primary) 0%, #0056b3 100%);
    border: none;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 86, 179, 0.3);
}

.rounded-4 {
    border-radius: 1.5rem !important;
}

.text-accent {
    color: #20c997 !important;
}

.bg-accent {
    background-color: #20c997 !important;
}

.border-accent {
    border-color: #20c997 !important;
}

.form-switch .form-check-input:checked {
    background-color: var(--bs-primary);
    border-color: var(--bs-primary);
}

.card {
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-2px);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Preview da imagem de perfil
    const profileImageInput = document.getElementById('profile_image');
    const profileImagePreview = document.getElementById('profileImagePreview');
    
    if (profileImageInput) {
        profileImageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    if (profileImagePreview.tagName === 'IMG') {
                        profileImagePreview.src = e.target.result;
                    } else {
                        // Criar elemento img se for div
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.className = 'rounded-circle border border-4 border-primary border-opacity-25';
                        img.style.width = '150px';
                        img.style.height = '150px';
                        img.style.objectFit = 'cover';
                        img.style.cursor = 'pointer';
                        img.onclick = () => profileImageInput.click();
                        
                        profileImagePreview.parentNode.replaceChild(img, profileImagePreview);
                        img.id = 'profileImagePreview';
                    }
                }
                reader.readAsDataURL(file);
            }
        });
    }

    // Validação do formulário
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
});

// Contadores dinâmicos
let educationIndex = <?php echo e(isset($educationData) && is_array($educationData) ? count($educationData) : 0); ?>;
let certificationIndex = <?php echo e(isset($certificationsData) && is_array($certificationsData) ? count($certificationsData) : 0); ?>;
let experienceIndex = <?php echo e(isset($experienceData) && is_array($experienceData) ? count($experienceData) : 0); ?>;
let languageIndex = <?php echo e(isset($languagesData) && is_array($languagesData) ? count($languagesData) : 0); ?>;

function addEducation() {
    const container = document.getElementById('education-container');
    const template = `
        <div class="card border mb-3 education-entry">
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Instituição *</label>
                        <input type="text" name="education[${educationIndex}][institution]" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Grau/Certificado *</label>
                        <input type="text" name="education[${educationIndex}][degree]" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Área de Estudo</label>
                        <input type="text" name="education[${educationIndex}][field]" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Data Início</label>
                        <input type="date" name="education[${educationIndex}][start_date]" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Data Conclusão</label>
                        <input type="date" name="education[${educationIndex}][end_date]" class="form-control">
                    </div>
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="education[${educationIndex}][current]" value="1">
                            <label class="form-check-label">Ainda estou a estudar</label>
                        </div>
                    </div>
                    <div class="col-12 text-end">
                        <button type="button" class="btn btn-sm btn-danger" onclick="removeEntry(this)">
                            <i class="fa-solid fa-trash me-2"></i>Remover
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', template);
    educationIndex++;
}

function addCertification() {
    const container = document.getElementById('certifications-container');
    const template = `
        <div class="card border mb-3 certification-entry">
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Nome da Certificação *</label>
                        <input type="text" name="certifications[${certificationIndex}][name]" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Emissor *</label>
                        <input type="text" name="certifications[${certificationIndex}][issuer]" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Data Emissão</label>
                        <input type="date" name="certifications[${certificationIndex}][issue_date]" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Data Validade</label>
                        <input type="date" name="certifications[${certificationIndex}][expiry_date]" class="form-control">
                    </div>
                    <div class="col-12 text-end">
                        <button type="button" class="btn btn-sm btn-danger" onclick="removeEntry(this)">
                            <i class="fa-solid fa-trash me-2"></i>Remover
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', template);
    certificationIndex++;
}

function addExperience() {
    const container = document.getElementById('experience-container');
    const template = `
        <div class="card border mb-3 experience-entry">
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Empresa *</label>
                        <input type="text" name="work_experience[${experienceIndex}][company]" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Cargo *</label>
                        <input type="text" name="work_experience[${experienceIndex}][position]" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Data Início</label>
                        <input type="date" name="work_experience[${experienceIndex}][start_date]" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Data Término</label>
                        <input type="date" name="work_experience[${experienceIndex}][end_date]" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <div class="form-check pt-4">
                            <input class="form-check-input" type="checkbox" name="work_experience[${experienceIndex}][current]" value="1">
                            <label class="form-check-label">Trabalho Atual</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Descrição das Funções</label>
                        <textarea name="work_experience[${experienceIndex}][description]" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="col-12 text-end">
                        <button type="button" class="btn btn-sm btn-danger" onclick="removeEntry(this)">
                            <i class="fa-solid fa-trash me-2"></i>Remover
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', template);
    experienceIndex++;
}

function addLanguage() {
    const container = document.getElementById('languages-container');
    const template = `
        <div class="card border mb-3 language-entry">
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Idioma *</label>
                        <input type="text" name="languages[${languageIndex}][language]" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Nível *</label>
                        <select name="languages[${languageIndex}][level]" class="form-select" required>
                            <option value="">-- Selecionar --</option>
                            <option value="basico">Básico</option>
                            <option value="intermedio">Intermediário</option>
                            <option value="avancado">Avançado</option>
                            <option value="fluente">Fluente</option>
                            <option value="nativo">Nativo</option>
                        </select>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="button" class="btn btn-sm btn-danger w-100" onclick="removeEntry(this)">
                            <i class="fa-solid fa-trash me-2"></i>Remover
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', template);
    languageIndex++;
}

function addSkill() {
    const container = document.getElementById('skills-container');
    const div = document.createElement('div');
    div.className = 'input-group mb-2 skill-entry';
    div.innerHTML = `
        <input type="text" name="skills[]" class="form-control" placeholder="ex: Auditorias HSE, Gestão de Riscos">
        <button type="button" class="btn btn-outline-danger" onclick="removeSkill(this)">
            <i class="fa-solid fa-times"></i>
        </button>
    `;
    container.appendChild(div);
}

function removeEntry(button) {
    const entry = button.closest('.education-entry, .certification-entry, .experience-entry, .language-entry');
    if (entry) {
        entry.remove();
    }
}

function removeSkill(button) {
    const skillEntry = button.closest('.skill-entry');
    if (skillEntry) {
        skillEntry.remove();
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal_backend_chat_packageB\resources\views/talent/profile-edit.blade.php ENDPATH**/ ?>