<?php $__env->startSection('title', 'Dashboard · Parceiro'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
      <h1 class="section-title mb-0">Dashboard</h1>
      <div class="text-muted small">Resumo das tuas publicações (vagas, ESG e projectos).</div>
    </div>
  </div>

  <div class="row g-3">
    <div class="col-12 col-md-4">
      <div class="card border-0 shadow-sm rounded-4 h-100">
        <div class="card-body">
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <div class="text-muted small">Vagas publicadas</div>
              <div class="fs-2 fw-bold"><?php echo e($jobsCount); ?></div>
              <div class="text-muted small">Ativas: <strong><?php echo e($jobsActiveCount); ?></strong></div>
            </div>
            <div class="rounded-circle bg-light d-flex align-items-center justify-content-center" style="width:54px;height:54px;">
              <i class="fa-solid fa-briefcase text-secondary"></i>
            </div>
          </div>

          <a href="<?php echo e(route('partner.jobs.index')); ?>" class="btn btn-outline-primary btn-sm mt-3">
            Gerir vagas <i class="fa-solid fa-arrow-right ms-1"></i>
          </a>
        </div>
      </div>
    </div>

    <div class="col-12 col-md-4">
      <div class="card border-0 shadow-sm rounded-4 h-100">
        <div class="card-body">
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <div class="text-muted small">Iniciativas ESG</div>
              <div class="fs-2 fw-bold"><?php echo e($esgCount); ?></div>
              <div class="text-muted small">Ativas: <strong><?php echo e($esgActiveCount); ?></strong></div>
            </div>
            <div class="rounded-circle bg-light d-flex align-items-center justify-content-center" style="width:54px;height:54px;">
              <i class="fa-solid fa-leaf text-secondary"></i>
            </div>
          </div>

          <a href="<?php echo e(route('partner.esg.index')); ?>" class="btn btn-outline-primary btn-sm mt-3">
            Gerir ESG <i class="fa-solid fa-arrow-right ms-1"></i>
          </a>
        </div>
      </div>
    </div>

    <div class="col-12 col-md-4">
      <div class="card border-0 shadow-sm rounded-4 h-100">
        <div class="card-body">
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <div class="text-muted small">Projectos</div>
              <div class="fs-2 fw-bold"><?php echo e($projectsCount); ?></div>
              <div class="text-muted small">Ativos: <strong><?php echo e($projectsActiveCount); ?></strong></div>
            </div>
            <div class="rounded-circle bg-light d-flex align-items-center justify-content-center" style="width:54px;height:54px;">
              <i class="fa-solid fa-diagram-project text-secondary"></i>
            </div>
          </div>

          <a href="<?php echo e(route('partner.projects.index')); ?>" class="btn btn-outline-primary btn-sm mt-3">
            Gerir projectos <i class="fa-solid fa-arrow-right ms-1"></i>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_com_auth_fix_seed\portal\resources\views/partner/dashboard.blade.php ENDPATH**/ ?>