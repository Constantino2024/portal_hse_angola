<?php if(session('success')): ?>
  <div class="alert alert-success alert-dismissible fade show rounded-4" role="alert">
    <i class="fa-solid fa-circle-check me-2"></i> <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="alert alert-danger rounded-4">
    <div class="fw-semibold mb-2"><i class="fa-solid fa-triangle-exclamation me-2"></i>Verifique os campos:</div>
    <ul class="mb-0">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($e); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<?php /**PATH C:\Users\Constantino\Downloads\portal_backend_chat_packageB_chatify_frontend_pt_hse\resources\views/partner/partials/alerts.blade.php ENDPATH**/ ?>