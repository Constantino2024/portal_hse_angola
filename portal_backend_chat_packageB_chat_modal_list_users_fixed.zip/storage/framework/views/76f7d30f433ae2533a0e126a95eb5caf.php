

<?php $__env->startSection('title', $post->title . ' | Portal HSE'); ?>
<?php $__env->startSection('meta_title', $post->meta_title ?? $post->title); ?>
<?php $__env->startSection('meta_description', $post->meta_description ?? $post->excerpt); ?>

<?php $__env->startSection('meta_extra'); ?>
<meta property="og:title" content="<?php echo e($post->meta_title ?? $post->title); ?>">
<meta property="og:description" content="<?php echo e($post->meta_description ?? $post->excerpt); ?>">

<?php if($post->image_url): ?>
<meta property="og:image" content="<?php echo e(asset('storage/'.$post->image_url)); ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<?php endif; ?>
<meta property="og:url" content="<?php echo e(url()->current()); ?>">
<meta property="og:type" content="article">
<meta property="article:published_time" content="<?php echo e($post->published_at); ?>">
<meta property="article:author" content="<?php echo e($post->author_name); ?>">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e($post->meta_title ?? $post->title); ?>">
<meta name="twitter:description" content="<?php echo e($post->meta_description ?? $post->excerpt); ?>">
<?php if($post->image_url): ?>
<meta name="twitter:image" content="<?php echo e(asset('storage/'.$post->image_url)); ?>">
<?php endif; ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $shareUrl = urlencode(url()->current());
    $shareTitle = urlencode($post->title);
    $shareText = urlencode($post->title . ' - Portal HSE');

    // Galeria (capa + 3 extras)
    $gallery = collect([
        $post->image_url ?? null,
        $post->image_2_url ?? null,
        $post->image_3_url ?? null,
        $post->image_4_url ?? null,
    ])->filter()->values();

    $relatedPosts = \App\Models\Post::whereNotNull('published_at')
        ->where('id', '!=', $post->id)
        ->where(function($query) use ($post) {
            $query->where('category_id', $post->category_id)
                  ->orWhere('author_name', $post->author_name);
        })
        ->latest('published_at')
        ->take(6)
        ->get();

    if ($relatedPosts->count() < 3) {
        $additionalPosts = \App\Models\Post::whereNotNull('published_at')
            ->where('id', '!=', $post->id)
            ->whereNotIn('id', $relatedPosts->pluck('id'))
            ->latest('published_at')
            ->take(6 - $relatedPosts->count())
            ->get();
        
        $relatedPosts = $relatedPosts->merge($additionalPosts);
    }

    $readingTime = $post->reading_time ?? ceil(str_word_count(strip_tags($post->body)) / 200);
?>


<nav aria-label="breadcrumb" class="breadcrumb-wrapper">
    <div class="container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Início</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('posts.public')); ?>">Notícias</a></li>
            <?php if($post->category): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('posts.public')); ?>?category=<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a></li>
            <?php endif; ?>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e(Str::limit($post->title, 50)); ?></li>
        </ol>
    </div>
</nav>

<section class="single-post-wrapper">
    <div class="container">
        <div class="row g-5">

            
            <div class="col-lg-8">

                
                <div class="post-header mb-4">
                    <div class="post-header-top">
                        <span class="category-badge"><?php echo e($post->category->name ?? 'Geral'); ?></span>
                        <?php if($post->is_featured): ?>
                            <span class="featured-badge">
                                <i class="fas fa-star"></i> Destaque
                            </span>
                        <?php endif; ?>
                        <?php if($post->is_exclusive): ?>
                            <span class="exclusive-badge">
                                <i class="fas fa-crown"></i> Exclusivo
                            </span>
                        <?php endif; ?>
                    </div>

                    <h1 class="post-title"><?php echo e($post->title); ?></h1>
                    
                    <?php if($post->subtitle): ?>
                        <h2 class="post-subtitle"><?php echo e($post->subtitle); ?></h2>
                    <?php endif; ?>

                    <div class="post-meta">
                        <div class="post-author">
                            <div class="author-avatar">
                                <?php if($post->author_photo): ?>
                                    <img src="<?php echo e(asset('storage/'.$post->author_photo)); ?>" alt="<?php echo e($post->author_name); ?>">
                                <?php else: ?>
                                    <i class="fas fa-user-circle"></i>
                                <?php endif; ?>
                            </div>
                            <div class="author-info">
                                <strong><?php echo e($post->author_name); ?></strong>
                                <span>Portal HSE</span>
                            </div>
                        </div>
                        
                        <div class="post-meta-details">
                            <div class="meta-item">
                                <i class="fas fa-calendar-alt"></i>
                                <span><?php echo e(optional($post->published_at)->format('d \\d\\e F \\d\\e Y')); ?></span>
                            </div>
                            <div class="meta-item">
                                <i class="fas fa-clock"></i>
                                <span><?php echo e($readingTime); ?> min de leitura</span>
                            </div>
                            <div class="meta-item">
                                <i class="fas fa-eye"></i>
                                <span><?php echo e($post->views ?? '0'); ?> visualizações</span>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="share-bar mb-5">
                    <div class="share-bar-content">
                        <span class="share-label">Compartilhar:</span>
                        <div class="share-buttons">
                            <a href="https://api.whatsapp.com/send?text=<?php echo e($shareText); ?>%20<?php echo e($shareUrl); ?>" 
                               target="_blank" 
                               class="share-btn whatsapp" 
                               title="Compartilhar no WhatsApp">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($shareUrl); ?>" 
                               target="_blank" 
                               class="share-btn facebook" 
                               title="Compartilhar no Facebook">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e($shareUrl); ?>" 
                               target="_blank" 
                               class="share-btn linkedin" 
                               title="Compartilhar no LinkedIn">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="https://twitter.com/intent/tweet?text=<?php echo e($shareText); ?>&url=<?php echo e($shareUrl); ?>" 
                               target="_blank" 
                               class="share-btn twitter" 
                               title="Compartilhar no X (Twitter)">
                                <i class="fab fa-x-twitter"></i>
                            </a>
                            <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e($shareUrl); ?>" 
                               target="_blank" 
                               class="share-btn email" 
                               title="Enviar por email">
                                <i class="fas fa-envelope"></i>
                            </a>
                            <button class="share-btn copy-link" 
                                    title="Copiar link" 
                                    onclick="copyToClipboard('<?php echo e(url()->current()); ?>')">
                                <i class="fas fa-link"></i>
                            </button>
                        </div>
                    </div>
                </div>

                
                <?php if($gallery->count()): ?>
                    <div class="post-gallery mb-5">
                        
                        <div class="post-featured-image">
                            <img src="<?php echo e(asset('storage/'.$gallery->first())); ?>" 
                                 alt="<?php echo e($post->title); ?>"
                                 class="featured-img"
                                 id="featuredImage"
                                 loading="eager">
                            
                            <?php if($gallery->count() > 1): ?>
                                <div class="image-counter">
                                    <i class="fas fa-images"></i> 1/<?php echo e($gallery->count()); ?>

                                </div>
                                <button class="gallery-nav prev" onclick="changeGalleryImage(-1)">
                                    <i class="fas fa-chevron-left"></i>
                                </button>
                                <button class="gallery-nav next" onclick="changeGalleryImage(1)">
                                    <i class="fas fa-chevron-right"></i>
                                </button>
                            <?php endif; ?>
                        </div>

                        
                        <?php if($gallery->count() > 1): ?>
                            <div class="gallery-thumbnails">
                                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button class="thumbnail-btn <?php echo e($index === 0 ? 'active' : ''); ?>" 
                                            onclick="showGalleryImage(<?php echo e($index); ?>)">
                                        <img src="<?php echo e(asset('storage/'.$img)); ?>" 
                                             alt="Imagem <?php echo e($index + 1); ?> da notícia"
                                             loading="lazy">
                                    </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                
                <?php if($post->video_url): ?>
                    <div class="post-video-wrapper mb-5" id="videoSection">
                        <div class="video-header">
                            <h3><i class="fas fa-play-circle"></i> Vídeo da Notícia</h3>
                            <?php if($post->video_caption): ?>
                                <p class="video-caption"><?php echo e($post->video_caption); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="video-container">
                            <div class="ratio ratio-16x9">
                                <iframe src="<?php echo e($post->video_url); ?>" 
                                        title="<?php echo e($post->title); ?>"
                                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                        allowfullscreen
                                        loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                
                <article class="post-body mb-5">
                    <div class="post-content">
                        <?php echo $post->body; ?>

                    </div>

                    
                    <?php if($post->tags): ?>
                        <div class="post-tags mt-4">
                            <strong>Tags:</strong>
                            <?php $__currentLoopData = explode(',', $post->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('posts.public')); ?>?tag=<?php echo e(trim($tag)); ?>" class="tag-link">
                                    #<?php echo e(trim($tag)); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <div class="post-footer mt-5">
                        <div class="post-footer-content">
                            <div class="post-updated">
                                <i class="fas fa-history"></i>
                                <span>Atualizado em <?php echo e($post->updated_at->format('d/m/Y H:i')); ?></span>
                            </div>
                            
                            <div class="post-actions">
                                <button class="action-btn save-btn" onclick="toggleSavePost(<?php echo e($post->id); ?>)">
                                    <i class="far fa-bookmark"></i> Salvar
                                </button>
                                <button class="action-btn print-btn" onclick="window.print()">
                                    <i class="fas fa-print"></i> Imprimir
                                </button>
                            </div>
                        </div>
                    </div>
                </article>

                
                <section class="comments-section">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-comments"></i> Comentários
                            <span class="comments-count" id="comments-total"></span>
                        </h2>
                        <p class="section-subtitle">Partilhe a sua opinião sobre esta notícia</p>
                    </div>

                    <div class="comments-container">
                        
                        <div id="comments-list" class="comments-list"></div>

                        
                        <div class="comments-pagination">
                            <button id="prev-comments" class="btn btn-pagination" disabled>
     
                            <i class="fas fa-chevron-left"></i> Anterior
                            </button>
                            
                            <div class="pagination-info">
                                <span id="comments-page-info">Página 1</span>
                            </div>
                            
                            <button id="next-comments" class="btn btn-pagination" disabled>
                                Próximo <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>

                        
                        <div class="comment-form-card">
                            <div class="form-header">
                                <h4>Deixe o seu comentário</h4>
                                <p class="form-subtitle">O seu email não será publicado. Campos obrigatórios marcados com *</p>
                            </div>

                            <form id="comment-form" action="<?php echo e(route('comments.store.ajax', $post)); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="form-grid">
                                    <div class="form-group">
                                        <label for="author_name">Nome *</label>
                                        <input type="text" 
                                               id="author_name" 
                                               name="author_name" 
                                               class="form-control" 
                                               placeholder="Seu nome" 
                                               required>
                                    </div>

                                    <div class="form-group">
                                        <label for="author_email">Email *</label>
                                        <input type="email" 
                                               id="author_email" 
                                               name="author_email" 
                                               class="form-control" 
                                               placeholder="seu@email.com" 
                                               required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="comment_body">Comentário *</label>
                                    <textarea id="comment_body" 
                                              name="body" 
                                              class="form-control" 
                                              rows="5" 
                                              placeholder="Digite seu comentário aqui..."
                                              required></textarea>
                                    <div class="char-counter">
                                        <span id="char-count">0</span> / 500 caracteres
                                    </div>
                                </div>

                                <div class="form-footer">
                                    
                                    <button type="submit" class="btn btn-primary" id="commentSubmitBtn">
                                        <i class="fas fa-paper-plane me-2"></i> Enviar comentário
                                    </button>
                                </div>

                                
                                <div id="comment-success" class="alert alert-success mt-3 d-none">
                                    <i class="fas fa-check-circle me-2"></i>
                                    Comentário enviado com sucesso! Aguarde a aprovação.
                                </div>

                                <div id="comment-error" class="alert alert-danger mt-3 d-none">
                                    <i class="fas fa-exclamation-circle me-2"></i>
                                    <span id="error-message">Ocorreu um erro ao enviar. Tente novamente.</span>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>

            </div>

            
            <div class="col-lg-4">
                
                <div class="sidebar-card newsletter-card">
                    <div class="card-header">
                        <i class="fas fa-envelope-open-text"></i>
                        <h3>Newsletter HSE</h3>
                    </div>
                    <div class="card-body">
                        <p>Receba as últimas notícias e conteúdos exclusivos sobre Saúde, Segurança e Ambiente.</p>
                        
                        <form action="<?php echo e(route('subscribers.store')); ?>" method="POST" class="sidebar-newsletter-form">
                            <?php echo csrf_field(); ?>
                            <div class="input-group">
                                <input type="email" 
                                       name="email" 
                                       class="form-control" 
                                       placeholder="Seu melhor email"
                                       required>
                                <button type="submit" class="btn btn-accent">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                            <small class="form-text">
                                <i class="fas fa-lock"></i> Respeitamos sua privacidade
                            </small>
                        </form>
                        
                        <div class="newsletter-benefits">
                            <div class="benefit-item">
                                <i class="fas fa-check-circle"></i>
                                <span>Conteúdo exclusivo</span>
                            </div>
                            <div class="benefit-item">
                                <i class="fas fa-check-circle"></i>
                                <span>Zero spam</span>
                            </div>
                            <div class="benefit-item">
                                <i class="fas fa-check-circle"></i>
                                <span>Cancele quando quiser</span>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="sidebar-card related-posts-card">
                    <div class="card-header">
                        <i class="fas fa-newspaper"></i>
                        <h3>Notícias Relacionadas</h3>
                    </div>
                    <div class="card-body">
                        <?php $__empty_1 = true; $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="<?php echo e(route('posts.show', $related->slug)); ?>" class="related-post-item">
                                <div class="related-post-image">
                                    <?php if($related->image_url): ?>
                                        <img src="<?php echo e(asset('storage/'.$related->image_url)); ?>" 
                                             alt="<?php echo e($related->title); ?>"
                                             loading="lazy">
                                    <?php else: ?>
                                        <div class="image-placeholder">
                                            <i class="fas fa-newspaper"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="related-post-content">
                                    <h4><?php echo e(Str::limit($related->title, 60)); ?></h4>
                                    <div class="post-meta-small">
                                        <span><?php echo e(optional($related->published_at)->format('d/m/Y')); ?></span>
                                        <span>•</span>
                                        <span><?php echo e($related->category->name ?? 'Geral'); ?></span>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted">Não há notícias relacionadas no momento.</p>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="sidebar-card categories-card">
                    <div class="card-header">
                        <i class="fas fa-folder"></i>
                        <h3>Categorias</h3>
                    </div>
                    <div class="card-body">
                        <ul class="categories-list">
                            <?php $__currentLoopData = \App\Models\Category::withCount('posts')->orderBy('posts_count', 'desc')->take(8)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('posts.public')); ?>?category=<?php echo e($category->slug); ?>">
                                        <span class="category-name"><?php echo e($category->name); ?></span>
                                        <span class="category-count"><?php echo e($category->posts_count); ?></span>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

                
                <div class="sidebar-card ad-card">
                    <div class="card-header">
                        <i class="fas fa-bullhorn"></i>
                        <h3>Patrocinador</h3>
                    </div>
                    <div class="card-body">
                        <div class="ad-content">
                            <img src="https://via.placeholder.com/300x150/0066cc/ffffff?text=HSE+PRO" 
                                 alt="HSE Pro - Patrocinador"
                                 loading="lazy"
                                 class="ad-image">
                            <div class="ad-text">
                                <h5>Soluções HSE Integradas</h5>
                                <p>Consultoria especializada em Saúde, Segurança e Ambiente</p>
                                <a href="#" class="btn btn-sm btn-outline-primary">
                                    Saiba Mais <i class="fas fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


<section class="recommended-posts">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Você Também Pode Gostar</h2>
            <p class="section-subtitle">Descubra mais conteúdos relevantes sobre HSE</p>
        </div>
        
        <div class="recommended-grid">
            <?php $__currentLoopData = \App\Models\Post::whereNotNull('published_at')
                ->where('id', '!=', $post->id)
                ->inRandomOrder()
                ->take(3)
                ->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommended): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="recommended-card">
                    <a href="<?php echo e(route('posts.show', $recommended->slug)); ?>" class="recommended-image">
                        <?php if($recommended->image_url): ?>
                            <img src="<?php echo e(asset('storage/'.$recommended->image_url)); ?>" 
                                 alt="<?php echo e($recommended->title); ?>"
                                 loading="lazy">
                        <?php else: ?>
                            <div class="image-placeholder">
                                <i class="fas fa-newspaper"></i>
                            </div>
                        <?php endif; ?>
                        <span class="category-tag"><?php echo e($recommended->category->name ?? 'Geral'); ?></span>
                    </a>
                    <div class="recommended-content">
                        <h3>
                            <a href="<?php echo e(route('posts.show', $recommended->slug)); ?>">
                                <?php echo e(Str::limit($recommended->title, 70)); ?>

                            </a>
                        </h3>
                        <div class="recommended-meta">
                            <span><?php echo e(optional($recommended->published_at)->format('d/m/Y')); ?></span>
                            <span>•</span>
                            <span><?php echo e($recommended->reading_time ?? '3'); ?> min</span>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<?php if($post->author_bio || $post->author_photo): ?>
<section class="author-section">
    <div class="container">
        <div class="author-card">
            <div class="author-header">
                <div class="author-avatar-large">
                    <?php if($post->author_photo): ?>
                        <img src="<?php echo e(asset('storage/'.$post->author_photo)); ?>" alt="<?php echo e($post->author_name); ?>">
                    <?php else: ?>
                        <i class="fas fa-user-circle"></i>
                    <?php endif; ?>
                </div>
                <div class="author-info">
                    <h3><?php echo e($post->author_name); ?></h3>
                    <p class="author-title">Colaborador do Portal HSE</p>
                    <?php if($post->author_role): ?>
                        <span class="author-role"><?php echo e($post->author_role); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if($post->author_bio): ?>
                <div class="author-bio">
                    <p><?php echo e($post->author_bio); ?></p>
                </div>
            <?php endif; ?>
            
            <div class="author-stats">
                <div class="stat-item">
                    <i class="fas fa-newspaper"></i>
                    <span><?php echo e($post->author_posts_count ?? '0'); ?> artigos</span>
                </div>
                <div class="stat-item">
                    <i class="fas fa-eye"></i>
                    <span><?php echo e($post->author_views_count ?? '0'); ?> visualizações</span>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?> 


<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="copyToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-body">
            <i class="fas fa-check-circle me-2 text-success"></i>
            Link copiado para a área de transferência!
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/postshow.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // ====== GALERIA DE IMAGENS ======
    const galleryImages = <?php echo json_encode($gallery->map(fn($img) => asset('storage/'.$img)), 15, 512) ?>;
    let currentGalleryIndex = 0;
    const featuredImage = document.getElementById('featuredImage');
    const thumbnailButtons = document.querySelectorAll('.thumbnail-btn');

    function showGalleryImage(index) {
        if (index < 0 || index >= galleryImages.length) return;
        
        currentGalleryIndex = index;
        
        // Atualiza imagem principal
        featuredImage.src = galleryImages[index];
        
        // Atualiza contador
        const counter = document.querySelector('.image-counter');
        if (counter) {
            counter.innerHTML = `<i class="fas fa-images"></i> ${index + 1}/${galleryImages.length}`;
        }
        
        // Atualiza thumbnails ativos
        thumbnailButtons.forEach((btn, i) => {
            btn.classList.toggle('active', i === index);
        });
    }

    function changeGalleryImage(direction) {
        let newIndex = currentGalleryIndex + direction;
        
        if (newIndex < 0) newIndex = galleryImages.length - 1;
        if (newIndex >= galleryImages.length) newIndex = 0;
        
        showGalleryImage(newIndex);
    }

    // Event listeners para a galeria
    document.querySelectorAll('.thumbnail-btn').forEach((btn, index) => {
        btn.addEventListener('click', () => showGalleryImage(index));
    });

    if (document.querySelector('.gallery-nav.prev')) {
        document.querySelector('.gallery-nav.prev').addEventListener('click', () => changeGalleryImage(-1));
        document.querySelector('.gallery-nav.next').addEventListener('click', () => changeGalleryImage(1));
    }

    // Navegação por teclado
    document.addEventListener('keydown', (e) => {
        if (galleryImages.length > 1) {
            if (e.key === 'ArrowLeft') changeGalleryImage(-1);
            if (e.key === 'ArrowRight') changeGalleryImage(1);
        }
    });

    // ====== COPIAR LINK ======
    window.copyToClipboard = function(text) {
        navigator.clipboard.writeText(text).then(() => {
            const toast = new bootstrap.Toast(document.getElementById('copyToast'));
            toast.show();
        }).catch(err => {
            console.error('Erro ao copiar: ', err);
        });
    };

    // ====== CONTADOR DE CARACTERES DO COMENTÁRIO ======
    const commentTextarea = document.getElementById('comment_body');
    const charCount = document.getElementById('char-count');
    
    if (commentTextarea && charCount) {
        commentTextarea.addEventListener('input', function() {
            const length = this.value.length;
            charCount.textContent = length;
            
            if (length > 500) {
                charCount.style.color = '#dc3545';
            } else if (length > 400) {
                charCount.style.color = '#ffc107';
            } else {
                charCount.style.color = '#28a745';
            }
        });
    }

    // ====== PAGINAÇÃO DE COMENTÁRIOS ======
    let currentCommentsUrl = "<?php echo e(route('comments.ajax', $post)); ?>";
    let commentsTotal = 0;

    async function loadComments(url) {
        if (!url) return;

        try {
            const response = await fetch(url);
            const result = await response.json();

            const list = document.getElementById('comments-list');
            list.innerHTML = '';

            // Atualiza total de comentários
            commentsTotal = result.total || 0;
            const totalEl = document.getElementById('comments-total');
            if (totalEl) {
                totalEl.textContent = `(${commentsTotal})`;
            }

            if (!result.data || result.data.length === 0) {
                list.innerHTML = `
                    <div class="empty-comments">
                        <i class="fas fa-comments"></i>
                        <h4>Nenhum comentário ainda</h4>
                        <p>Seja o primeiro a comentar esta notícia!</p>
                    </div>
                `;
            } else {
                result.data.forEach(comment => {
                    const commentDate = new Date(comment.created_at);
                    const formattedDate = commentDate.toLocaleDateString('pt-PT', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });

                    list.insertAdjacentHTML('beforeend', `
                        <div class="comment-item">
                            <div class="comment-header">
                                <div class="comment-avatar">
                                    <span>${comment.name.charAt(0).toUpperCase()}</span>
                                </div>
                                <div class="comment-author">
                                    <strong>${comment.name}</strong>
                                    <span class="comment-date">
                                        <i class="fas fa-clock"></i> ${comment.date}
                                    </span>
                                </div>
                            </div>
                            <div class="comment-body">
                                ${comment.body}
                            </div>
                            ${comment.reply_to ? `
                                <div class="comment-reply">
                                    <i class="fas fa-reply"></i> Em resposta a ${comment.reply_to}
                                </div>
                            ` : ''}
                        </div>
                    `);
                });
            }

            // Atualiza botões de paginação
            const prevBtn = document.getElementById('prev-comments');
            const nextBtn = document.getElementById('next-comments');
            const pageInfo = document.getElementById('comments-page-info');

            prevBtn.disabled = !result.prev_page_url;
            nextBtn.disabled = !result.next_page_url;

            if (pageInfo) {
                pageInfo.textContent = `Página ${result.current_page} de ${result.last_page}`;
            }

            prevBtn.dataset.url = result.prev_page_url || '';
            nextBtn.dataset.url = result.next_page_url || '';

        } catch (error) {
            console.error('Erro ao carregar comentários:', error);
        }
    }

    // Carrega primeira página
    loadComments(currentCommentsUrl);

    // Event listeners para paginação
    document.getElementById('prev-comments').addEventListener('click', function() {
        if (this.dataset.url) loadComments(this.dataset.url);
    });

    document.getElementById('next-comments').addEventListener('click', function() {
        if (this.dataset.url) loadComments(this.dataset.url);
    });

    // ====== ENVIO DE COMENTÁRIO ======
    const commentForm = document.getElementById('comment-form');
    const successEl = document.getElementById('comment-success');
    const errorEl = document.getElementById('comment-error');
    const submitBtn = document.getElementById('commentSubmitBtn');
    

    if (commentForm) {
        commentForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            // Esconde mensagens anteriores
            if (successEl) successEl.classList.add('d-none');
            if (errorEl) errorEl.classList.add('d-none');

            // Salva texto original do botão
            const originalText = submitBtn ? submitBtn.innerHTML : '';
            
            // Desabilita botão e mostra loading
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = `
                    <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    Enviando...
                `;
            }

            try {
                const formData = new FormData(this);
                const response = await fetch(this.action, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: formData
                });

                const result = await response.json();

                if (!response.ok) {
                    throw new Error(result.message || 'Erro ao enviar comentário');
                }

                // Sucesso
                if (successEl) {
                    successEl.classList.remove('d-none');
                }

                // Limpa formulário
                this.reset();
                
                // Reseta contador de caracteres
                if (charCount) {
                    charCount.textContent = '0';
                    charCount.style.color = '#28a745';
                }

                // Recarrega comentários
                setTimeout(() => {
                    loadComments("<?php echo e(route('comments.ajax', $post)); ?>");
                    location.reload();
                }, 1000);

            } catch (error) {
                // Erro
                if (errorEl) {
                    errorEl.querySelector('#error-message').textContent = error.message;
                    errorEl.classList.remove('d-none');
                }
            } finally {
                // Restaura botão
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }
            }
        });
    }

    // ====== SALVAR POST ======
    window.toggleSavePost = function(postId) {
        const saveBtn = document.querySelector('.save-btn');
        const icon = saveBtn.querySelector('i');
        
        // Toggle visual
        if (icon.classList.contains('far')) {
            icon.classList.remove('far');
            icon.classList.add('fas');
            saveBtn.innerHTML = '<i class="fas fa-bookmark"></i> Salvo';
            saveBtn.classList.add('saved');
        } else {
            icon.classList.remove('fas');
            icon.classList.add('far');
            saveBtn.innerHTML = '<i class="far fa-bookmark"></i> Salvar';
            saveBtn.classList.remove('saved');
        }

        // Em produção, aqui faria uma requisição AJAX para salvar/remover
        console.log('Post ' + postId + ' salvo/removido');
    };

    // ====== SCROLL SUAVE PARA ÂNCORAS ======
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });

});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal_backend_chat_packageB\resources\views/posts/show.blade.php ENDPATH**/ ?>