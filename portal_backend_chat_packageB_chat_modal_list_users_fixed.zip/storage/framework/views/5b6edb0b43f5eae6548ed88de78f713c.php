

<?php $__env->startSection('title', 'Admin - Vagas HSE'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h1 class="section-title mb-0">Gerir Vagas HSE</h1>
    <div class="text-muted small">Crie, edite e destaque oportunidades de emprego.</div>
  </div>

  <div class="d-flex gap-2">
    <form method="GET" class="d-flex gap-2">
      <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Buscar vaga...">
      <button class="btn btn-outline-secondary" type="submit">
        <i class="fa-solid fa-magnifying-glass"></i>
      </button>
    </form>

    <a href="<?php echo e(route('admin.jobs.create')); ?>" class="btn btn-primary">
      <i class="fa-solid fa-plus me-1"></i> Nova vaga
    </a>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-4">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover mb-0 align-middle">
        <thead class="table-light">
          <tr>
            <th style="min-width:320px;">Vaga</th>
            <th>Empresa</th>
            <th>Local</th>
            <th>Publicado</th>
            <th class="text-center">Ativa</th>
            <th class="text-center">Destaque</th>
            <th class="text-center">Patroc.</th>
            <th class="text-end">Ações</th>
          </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td>
              <div class="fw-semibold"><?php echo e($job->title); ?></div>
              <div class="text-muted small"><?php echo e($job->type ?? '—'); ?> <?php if($job->level): ?> · <?php echo e($job->level); ?> <?php endif; ?></div>
            </td>
            <td><?php echo e($job->company ?? '—'); ?></td>
            <td><?php echo e($job->location ?? '—'); ?></td>
            <td class="text-muted small"><?php echo e(optional($job->published_at)->format('d/m/Y H:i')); ?></td>

            <td class="text-center">
              <?php if($job->is_active): ?>
                <span class="badge text-bg-success">Sim</span>
              <?php else: ?>
                <span class="badge text-bg-secondary">Não</span>
              <?php endif; ?>
            </td>

            <td class="text-center">
              <?php if($job->is_featured): ?>
                <span class="badge text-bg-warning"><i class="fa-solid fa-star"></i></span>
              <?php else: ?>
                <span class="text-muted">—</span>
              <?php endif; ?>
            </td>

            <td class="text-center">
              <?php if($job->is_sponsored): ?>
                <span class="badge text-bg-dark"><i class="fa-solid fa-bolt"></i></span>
              <?php else: ?>
                <span class="text-muted">—</span>
              <?php endif; ?>
            </td>

            <td class="text-end">
              <a href="<?php echo e(route('admin.jobs.edit', $job)); ?>" class="btn btn-sm btn-outline-secondary">
                <i class="fa-regular fa-pen-to-square"></i>
              </a>
              <form action="<?php echo e(route('admin.jobs.destroy', $job)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-outline-danger"
                        onclick="return confirm('Apagar esta vaga?')">
                  <i class="fa-regular fa-trash-can"></i>
                </button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="8" class="text-center text-muted py-4">
              Nenhuma vaga encontrada.
            </td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<div class="d-flex justify-content-between align-items-center mt-4">
  <div>
    <?php if($jobs->onFirstPage()): ?>
      <button class="btn btn-outline-secondary" disabled>
        <i class="fa-solid fa-arrow-left me-1"></i> Anterior
      </button>
    <?php else: ?>
      <a class="btn btn-outline-secondary" href="<?php echo e($jobs->previousPageUrl()); ?>">
        <i class="fa-solid fa-arrow-left me-1"></i> Anterior
      </a>
    <?php endif; ?>
  </div>

  <div class="text-muted small">Página <?php echo e($jobs->currentPage()); ?> de <?php echo e($jobs->lastPage()); ?></div>

  <div>
    <?php if($jobs->hasMorePages()): ?>
      <a class="btn btn-outline-secondary" href="<?php echo e($jobs->nextPageUrl()); ?>">
        Próximo <i class="fa-solid fa-arrow-right ms-1"></i>
      </a>
    <?php else: ?>
      <button class="btn btn-outline-secondary" disabled>
        Próximo <i class="fa-solid fa-arrow-right ms-1"></i>
      </button>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal_hse\resources\views/admin/jobs/index.blade.php ENDPATH**/ ?>