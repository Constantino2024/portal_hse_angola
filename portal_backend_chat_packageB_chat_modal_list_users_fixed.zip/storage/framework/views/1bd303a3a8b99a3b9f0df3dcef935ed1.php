<?php
  $isEdit = isset($project);
?>

<div class="row g-3">
  <div class="col-12 col-lg-8">
    <div class="mb-3">
      <label class="form-label">Título do projecto</label>
      <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $project->title ?? '')); ?>" required>
    </div>

    <div class="row g-2">
      <div class="col-12 col-md-6">
        <label class="form-label">Cliente (opcional)</label>
        <input type="text" name="client" class="form-control" value="<?php echo e(old('client', $project->client ?? '')); ?>">
      </div>
      <div class="col-12 col-md-6">
        <label class="form-label">Sector</label>
        <input type="text" name="sector" class="form-control" value="<?php echo e(old('sector', $project->sector ?? '')); ?>" placeholder="Oil&Gas, Construção, Energia...">
      </div>
    </div>

    <div class="row g-2 mt-1">
      <div class="col-12 col-md-6">
        <label class="form-label">Local</label>
        <input type="text" name="location" class="form-control" value="<?php echo e(old('location', $project->location ?? '')); ?>">
      </div>
      <div class="col-12 col-md-3">
        <label class="form-label">Início</label>
        <input type="date" name="start_date" class="form-control" value="<?php echo e(old('start_date', optional($project->start_date ?? null)->format('Y-m-d'))); ?>">
      </div>
      <div class="col-12 col-md-3">
        <label class="form-label">Fim</label>
        <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date', optional($project->end_date ?? null)->format('Y-m-d'))); ?>">
      </div>
    </div>

    <div class="mt-3">
      <label class="form-label">Resumo</label>
      <textarea name="excerpt" class="form-control" rows="2"><?php echo e(old('excerpt', $project->excerpt ?? '')); ?></textarea>
    </div>

    <div class="mt-3">
      <label class="form-label">Descrição</label>
      <textarea name="description" class="form-control" rows="7"><?php echo e(old('description', $project->description ?? '')); ?></textarea>
    </div>
  </div>

  <div class="col-12 col-lg-4">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="card-body">
        <div class="fw-semibold mb-2">Publicação</div>

        <div class="mb-3">
          <label class="form-label">Website (opcional)</label>
          <input type="url" name="website" class="form-control" value="<?php echo e(old('website', $project->website ?? '')); ?>" placeholder="https://...">
        </div>

        <hr>

        <div class="form-check form-switch">
          <input class="form-check-input" type="checkbox" role="switch" id="is_active" name="is_active" value="1"
                 <?php if(old('is_active', $project->is_active ?? true)): echo 'checked'; endif; ?>>
          <label class="form-check-label" for="is_active">Ativo (visível no portal)</label>
        </div>

        <div class="text-muted small mt-3">
          <i class="fa-regular fa-circle-info me-1"></i>
          Use esta área para divulgar projectos e portfólio.
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\Users\Constantino\Downloads\Trabalho\portal\resources\views/partner/projects/_form.blade.php ENDPATH**/ ?>