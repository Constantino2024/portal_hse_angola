<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Área do Parceiro'); ?> · Portal HSE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="admin-body">

<div class="admin-wrapper">

    <aside class="admin-sidebar">
        <div class="sidebar-header">
            <span class="logo">
                Portal <strong>HSE</strong>
            </span>
            <div class="text-muted small mt-1">Área do Parceiro</div>
        </div>

        <nav class="sidebar-nav">

            <a href="<?php echo e(route('partner.dashboard')); ?>"
               class="sidebar-link <?php echo e(request()->routeIs('partner.dashboard') ? 'active' : ''); ?>">
                <i class="fa-solid fa-gauge-high"></i>
                <span>Dashboard</span>
            </a>

            <a href="<?php echo e(route('partner.jobs.index')); ?>"
               class="sidebar-link <?php echo e(request()->routeIs('partner.jobs.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-briefcase"></i>
                <span>Publicar Vagas</span>
            </a>

            <a href="<?php echo e(route('partner.esg.index')); ?>"
               class="sidebar-link <?php echo e(request()->routeIs('partner.esg.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-leaf"></i>
                <span>Iniciativas ESG</span>
            </a>

            <a href="<?php echo e(route('partner.projects.index')); ?>"
               class="sidebar-link <?php echo e(request()->routeIs('partner.projects.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-diagram-project"></i>
                <span>Projectos</span>
            </a>

            <div class="sidebar-section-title">Banco de Talentos</div>

            <a href="<?php echo e(route('partner.needs.index')); ?>"
               class="sidebar-link <?php echo e(request()->routeIs('partner.needs.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-clipboard-list"></i>
                <span>Necessidades</span>
            </a>

            <a href="<?php echo e(route('partner.talents.index')); ?>"
               class="sidebar-link <?php echo e(request()->routeIs('partner.talents.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-users"></i>
                <span>Pesquisar Talentos</span>
            </a>

            <hr>

            <a href="<?php echo e(route('home')); ?>" target="_blank" class="sidebar-link">
                <i class="fa-solid fa-globe"></i>
                <span>Ver site</span>
            </a>

        </nav>
    </aside>

    <main class="admin-content">

        <header class="admin-topbar">
            <button class="btn btn-sm btn-outline-secondary d-lg-none" id="toggleSidebar">
                <i class="fa-solid fa-bars"></i>
            </button>

            <div class="ms-auto">
                <span class="admin-user">
                    <i class="fa-regular fa-building"></i>
                    <?php echo e(auth()->check() ? auth()->user()->name : 'Empresa'); ?>

                </span>
            </div>
        </header>

        <section class="admin-page-content">
            <?php echo $__env->make('partner.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </section>

    </main>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('toggleSidebar')?.addEventListener('click', function () {
    document.body.classList.toggle('sidebar-open');
});
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Constantino\Downloads\Compressed\portal_hse_com_auth_fix_seed\portal\resources\views/layouts/partner.blade.php ENDPATH**/ ?>