

<?php $__env->startSection('title', 'Editar Perfil da Empresa'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">
    <!-- Header -->
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h2 fw-bold mb-2">Editar Perfil da Empresa</h1>
            <p class="text-muted">
                <i class="fa-regular fa-circle-info me-2"></i>
                Atualize as informações da sua empresa para manter seu perfil sempre atualizado.
            </p>
        </div>
        <a href="<?php echo e(route('partner.profile')); ?>" class="btn btn-light">
            <i class="fa-solid fa-arrow-left me-2"></i>
            Voltar ao Perfil
        </a>
    </div>

    <form action="<?php echo e(route('partner.profile.update')); ?>" method="POST" enctype="multipart/form-data" id="profileForm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Logo e Banner Section -->
        <div class="form-section">
            <div class="form-section-title">
                <i class="fa-solid fa-image"></i>
                Logo e Banner
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <label class="form-label">Logo da Empresa</label>
                    <div class="upload-area <?php if($company->logo_path): ?> has-image <?php endif; ?>" id="logoUpload">
                        <input type="file" name="logo" id="logoInput" accept="image/*" style="display: none;">
                        
                        <?php if($company->logo_path): ?>
                            <img src="<?php echo e($company->logo_url); ?>" alt="Logo" id="logoPreview">
                            <div class="upload-remove" onclick="removeLogo(event)" title="Remover logo">
                                <i class="fa-solid fa-times"></i>
                            </div>
                        <?php else: ?>
                            <div class="text-center">
                                <div class="upload-icon">
                                    <i class="fa-solid fa-cloud-upload-alt"></i>
                                </div>
                                <div class="upload-text">Clique para fazer upload do logo</div>
                                <div class="upload-hint">PNG, JPG ou SVG (max. 2MB)</div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Banner da Empresa</label>
                    <div class="upload-area <?php if($company->banner_path): ?> has-image <?php endif; ?>" id="bannerUpload">
                        <input type="file" name="banner" id="bannerInput" accept="image/*" style="display: none;">
                        
                        <?php if($company->banner_path): ?>
                            <img src="<?php echo e($company->banner_url); ?>" alt="Banner" id="bannerPreview">
                            <div class="upload-remove" onclick="removeBanner(event)" title="Remover banner">
                                <i class="fa-solid fa-times"></i>
                            </div>
                        <?php else: ?>
                            <div class="text-center">
                                <div class="upload-icon">
                                    <i class="fa-solid fa-cloud-upload-alt"></i>
                                </div>
                                <div class="upload-text">Clique para fazer upload do banner</div>
                                <div class="upload-hint">JPG ou PNG (max. 5MB, recomendado 1200x300px)</div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php $__errorArgs = ['banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- Informações Básicas -->
        <div class="form-section">
            <div class="form-section-title">
                <i class="fa-solid fa-building"></i>
                Informações Básicas
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <label class="form-label">Nome da Empresa *</label>
                    <input type="text" name="company_name" class="form-control <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('company_name', $company->company_name)); ?>" required>
                    <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Nome Fantasia</label>
                    <input type="text" name="trading_name" class="form-control <?php $__errorArgs = ['trading_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('trading_name', $company->trading_name)); ?>">
                    <?php $__errorArgs = ['trading_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">NIF *</label>
                    <input type="text" name="nif" class="form-control <?php $__errorArgs = ['nif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('nif', $company->nif)); ?>" required>
                    <?php $__errorArgs = ['nif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Setor de Atividade *</label>
                    <select name="sector" class="form-select <?php $__errorArgs = ['sector'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Selecione o setor</option>
                        <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('sector', $company->sector) == $value ? 'selected' : ''); ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['sector'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Porte da Empresa *</label>
                    <select name="company_size" class="form-select <?php $__errorArgs = ['company_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Selecione o porte</option>
                        <?php $__currentLoopData = $companySizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('company_size', $company->company_size) == $value ? 'selected' : ''); ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['company_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Ano de Fundação</label>
                    <input type="number" name="foundation_year" class="form-control <?php $__errorArgs = ['foundation_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('foundation_year', $company->foundation_year)); ?>" min="1900" max="<?php echo e(date('Y')); ?>">
                    <?php $__errorArgs = ['foundation_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- Contactos -->
        <div class="form-section">
            <div class="form-section-title">
                <i class="fa-solid fa-address-book"></i>
                Contactos
            </div>

            <div class="row g-4">
                <div class="col-md-4">
                    <label class="form-label">Telefone *</label>
                    <input type="text" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('phone', $company->phone)); ?>" required>
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('email', $company->email)); ?>" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Website</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-globe"></i></span>
                        <input type="url" name="website" class="form-control <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('website', $company->website)); ?>" placeholder="https://www.exemplo.com">
                    </div>
                    <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- Pessoa de Contacto -->
        <div class="form-section">
            <div class="form-section-title">
                <i class="fa-solid fa-user-tie"></i>
                Pessoa de Contacto
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <label class="form-label">Nome do Contacto *</label>
                    <input type="text" name="contact_person" class="form-control <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('contact_person', $company->contact_person)); ?>" required>
                    <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Cargo/Função</label>
                    <input type="text" name="contact_position" class="form-control <?php $__errorArgs = ['contact_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('contact_position', $company->contact_position)); ?>">
                    <?php $__errorArgs = ['contact_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- Localização -->
        <div class="form-section">
            <div class="form-section-title">
                <i class="fa-solid fa-location-dot"></i>
                Localização
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <label class="form-label">Endereço *</label>
                    <input type="text" name="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('address', $company->address)); ?>" required>
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Cidade *</label>
                    <input type="text" name="city" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('city', $company->city)); ?>" required>
                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Província *</label>
                    <select name="province" class="form-select <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Selecione a província</option>
                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('province', $company->province) == $value ? 'selected' : ''); ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">País</label>
                    <input type="text" name="country" class="form-control <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('country', $company->country ?? 'Angola')); ?>" required>
                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- Sobre a Empresa -->
        <div class="form-section">
            <div class="form-section-title">
                <i class="fa-solid fa-align-left"></i>
                Sobre a Empresa
            </div>

            <div class="row g-4">
                <div class="col-12">
                    <label class="form-label">Descrição</label>
                    <textarea name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              rows="5"><?php echo e(old('description', $company->description)); ?></textarea>
                    <small class="text-muted">Descreva a sua empresa, principais atividades e diferenciais.</small>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Missão</label>
                    <textarea name="mission" class="form-control <?php $__errorArgs = ['mission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              rows="3"><?php echo e(old('mission', $company->mission)); ?></textarea>
                    <?php $__errorArgs = ['mission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Visão</label>
                    <textarea name="vision" class="form-control <?php $__errorArgs = ['vision'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              rows="3"><?php echo e(old('vision', $company->vision)); ?></textarea>
                    <?php $__errorArgs = ['vision'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Valores</label>
                    <textarea name="values" class="form-control <?php $__errorArgs = ['values'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              rows="3"><?php echo e(old('values', $company->values)); ?></textarea>
                    <?php $__errorArgs = ['values'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- Redes Sociais -->
        <div class="form-section">
            <div class="form-section-title">
                <i class="fa-solid fa-share-nodes"></i>
                Redes Sociais
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <label class="form-label">Facebook</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-brands fa-facebook-f"></i></span>
                        <input type="url" name="facebook" class="form-control <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('facebook', $company->facebook)); ?>" placeholder="https://facebook.com/...">
                    </div>
                    <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">LinkedIn</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-brands fa-linkedin-in"></i></span>
                        <input type="url" name="linkedin" class="form-control <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('linkedin', $company->linkedin)); ?>" placeholder="https://linkedin.com/company/...">
                    </div>
                    <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Twitter/X</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-brands fa-x-twitter"></i></span>
                        <input type="url" name="twitter" class="form-control <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('twitter', $company->twitter)); ?>" placeholder="https://twitter.com/...">
                    </div>
                    <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Instagram</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-brands fa-instagram"></i></span>
                        <input type="url" name="instagram" class="form-control <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('instagram', $company->instagram)); ?>" placeholder="https://instagram.com/...">
                    </div>
                    <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- HSE & ESG -->
        <div class="form-section">
            <div class="form-section-title">
                <i class="fa-solid fa-leaf"></i>
                HSE & ESG
            </div>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" name="has_hse_department" class="form-check-input" role="switch" 
                               id="hasHseDept" <?php echo e(old('has_hse_department', $company->has_hse_department) ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="hasHseDept">Possui Departamento de HSE</label>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" name="has_esg_policy" class="form-check-input" role="switch" 
                               id="hasEsgPolicy" <?php echo e(old('has_esg_policy', $company->has_esg_policy) ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="hasEsgPolicy">Possui Política ESG</label>
                    </div>
                </div>
            </div>

            <div class="row g-4" id="hseInfo" style="<?php echo e($company->has_hse_department ? '' : 'display: none;'); ?>">
                <div class="col-md-6">
                    <label class="form-label">Nome do Gestor HSE</label>
                    <input type="text" name="hse_manager_name" class="form-control <?php $__errorArgs = ['hse_manager_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('hse_manager_name', $company->hse_manager_name)); ?>">
                    <?php $__errorArgs = ['hse_manager_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Contacto do Gestor HSE</label>
                    <input type="text" name="hse_manager_contact" class="form-control <?php $__errorArgs = ['hse_manager_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('hse_manager_contact', $company->hse_manager_contact)); ?>">
                    <?php $__errorArgs = ['hse_manager_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- Submit Buttons -->
        <div class="d-flex gap-3 justify-content-end mt-4 mb-5">
            <a href="<?php echo e(route('partner.profile')); ?>" class="btn-cancel">
                <i class="fa-solid fa-times me-2"></i>
                Cancelar
            </a>
            <button type="submit" class="btn-save">
                <i class="fa-solid fa-save me-2"></i>
                Salvar Alterações
            </button>
        </div>
    </form>
</div>

<!-- Hidden form for remove operations -->
<form id="removeLogoForm" action="<?php echo e(route('partner.profile.logo.remove')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>

<form id="removeBannerForm" action="<?php echo e(route('partner.profile.banner.remove')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>

<style>
    .form-section {
        background: white;
        border-radius: 16px;
        padding: 2rem;
        box-shadow: var(--box-shadow);
        margin-bottom: 2rem;
        border: 1px solid var(--medium-gray);
    }

    .form-section-title {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--primary-dark);
        margin-bottom: 1.5rem;
        padding-bottom: 0.75rem;
        border-bottom: 2px solid var(--medium-gray);
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .form-section-title i {
        color: var(--accent-orange);
        font-size: 1.25rem;
    }

    .form-label {
        font-weight: 500;
        color: var(--text-dark);
        margin-bottom: 0.5rem;
        font-size: 0.9rem;
    }

    .form-control, .form-select {
        border: 2px solid var(--medium-gray);
        border-radius: 10px;
        padding: 0.75rem 1rem;
        transition: all 0.2s ease;
    }

    .form-control:focus, .form-select:focus {
        border-color: var(--accent-orange);
        box-shadow: 0 0 0 4px rgba(211, 84, 0, 0.1);
    }

    .form-control.is-invalid, .form-select.is-invalid {
        border-color: #dc3545;
        background-image: none;
    }

    .invalid-feedback {
        font-size: 0.875rem;
        margin-top: 0.25rem;
    }

    .upload-area {
        border: 3px dashed var(--medium-gray);
        border-radius: 16px;
        padding: 2rem;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s ease;
        background: var(--light-gray);
        position: relative;
        min-height: 200px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .upload-area:hover {
        border-color: var(--accent-orange);
        background: rgba(211, 84, 0, 0.05);
    }

    .upload-area.has-image {
        border-style: solid;
        border-color: var(--primary-dark);
        padding: 0.5rem;
    }

    .upload-area img {
        max-width: 100%;
        max-height: 180px;
        border-radius: 12px;
    }

    .upload-remove {
        position: absolute;
        top: 10px;
        right: 10px;
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: white;
        border: 2px solid #dc3545;
        color: #dc3545;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        z-index: 10;
    }

    .upload-remove:hover {
        background: #dc3545;
        color: white;
    }

    .upload-icon {
        font-size: 3rem;
        color: var(--dark-gray);
        margin-bottom: 1rem;
    }

    .upload-text {
        color: var(--dark-gray);
        font-weight: 500;
    }

    .upload-hint {
        font-size: 0.875rem;
        color: var(--dark-gray);
        margin-top: 0.5rem;
    }

    .btn-save {
        background: var(--accent-orange);
        color: white;
        padding: 1rem 2.5rem;
        font-weight: 600;
        border-radius: 12px;
        border: none;
        transition: all 0.3s ease;
    }

    .btn-save:hover {
        background: var(--accent-orange-hover);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(211, 84, 0, 0.3);
    }

    .btn-cancel {
        background: var(--light-gray);
        color: var(--text-dark);
        padding: 1rem 2.5rem;
        font-weight: 600;
        border-radius: 12px;
        border: 2px solid var(--medium-gray);
        transition: all 0.3s ease;
    }

    .btn-cancel:hover {
        background: var(--medium-gray);
        color: var(--text-dark);
    }

    .preview-badge {
        position: absolute;
        bottom: 10px;
        right: 10px;
        background: rgba(0,0,0,0.7);
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 50px;
        font-size: 0.75rem;
        backdrop-filter: blur(5px);
    }

    .input-group-text {
        background: var(--light-gray);
        border: 2px solid var(--medium-gray);
        border-radius: 10px 0 0 10px;
        color: var(--dark-gray);
    }

    .input-group .form-control {
        border-left: none;
        border-radius: 0 10px 10px 0;
    }

    .form-check-input:checked {
        background-color: var(--accent-orange);
        border-color: var(--accent-orange);
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle HSE fields
    const hasHseDept = document.getElementById('hasHseDept');
    const hseInfo = document.getElementById('hseInfo');
    
    if (hasHseDept) {
        hasHseDept.addEventListener('change', function() {
            hseInfo.style.display = this.checked ? 'flex' : 'none';
        });
    }

    // Logo upload
    const logoUpload = document.getElementById('logoUpload');
    const logoInput = document.getElementById('logoInput');
    
    if (logoUpload) {
        logoUpload.addEventListener('click', function() {
            logoInput.click();
        });
    }

    if (logoInput) {
        logoInput.addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const html = `
                        <img src="${e.target.result}" id="logoPreview">
                        <div class="upload-remove" onclick="removeLogo(event)" title="Remover logo">
                            <i class="fa-solid fa-times"></i>
                        </div>
                    `;
                    logoUpload.innerHTML = html;
                    logoUpload.classList.add('has-image');
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    }

    // Banner upload
    const bannerUpload = document.getElementById('bannerUpload');
    const bannerInput = document.getElementById('bannerInput');
    
    if (bannerUpload) {
        bannerUpload.addEventListener('click', function() {
            bannerInput.click();
        });
    }

    if (bannerInput) {
        bannerInput.addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const html = `
                        <img src="${e.target.result}" id="bannerPreview">
                        <div class="upload-remove" onclick="removeBanner(event)" title="Remover banner">
                            <i class="fa-solid fa-times"></i>
                        </div>
                    `;
                    bannerUpload.innerHTML = html;
                    bannerUpload.classList.add('has-image');
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    }

    // Preview before submit (optional)
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            // You could add a loading indicator here
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-2"></i> Salvando...';
                submitBtn.disabled = true;
            }
        });
    }
});

// Remove logo function
function removeLogo(event) {
    event.stopPropagation();
    
    if (confirm('Tem certeza que deseja remover o logo?')) {
        // Submit the remove form via AJAX
        fetch('<?php echo e(route("partner.profile.logo.remove")); ?>', {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Reload the page or update UI
                location.reload();
            } else {
                alert('Erro ao remover o logo.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Erro ao remover o logo.');
        });
    }
}

// Remove banner function
function removeBanner(event) {
    event.stopPropagation();
    
    if (confirm('Tem certeza que deseja remover o banner?')) {
        fetch('<?php echo e(route("partner.profile.banner.remove")); ?>', {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Erro ao remover o banner.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Erro ao remover o banner.');
        });
    }
}

// Optional: Drag and drop functionality
function setupDragDrop(uploadArea, inputElement) {
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, unhighlight, false);
    });

    function highlight(e) {
        uploadArea.classList.add('bg-light');
    }

    function unhighlight(e) {
        uploadArea.classList.remove('bg-light');
    }

    uploadArea.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        inputElement.files = files;
        
        // Trigger change event
        const event = new Event('change', { bubbles: true });
        inputElement.dispatchEvent(event);
    }
}

// Apply drag drop to upload areas
document.addEventListener('DOMContentLoaded', function() {
    const logoUpload = document.getElementById('logoUpload');
    const logoInput = document.getElementById('logoInput');
    const bannerUpload = document.getElementById('bannerUpload');
    const bannerInput = document.getElementById('bannerInput');
    
    if (logoUpload && logoInput && !logoUpload.querySelector('img')) {
        setupDragDrop(logoUpload, logoInput);
    }
    
    if (bannerUpload && bannerInput && !bannerUpload.querySelector('img')) {
        setupDragDrop(bannerUpload, bannerInput);
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.partner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Constantino\Downloads\portal_backend_chat_packageB_chat_modal_list_users_fixed\resources\views/partner/profile/edit.blade.php ENDPATH**/ ?>